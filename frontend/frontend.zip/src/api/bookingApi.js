const BASE_URL = "http://localhost:5000/api/admin-bookings";

const buildHeaders = (withJson = true) => {
  const token = localStorage.getItem("token");
  const headers = {};

  if (withJson) {
    headers["Content-Type"] = "application/json";
  }

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  return headers;
};

const parseResponse = async (response) => {
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.message || data.error || "Request failed");
  }

  return data;
};

export const createBooking = async (payload) => {
  const response = await fetch(BASE_URL, {
    method: "POST",
    headers: buildHeaders(),
    body: JSON.stringify(payload),
  });

  return parseResponse(response);
};

export const checkBookingAvailability = async (payload) => {
  const response = await fetch(`${BASE_URL}/availability`, {
    method: "POST",
    headers: buildHeaders(),
    body: JSON.stringify(payload),
  });

  return parseResponse(response);
};

export const getHallPeriodAvailability = async (hallId, date) => {
  const query = new URLSearchParams({ date });
  const response = await fetch(`${BASE_URL}/availability/${hallId}?${query.toString()}`, {
    headers: buildHeaders(false),
  });

  return parseResponse(response);
};

export const getFacultyBookings = async (email) => {
  const params = new URLSearchParams();
  if (email) params.set("email", email);

  const response = await fetch(`${BASE_URL}/my${params.toString() ? `?${params.toString()}` : ""}`, {
    headers: buildHeaders(false),
  });

  return parseResponse(response);
};

export const getAllBookings = async (status = "") => {
  const query = status ? `?status=${encodeURIComponent(status)}` : "";
  const response = await fetch(`${BASE_URL}/bookings${query}`, {
    headers: buildHeaders(false),
  });

  return parseResponse(response);
};

export const updateBookingStatus = async (id, status) => {
  const response = await fetch(`${BASE_URL}/${id}/status`, {
    method: "PATCH",
    headers: buildHeaders(),
    body: JSON.stringify({ status }),
  });

  return parseResponse(response);
};

export const cancelBooking = async (id) => {
  const response = await fetch(`${BASE_URL}/${id}/cancel`, {
    method: "PATCH",
    headers: buildHeaders(),
  });

  return parseResponse(response);
};
