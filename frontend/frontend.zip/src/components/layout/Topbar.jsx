import { Menu, Bell, UserCircle } from "lucide-react";

const Topbar = ({ toggleSidebar }) => {

  const today = new Date();

  const formattedDate = today.toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <header className="h-16 bg-white shadow-sm flex items-center justify-between px-6">

      {/* Left Section */}
      <div className="flex items-center gap-4">

        <button
          onClick={toggleSidebar}
          className="text-gray-600 hover:text-blue-700"
        >
          <Menu size={24} />
        </button>

        <div>
          <h2 className="text-xl font-semibold text-gray-800">
            NEC Smart Venue Management
          </h2>

          <p className="text-sm text-gray-500">
            {formattedDate}
          </p>
        </div>

      </div>

      {/* Right Section */}
      <div className="flex items-center gap-5">

        <button className="text-gray-600 hover:text-blue-700">
          <Bell size={22} />
        </button>

        <div className="flex items-center gap-2">

          <UserCircle size={34} className="text-blue-700" />

          <div>
            <p className="font-semibold text-gray-700">
              Admin
            </p>

            <p className="text-xs text-gray-500">
              Administrator
            </p>
          </div>

        </div>

      </div>

    </header>
  );
};

export default Topbar;