import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { X } from 'lucide-react';
import { sendPasswordOtp, updatePassword, verifyPasswordOtp } from '../../api/authApi';

const maskEmail = (email = '') => { const [name, domain] = email.split('@'); return domain ? `${name[0] || ''}***@${domain}` : 'your registered email'; };
const strong = (password) => password.length >= 8 && /[A-Z]/.test(password) && /[a-z]/.test(password) && /\d/.test(password) && /[^A-Za-z0-9]/.test(password);

const ChangePasswordModal = ({ isOpen, email, onClose, onComplete }) => {
  const { t } = useTranslation();
  const [step, setStep] = useState(1); const [otp, setOtp] = useState(''); const [changeToken, setChangeToken] = useState(''); const [newPassword, setNewPassword] = useState(''); const [confirmPassword, setConfirmPassword] = useState(''); const [message, setMessage] = useState(''); const [error, setError] = useState(''); const [busy, setBusy] = useState(false); const [cooldown, setCooldown] = useState(0);
  useEffect(() => { if (!isOpen) { setStep(1); setOtp(''); setChangeToken(''); setNewPassword(''); setConfirmPassword(''); setMessage(''); setError(''); setCooldown(0); } }, [isOpen]);
  useEffect(() => { if (!cooldown) return; const id = setInterval(() => setCooldown((seconds) => Math.max(0, seconds - 1)), 1000); return () => clearInterval(id); }, [cooldown]);
  if (!isOpen) return null;
  const send = async () => { try { setBusy(true); setError(''); const data = await sendPasswordOtp(); setMessage(data.message); setStep(2); setCooldown(60); } catch (err) { setError(err.message); } finally { setBusy(false); } };
  const verify = async (event) => { event.preventDefault(); try { setBusy(true); setError(''); const data = await verifyPasswordOtp(otp); setChangeToken(data.passwordChangeToken); setMessage(data.message); setStep(3); } catch (err) { setError(err.message); } finally { setBusy(false); } };
  const save = async (event) => { event.preventDefault(); if (newPassword !== confirmPassword) return setError('Passwords do not match.'); if (!strong(newPassword)) return setError('Password must be at least 8 characters and include uppercase, lowercase, number, and special character.'); try { setBusy(true); setError(''); const data = await updatePassword(newPassword, changeToken); setMessage(data.message); onComplete(data.message); } catch (err) { setError(err.message); } finally { setBusy(false); } };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl sm:p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-800">{t("profile.changePassword")}</h2>
          <button type="button" aria-label="Close" onClick={onClose} className="rounded-full p-1 text-slate-500 hover:bg-slate-100 cursor-pointer"><X size={20} /></button>
        </div>
        {message && <p className="mt-4 rounded-lg bg-blue-50 p-3 text-sm text-blue-800">{message}</p>}
        {error && <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        {step === 1 && (
          <div className="mt-5 space-y-5">
            <div>
              <p className="text-sm text-slate-500">{t("profile.email")}</p>
              <p className="mt-1 break-all font-medium text-slate-800">{email}</p>
            </div>
            <button disabled={busy} onClick={send} className="w-full rounded-xl bg-blue-700 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60 cursor-pointer">{busy ? t("common.loading") : t("profile.sendOtp")}</button>
          </div>
        )}
        {step === 2 && (
          <form onSubmit={verify} className="mt-5 space-y-4">
            <p className="text-sm text-slate-600">{t("profile.enterOtp")} (<strong>{maskEmail(email)}</strong>)</p>
            <div className="flex justify-between gap-1.5 sm:gap-2">
              {Array.from({ length: 6 }, (_, index) => (
                <input key={index} aria-label={`Verification code digit ${index + 1}`} inputMode="numeric" maxLength="1" value={otp[index] || ''} onChange={(event) => { const digit = event.target.value.replace(/\D/g, ''); const next = otp.split(''); next[index] = digit; setOtp(next.join('').slice(0, 6)); if (digit) event.target.nextElementSibling?.focus(); }} onPaste={(event) => { const digits = event.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6); if (digits) { event.preventDefault(); setOtp(digits); } }} className="min-w-0 flex-1 rounded-lg border border-slate-300 py-3 text-center text-lg outline-none focus:border-blue-600" required />
              ))}
            </div>
            <button disabled={busy || otp.length !== 6} className="w-full rounded-xl bg-blue-700 px-4 py-3 text-sm font-semibold text-white disabled:opacity-60 cursor-pointer">{busy ? t("common.loading") : t("profile.verifyOtp")}</button>
            <button type="button" disabled={busy || cooldown > 0} onClick={send} className="w-full text-sm font-medium text-blue-700 disabled:text-slate-400 cursor-pointer">{cooldown ? `Resend available in ${cooldown}s` : t("profile.sendOtp")}</button>
          </form>
        )}
        {step === 3 && (
          <form onSubmit={save} className="mt-5 space-y-4">
            <input type="password" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} placeholder={t("profile.newPassword")} className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-blue-600 text-sm" required />
            <input type="password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} placeholder={t("profile.confirmNewPassword")} className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-blue-600 text-sm" required />
            <p className={`text-xs ${strong(newPassword) ? 'text-emerald-600' : 'text-slate-500'}`}>Use 8+ characters with uppercase, lowercase, number, and special character.</p>
            <button disabled={busy} className="w-full rounded-xl bg-blue-700 px-4 py-3 text-sm font-semibold text-white disabled:opacity-60 cursor-pointer">{busy ? t("common.loading") : t("profile.updatePassword")}</button>
          </form>
        )}
      </div>
    </div>
  );
};
export default ChangePasswordModal;
