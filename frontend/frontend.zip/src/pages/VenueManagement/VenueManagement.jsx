import { useCallback, useEffect, useState } from "react";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Building2,
  Users,
} from "lucide-react";

import AdminLayout from "../../layouts/AdminLayout";
import { deleteHall, getAllHalls } from "../../api/hallApi";

import AddVenueModal from "./AddVenueModal";
import EditVenueModal from "./EditVenueModal";

const VenueManagement = () => {

  const [venues, setVenues] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("active");

  const [showAddModal, setShowAddModal] = useState(false);

  const [showEditModal, setShowEditModal] = useState(false);

  const [selectedVenue, setSelectedVenue] = useState(null);

  const normalizeVenue = (venue) => ({
    ...venue,
    hallId: venue.hallId ?? venue.HallID ?? venue.id,
    hallName: venue.hallName ?? venue.HallName ?? venue.name ?? "",
    department: venue.department ?? venue.DeptName ?? "",
    deptId: venue.deptId ?? venue.DeptID ?? "",
    location: venue.location ?? venue.Location ?? "",
    capacity: venue.capacity ?? venue.Capacity ?? "",
    numberOfSystems: venue.numberOfSystems ?? venue.NumberOfSystems ?? 0,
    venueType: venue.venueType ?? venue.VenueType ?? "",
    hasProjector: Boolean(venue.hasProjector ?? venue.HasProjector),
    hasSmartBoard: Boolean(venue.hasSmartBoard ?? venue.HasSmartBoard),
    hasWiFi: Boolean(venue.hasWiFi ?? venue.HasWiFi),
    hasSpeaker: Boolean(venue.hasSpeaker ?? venue.HasSpeaker),
    hasPodium: Boolean(venue.hasPodium ?? venue.HasPodium),
    hasWhiteBoard: Boolean(venue.hasWhiteBoard ?? venue.HasWhiteBoard),
    hasCCTV: Boolean(venue.hasCCTV ?? venue.HasCCTV),
    hasAC: Boolean(venue.hasAC ?? venue.HasAC),
    microphoneType: venue.microphoneType ?? venue.MicrophoneType ?? "None",
    additionalFeatures: venue.additionalFeatures ?? venue.AdditionalFeatures ?? "",
    image: venue.image ?? venue.ImageURL ?? null,
    activeStatus: Boolean(venue.activeStatus ?? venue.ActiveStatus ?? true),
  });

  const loadVenues = useCallback(async () => {
    try {
      const response = await getAllHalls();
      const normalizedVenues = (response.data || []).map(normalizeVenue);
      setVenues(normalizedVenues);
    } catch (error) {
      console.error(error);
    }
  }, []);

  useEffect(() => {
    loadVenues();
  }, [loadVenues]);

  const filteredVenues = venues.filter((venue) => {
    // Search filter
    const matchesSearch = (venue.hallName || "").toLowerCase().includes(search.toLowerCase());
    
    // Status filter
    let matchesStatus = true;
    if (statusFilter === "active") {
      matchesStatus = venue.activeStatus === true;
    } else if (statusFilter === "inactive") {
      matchesStatus = venue.activeStatus === false;
    }
    // If statusFilter === "all", matchesStatus stays true
    
    return matchesSearch && matchesStatus;
  });

  const handleDeleteVenue = async (venue) => {
    const confirmed = window.confirm("Are you sure you want to delete this venue permanently?");

    if (!confirmed) return;

    try {
      const response = await deleteHall(venue.hallId);

      if (response?.success) {
        alert("Venue deleted successfully.");
        await loadVenues();
      } else {
        alert(response?.message || "Failed to delete venue.");
      }
    } catch (error) {
      console.error(error);
      alert(error.message || "Failed to delete venue.");
    }
  };

  return (
    <AdminLayout>

      <div className="p-6">

        {/* Header */}

        <div className="flex justify-between items-center mb-6">

          <h1 className="text-3xl font-bold">
            Venue Management
          </h1>

          <button
            onClick={() => setShowAddModal(true)}
            className="bg-blue-600 text-white px-5 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
          >
            <Plus size={18} />

            Add Venue
          </button>

        </div>

        {/* Search */}

        <div className="relative mb-6">

          <Search
            size={18}
            className="absolute left-3 top-3 text-gray-400"
          />

          <input
            type="text"
            placeholder="Search venue..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 w-full border rounded-lg p-3"
          />

        </div>

        {/* Status Filter */}

        <div className="mb-6 flex gap-3">

          <label className="text-sm font-medium text-gray-700 self-center">
            Filter by Status:
          </label>

          <div className="flex gap-2">

            <button
              onClick={() => setStatusFilter("active")}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                statusFilter === "active"
                  ? "bg-green-600 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              Active
            </button>

            <button
              onClick={() => setStatusFilter("inactive")}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                statusFilter === "inactive"
                  ? "bg-red-600 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              Inactive
            </button>

            <button
              onClick={() => setStatusFilter("all")}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                statusFilter === "all"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              All
            </button>

          </div>

        </div>

        {/* Table */}

        <div className="bg-white rounded-xl shadow overflow-hidden">

          <table className="w-full">

            <thead className="bg-gray-100">

              <tr>

                <th className="p-4">Venue</th>

                <th className="p-4">Department</th>

                <th className="p-4">Type</th>

                <th className="p-4">Capacity</th>

                <th className="p-4">Location</th>

                <th className="p-4">Facilities</th>

                <th className="p-4">Status</th>

                <th className="p-4 text-center">
                  Actions
                </th>

              </tr>

            </thead>

            <tbody>

              {filteredVenues.map((venue) => (

                <tr
                  key={venue.hallId}
                  className="border-b hover:bg-gray-50"
                >

                  <td className="p-4 font-semibold">

                    <div className="flex items-center gap-2">

                      <Building2
                        size={18}
                        className="text-blue-600"
                      />

                      {venue.hallName}

                    </div>

                  </td>

                  <td className="p-4">
                    {venue.department}
                  </td>

                  <td className="p-4">

                    <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm">

                      {venue.venueType}

                    </span>

                  </td>

                  <td className="p-4">

                    <div className="flex items-center gap-2">

                      <Users size={16} />

                      {venue.capacity}

                    </div>

                  </td>

                  <td className="p-4">
                    {venue.location}
                  </td>

                  <td className="p-4">

                    <div className="flex gap-2 flex-wrap">

                      {venue.hasAC &&
                        <span className="bg-green-100 text-green-700 px-2 rounded">
                          AC
                        </span>}

                      {venue.hasProjector &&
                        <span className="bg-blue-100 text-blue-700 px-2 rounded">
                          Projector
                        </span>}

                      {venue.hasSmartBoard &&
                        <span className="bg-purple-100 text-purple-700 px-2 rounded">
                          Smart Board
                        </span>}

                    </div>

                  </td>

                  <td className="p-4">

                    {venue.activeStatus ? (

                      <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full">

                        Active

                      </span>

                    ) : (

                      <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full">

                        Inactive

                      </span>

                    )}

                  </td>

                  <td className="p-4">

                    <div className="flex justify-center gap-4">

                      <button
                        onClick={() => {
                          setSelectedVenue(venue);
                          setShowEditModal(true);
                        }}
                        className="text-blue-600"
                      >
                        <Pencil size={18} />
                      </button>

                      <button
                        onClick={() => handleDeleteVenue(venue)}
                        className="text-red-600"
                      >
                        <Trash2 size={18} />
                      </button>

                    </div>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        </div>

      </div>

      <AddVenueModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={loadVenues}
      />

      {showEditModal && selectedVenue && (
        <EditVenueModal
          isOpen={showEditModal}
          venue={selectedVenue}
          onClose={() => setShowEditModal(false)}
          onSuccess={loadVenues}
        />
      )}

    </AdminLayout>
  );
};

export default VenueManagement;