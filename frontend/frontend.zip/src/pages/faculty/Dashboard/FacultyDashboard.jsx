import { useEffect, useMemo, useState } from "react";
import { BookOpen, CalendarCheck2, CircleX, Clock3, Eye } from "lucide-react";
import FacultyLayout from "../../../layouts/FacultyLayout";
import DashboardCard from "../../../components/faculty/DashboardCard";
import RecentBookingTable from "../../../components/faculty/RecentBookingTable";
import PageHeader from "../../../components/faculty/PageHeader";
import DetailModal from "../../../components/faculty/DetailModal";

const mockBookings = [
  { id: "BK101", venue: "Seminar Hall A", date: "2026-08-10", time: "09:00 - 11:00", status: "Approved" },
  { id: "BK102", venue: "Conference Room", date: "2026-08-12", time: "14:00 - 15:00", status: "Pending" },
  { id: "BK103", venue: "Lab 3", date: "2026-08-14", time: "10:00 - 12:00", status: "Rejected" },
  { id: "BK104", venue: "Auditorium", date: "2026-08-16", time: "16:00 - 18:00", status: "Completed" },
];

const FacultyDashboard = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedBooking, setSelectedBooking] = useState(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setBookings(mockBookings);
      setLoading(false);
    }, 600);

    return () => clearTimeout(timer);
  }, []);

  const stats = useMemo(() => {
    const total = bookings.length;
    const pending = bookings.filter((b) => b.status === "Pending").length;
    const approved = bookings.filter((b) => b.status === "Approved").length;
    const cancelled = bookings.filter((b) => b.status === "Cancelled").length;

    return [
      { title: "Total Bookings", count: total, icon: BookOpen, accent: "bg-blue-100 text-blue-700" },
      { title: "Pending", count: pending, icon: Clock3, accent: "bg-amber-100 text-amber-700" },
      { title: "Approved", count: approved, icon: CalendarCheck2, accent: "bg-emerald-100 text-emerald-700" },
      { title: "Cancelled", count: cancelled, icon: CircleX, accent: "bg-rose-100 text-rose-700" },
    ];
  }, [bookings]);

  if (loading) {
    return (
      <FacultyLayout>
        <div className="space-y-6">
          <div className="h-10 w-64 animate-pulse rounded-full bg-slate-200" />
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {Array.from({ length: 4 }).map((_, index) => (
              <div key={index} className="h-32 animate-pulse rounded-2xl bg-slate-200" />
            ))}
          </div>
          <div className="h-80 animate-pulse rounded-2xl bg-slate-200" />
        </div>
      </FacultyLayout>
    );
  }

  return (
    <FacultyLayout>
      <div className="space-y-6">
        <PageHeader title="Faculty Dashboard" description="Overview of your venue bookings and status updates." action={<button type="button" className="flex items-center gap-2 rounded-xl border border-blue-200 px-3 py-2 text-sm font-medium text-blue-700 transition hover:bg-blue-50"><Eye size={16} /> View All</button>} />

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => (
            <DashboardCard key={stat.title} {...stat} />
          ))}
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
          <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-semibold text-slate-800">Recent Activity</h2>
              <p className="text-sm text-slate-500">Latest venue requests submitted by you.</p>
            </div>
          </div>
          <RecentBookingTable bookings={bookings} onView={setSelectedBooking} />
        </div>
      </div>

      {selectedBooking && (
        <DetailModal
          title="Booking Details"
          subtitle={selectedBooking.id}
          rows={[
            { label: "Venue", value: selectedBooking.venue },
            { label: "Date", value: selectedBooking.date },
            { label: "Time", value: selectedBooking.time },
            { label: "Status", value: selectedBooking.status },
          ]}
          onClose={() => setSelectedBooking(null)}
        />
      )}
    </FacultyLayout>
  );
};

export default FacultyDashboard;
