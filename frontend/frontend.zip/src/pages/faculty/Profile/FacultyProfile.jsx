import { Camera, Mail, Phone, Building2, BadgeCheck, IdCard, Pencil, Lock } from "lucide-react";
import FacultyLayout from "../../../layouts/FacultyLayout";
import { useEffect, useState } from "react";
import { getProfile } from "../../../api/staffApi";
import EditFacultyModal from "../../FacultyManagement/EditFacultyModal";

const FacultyProfile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditOpen, setIsEditOpen] = useState(false);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      const data = await getProfile(token);
      setProfile(data);
    } catch (err) {
      console.error('Failed to load profile', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, []);

  const avatarUrl = (p) => {
    if (p && p.profile_image) return p.profile_image;
    const name = p && p.full_name ? p.full_name : 'User';
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=0D8ABC&color=fff&size=256`;
  };

  const notAvailable = (val) => (val && val !== '' ? val : 'Not Available');

  return (
    <FacultyLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold text-slate-800">My Profile</h1>
          <p className="text-sm text-slate-500">Manage your profile details and account preferences.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex flex-col items-center text-center">
              <div className="relative">
                <img src={avatarUrl(profile)} alt={profile ? profile.full_name : 'Profile'} className="h-28 w-28 rounded-full object-cover" />
                <button className="absolute bottom-0 right-0 rounded-full bg-blue-700 p-2 text-white shadow-lg">
                  <Camera size={16} />
                </button>
              </div>
              <h2 className="mt-4 text-xl font-semibold text-slate-800">{profile ? profile.full_name : (loading ? 'Loading...' : 'Profile')}</h2>
              <p className="text-sm text-slate-500">{profile ? notAvailable(profile.designation) : ''}</p>
              <div className="mt-4 inline-flex rounded-full bg-blue-50 px-3 py-1 text-sm font-medium text-blue-700">
                {profile ? notAvailable(profile.department) : ''}
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold text-slate-800">Profile Information</h3>
                <p className="text-sm text-slate-500">Your academic and contact details.</p>
              </div>
              <button onClick={() => setIsEditOpen(true)} className="flex items-center gap-2 rounded-xl border border-blue-200 px-3 py-2 text-sm font-medium text-blue-700 transition hover:bg-blue-50">
                <Pencil size={16} /> Edit Profile
              </button>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl bg-slate-50 p-4">
                <div className="flex items-center gap-2 text-slate-500">
                  <Mail size={16} /> <span className="text-sm font-medium">Email</span>
                </div>
                <p className="mt-2 text-sm font-semibold text-slate-700">{profile ? profile.email : ''}</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-4">
                <div className="flex items-center gap-2 text-slate-500">
                  <Phone size={16} /> <span className="text-sm font-medium">Phone</span>
                </div>
                <p className="mt-2 text-sm font-semibold text-slate-700">{profile ? notAvailable(profile.phone) : ''}</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-4">
                <div className="flex items-center gap-2 text-slate-500">
                  <Building2 size={16} /> <span className="text-sm font-medium">Department</span>
                </div>
                <p className="mt-2 text-sm font-semibold text-slate-700">{profile ? notAvailable(profile.department) : ''}</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-4">
                <div className="flex items-center gap-2 text-slate-500">
                  <BadgeCheck size={16} /> <span className="text-sm font-medium">Designation</span>
                </div>
                <p className="mt-2 text-sm font-semibold text-slate-700">{profile ? notAvailable(profile.designation) : ''}</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-4 sm:col-span-2">
                <div className="flex items-center gap-2 text-slate-500">
                  <IdCard size={16} /> <span className="text-sm font-medium">Employee ID</span>
                </div>
                <p className="mt-2 text-sm font-semibold text-slate-700">{profile ? profile.staff_id : ''}</p>
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button className="flex items-center gap-2 rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-100">
                <Lock size={16} /> Change Password
              </button>
            </div>
          </div>
        </div>

        <EditFacultyModal
          isOpen={isEditOpen}
          faculty={profile}
          onClose={() => setIsEditOpen(false)}
          onSuccess={() => { setIsEditOpen(false); loadProfile(); }}
        />
      </div>
    </FacultyLayout>
  );
};

export default FacultyProfile;
