param(
    [string]$docxPath,
    [string]$pdfPath
)

$word = New-Object -ComObject Word.Application
$word.Visible = $false
try {
    $absDocx = (Resolve-Path $docxPath).Path
    $absPdf = [System.IO.Path]::GetFullPath($pdfPath)
    $doc = $word.Documents.Open($absDocx)
    # Update fields (TOC, page numbers, etc.)
    $doc.Fields.Update()
    foreach ($tableOfContents in $doc.TablesOfContents) {
        $tableOfContents.Update()
    }
    # 17 = wdFormatPDF
    $doc.SaveAs([ref]$absPdf, [ref]17)
    $doc.Close([ref]$false)
    Write-Host "Successfully exported PDF: $absPdf"
}
finally {
    $word.Quit()
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($word) | Out-Null
}
