import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

doc = docx.Document()
section = doc.sections[0]
section.page_width = Inches(8.27)
section.page_height = Inches(11.69)
section.top_margin = Inches(1.0)
section.bottom_margin = Inches(1.0)
section.left_margin = Inches(1.0)
section.right_margin = Inches(1.0)

# Add page border
sectPr = section._sectPr
pgBorders = parse_xml(
    '<w:pgBorders %s w:offsetFrom="page">'
    '<w:top w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '<w:left w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '<w:bottom w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '<w:right w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '</w:pgBorders>' % nsdecls('w')
)
sectPr.append(pgBorders)

# Add page number to footer
footer = section.footer
f_p = footer.paragraphs[0]
f_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
f_run = f_p.add_run()
fldSimple = parse_xml(r'<w:fldSimple %s w:instr="PAGE"/>' % nsdecls('w'))
f_run._r.append(fldSimple)

p = doc.add_paragraph('Test Paragraph in Times New Roman')
doc.save('test_out.docx')
print('test_out.docx created successfully!')
