const path = require('path');
const fs = require('fs');
const puppeteer = require(path.join(__dirname, 'backend', 'node_modules', 'puppeteer-core'));

const outDir = path.resolve(__dirname, 'report_screenshots');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

async function main() {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox', '--window-size=1440,960']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 960 });

  console.log('1. Capturing Login Page...');
  await page.goto('http://localhost:5173/', { waitUntil: 'networkidle2' });
  await page.screenshot({ path: path.join(outDir, '01_login.png') });

  console.log('Logging in as Admin...');
  await page.type('input[name="email"]', 'admin@nec.edu.in');
  await page.type('input[name="password"]', 'Admin@123');
  await page.click('button[type="submit"]');
  await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
  await new Promise(r => setTimeout(r, 2000));

  console.log('2. Admin Dashboard...');
  await page.screenshot({ path: path.join(outDir, '02_admin_dashboard.png') });

  console.log('3. Venue Management...');
  await page.goto('http://localhost:5173/admin/venue-management', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '03_venue_management.png') });

  console.log('4. Add Venue Modal...');
  try {
    const addVenueBtn = await page.$('button.bg-blue-700, button:has-text("Add Venue")');
    if (addVenueBtn) {
      await addVenueBtn.click();
      await new Promise(r => setTimeout(r, 1000));
      await page.screenshot({ path: path.join(outDir, '04_venue_add_modal.png') });
      await page.keyboard.press('Escape');
      await new Promise(r => setTimeout(r, 500));
    }
  } catch (e) {
    console.error('Add venue modal err:', e.message);
  }

  console.log('5. Manage Departments...');
  try {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(x => x.textContent.includes('Manage Departments'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 1000));
    await page.screenshot({ path: path.join(outDir, '05_manage_departments.png') });
  } catch (e) { console.error(e.message); }

  console.log('6. Manage Venue Types...');
  try {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(x => x.textContent.includes('Manage Venue Types'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 1000));
    await page.screenshot({ path: path.join(outDir, '06_manage_venue_types.png') });
  } catch (e) { console.error(e.message); }

  console.log('7. Manage Facilities...');
  try {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(x => x.textContent.includes('Manage Facilities'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 1000));
    await page.screenshot({ path: path.join(outDir, '07_manage_facilities.png') });
  } catch (e) { console.error(e.message); }

  console.log('8. Faculty Management...');
  await page.goto('http://localhost:5173/admin/faculty-management', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '08_faculty_management.png') });

  console.log('9. Add Faculty Modal...');
  try {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(x => x.textContent.includes('Add Faculty') || x.textContent.includes('Add Staff'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 1000));
    await page.screenshot({ path: path.join(outDir, '09_faculty_add_modal.png') });
    await page.keyboard.press('Escape');
    await new Promise(r => setTimeout(r, 500));
  } catch (e) { console.error(e.message); }

  console.log('10. Admin Bookings...');
  await page.goto('http://localhost:5173/admin/bookings', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '10_admin_bookings.png') });

  console.log('11. Admin Bookings Pending Filter...');
  try {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(x => x.textContent.trim() === 'Pending');
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 1000));
    await page.screenshot({ path: path.join(outDir, '11_admin_bookings_pending.png') });
  } catch (e) { console.error(e.message); }

  console.log('12. Admin Timetable...');
  await page.goto('http://localhost:5173/admin/timetable', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '12_admin_timetable.png') });

  console.log('13. Admin Reports...');
  await page.goto('http://localhost:5173/admin/reports', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(outDir, '13_admin_reports.png') });

  console.log('14. Admin Analytics...');
  await page.goto('http://localhost:5173/admin/analytics', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(outDir, '14_admin_analytics.png') });

  console.log('15. Admin Notifications...');
  await page.goto('http://localhost:5173/admin/notifications', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '15_admin_notifications.png') });

  console.log('16. Admin Profile...');
  await page.goto('http://localhost:5173/admin/profile', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '16_admin_profile.png') });

  console.log('Switching to Faculty...');
  await page.evaluate(() => localStorage.clear());
  await page.goto('http://localhost:5173/', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1000));

  await page.type('input[name="email"]', 'alice@nec.edu.in');
  await page.type('input[name="password"]', 'Alice@123');
  await page.click('button[type="submit"]');
  await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
  await new Promise(r => setTimeout(r, 2000));

  console.log('17. Faculty Dashboard...');
  await page.screenshot({ path: path.join(outDir, '17_faculty_dashboard.png') });

  console.log('18. Faculty Book Venue...');
  await page.goto('http://localhost:5173/faculty/book-venue', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(outDir, '18_faculty_book_venue.png') });

  console.log('19. Faculty Book Venue Details / Form...');
  try {
    const bookNowBtn = await page.$('button.bg-blue-600, button:has-text("Book Now"), button:has-text("Book Venue")');
    if (bookNowBtn) {
      await bookNowBtn.click();
      await new Promise(r => setTimeout(r, 1500));
      await page.screenshot({ path: path.join(outDir, '19_faculty_book_modal.png') });
      await page.keyboard.press('Escape');
    }
  } catch (e) { console.error(e.message); }

  console.log('20. Faculty My Bookings...');
  await page.goto('http://localhost:5173/faculty/my-bookings', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  await page.screenshot({ path: path.join(outDir, '20_faculty_my_bookings.png') });

  console.log('21. Faculty Notifications...');
  await page.goto('http://localhost:5173/faculty/notifications', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '21_faculty_notifications.png') });

  console.log('22. Faculty Profile...');
  await page.goto('http://localhost:5173/faculty/profile', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '22_faculty_profile.png') });

  console.log('23. Faculty Change Password / OTP Modal...');
  try {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(x => x.textContent.includes('Change Password'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 1000));
    await page.screenshot({ path: path.join(outDir, '23_change_password_otp.png') });
    await page.keyboard.press('Escape');
  } catch (e) { console.error(e.message); }

  await browser.close();
  console.log('All screens captured successfully!');
}

main().catch(err => {
  console.error('Execution failed:', err);
  process.exit(1);
});
