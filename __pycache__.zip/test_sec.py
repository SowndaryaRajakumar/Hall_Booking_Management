import docx
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

doc = docx.Document()
sec1 = doc.sections[0]
sec1.different_first_page_header_footer = True
p1 = doc.add_paragraph('Title Page')

sec2 = doc.add_section()
sec2.header.is_linked_to_previous = False
sec2.footer.is_linked_to_previous = False
sectPr = sec2._sectPr
pgNumType = parse_xml(f'<w:pgNumType {nsdecls("w")} w:start="1"/>')
sectPr.append(pgNumType)

f_p = sec2.footer.paragraphs[0]
f_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
f_run = f_p.add_run()
f_run.font.name = 'Times New Roman'
fld = parse_xml(f'<w:fldSimple {nsdecls("w")} w:instr="PAGE"/>')
f_run._r.append(fld)

p2 = doc.add_paragraph('Certificate Page')
doc.save('test_sec.docx')
print('test_sec.docx created successfully!')
