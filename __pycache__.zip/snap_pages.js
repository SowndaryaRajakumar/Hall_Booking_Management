const puppeteer = require('./backend/node_modules/puppeteer-core');
const path = require('path');
const fs = require('fs');

async function snap() {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 900, height: 1200, deviceScaleFactor: 1.5 });
  
  let html = fs.readFileSync('ex15_template.html', 'utf8');
  function toBase64(filePath) {
    const bitmap = fs.readFileSync(filePath);
    const ext = path.extname(filePath).replace('.', '');
    return 'data:image/' + (ext === 'png' ? 'png' : 'jpeg') + ';base64,' + bitmap.toString('base64');
  }
  html = html.replace('{{FRONTEND_IMG}}', toBase64('ex15_assets/struct_frontend.png'))
             .replace('{{BACKEND_IMG}}', toBase64('ex15_assets/struct_backend.png'))
             .replace('{{TERM_IMG}}', toBase64('ex15_assets/screen_terminal.png'))
             .replace('{{DASH_IMG}}', toBase64('report_screenshots/02_admin_dashboard.png'))
             .replace('{{API_IMG}}', toBase64('ex15_assets/screen_api.png'))
             .replace('{{BOOKINGS_IMG}}', toBase64('report_screenshots/10_admin_bookings.png'));
             
  await page.setContent(html, { waitUntil: 'networkidle0' });
  const pages = await page.$$('.page');
  console.log('Found', pages.length, 'pages');
  for (let i = 0; i < pages.length; i++) {
    await pages[i].screenshot({ path: 'ex15_assets/page_' + (i + 1) + '.png' });
    console.log('Saved page', i + 1);
  }
  await browser.close();
}
snap().catch(console.error);
