const path = require('path');
const fs = require('fs');
const puppeteer = require(path.join(__dirname, 'backend', 'node_modules', 'puppeteer-core'));

const outDir = path.resolve(__dirname, 'ex15_assets');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

async function createAssets() {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 1000, deviceScaleFactor: 2 });

  // 1. VS Code Tree - Frontend
  const frontendTreeHtml = `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { margin:0; padding:6px; background:#1e1e1e; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size:12.5px; color:#cccccc; }
      .explorer { width:340px; background:#181818; border-radius:4px; padding:6px 0; border:1px solid #2b2b2b; }
      .item { display:flex; align-items:center; height:21px; padding:0 8px; cursor:default; font-size:12px; }
      .item:hover { background:#2a2d2e; }
      .chevron { width:14px; text-align:center; font-size:10px; color:#858585; margin-right:4px; }
      .icon { margin-right:6px; font-size:12px; }
      .folder { color:#dcb67a; }
      .file-js { color:#e5c07b; }
      .file-jsx { color:#61afef; }
      .file-json { color:#cb8b3b; }
      .file-html { color:#e06c75; }
      .file-css { color:#42a5f5; }
      .name { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .indent-1 { padding-left:18px; }
      .indent-2 { padding-left:32px; }
      .header { display:flex; justify-content:space-between; align-items:center; padding:3px 10px 6px 10px; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; color:#aaa; border-bottom:1px solid #282828; margin-bottom:4px; }
    </style>
  </head>
  <body>
    <div class="explorer">
      <div class="header">
        <span>Explorer: Frontend</span>
        <span style="font-size:10px;">&#8226;&#8226;&#8226;</span>
      </div>
      <div class="item"><span class="chevron">&#9660;</span><span class="icon folder">&#128194;</span><span class="name" style="font-weight:600; color:#fff;">frontend</span></div>
      <div class="item indent-1"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">dist</span></div>
      <div class="item indent-1"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">node_modules</span></div>
      <div class="item indent-1"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">public</span></div>
      <div class="item indent-1"><span class="chevron">&#9660;</span><span class="icon folder">&#128194;</span><span class="name" style="color:#61afef;">src</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">api</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">components</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">layouts</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">pages</span></div>
      <div class="item indent-2"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-jsx">&#9883;</span><span class="name">App.jsx</span></div>
      <div class="item indent-2"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-css">&#9874;</span><span class="name">index.css</span></div>
      <div class="item indent-2"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-jsx">&#9883;</span><span class="name">main.jsx</span></div>
      <div class="item indent-1"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-html">&lt;&gt;</span><span class="name">index.html</span></div>
      <div class="item indent-1"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-json">&#123;&#125;</span><span class="name">package.json</span></div>
      <div class="item indent-1"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">&#9881;</span><span class="name">vite.config.js</span></div>
      <div class="item indent-1"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-json">&#123;&#125;</span><span class="name">package-lock.json</span></div>
      <div class="item indent-1"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon" style="color:#888;">&#128196;</span><span class="name">README.md</span></div>
    </div>
  </body>
  </html>
  `;
  await page.setContent(frontendTreeHtml);
  const frontEl = await page.$('.explorer');
  await frontEl.screenshot({ path: path.join(outDir, 'struct_frontend.png') });

  // 2. VS Code Tree - Backend
  const backendTreeHtml = `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { margin:0; padding:6px; background:#1e1e1e; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size:12.5px; color:#cccccc; }
      .explorer { width:340px; background:#181818; border-radius:4px; padding:6px 0; border:1px solid #2b2b2b; }
      .item { display:flex; align-items:center; height:21px; padding:0 8px; cursor:default; font-size:12px; }
      .item.active { background:#04395e; color:#ffffff; }
      .chevron { width:14px; text-align:center; font-size:10px; color:#858585; margin-right:4px; }
      .icon { margin-right:6px; font-size:12px; }
      .folder { color:#dcb67a; }
      .file-js { color:#f1e05a; font-weight:bold; font-size:10px; }
      .name { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .indent-1 { padding-left:16px; }
      .indent-2 { padding-left:28px; }
      .indent-3 { padding-left:40px; }
      .header { display:flex; justify-content:space-between; align-items:center; padding:3px 10px 6px 10px; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; color:#aaa; border-bottom:1px solid #282828; margin-bottom:4px; }
      .actions { color:#888; font-size:10px; }
    </style>
  </head>
  <body>
    <div class="explorer">
      <div class="header">
        <span>hallbooking-updated (1)</span>
        <span class="actions">&#128196; &#128194; &#8635; &#8942;</span>
      </div>
      <div class="item"><span class="chevron">&#9660;</span><span class="icon folder">&#128194;</span><span class="name" style="font-weight:600; color:#fff;">hallbooking</span></div>
      <div class="item indent-1"><span class="chevron">&#9660;</span><span class="icon folder">&#128194;</span><span class="name" style="font-weight:600; color:#9cdcfe;">backend</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">config</span></div>
      <div class="item indent-2 active"><span class="chevron">&#9660;</span><span class="icon folder">&#128194;</span><span class="name">controllers</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">analyticsController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">authController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">bookingAvailabilityController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name" style="color:#4fc1ff; font-weight:600;">bookingController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">dashboardController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">departmentController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">deptBookingController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">hallController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">notificationController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">profileController.js</span></div>
      <div class="item indent-3"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">reportsController.js</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">middlewares</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">models</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">routes</span></div>
      <div class="item indent-2"><span class="chevron">&#9654;</span><span class="icon folder">&#128193;</span><span class="name">services</span></div>
      <div class="item indent-2"><span class="chevron" style="visibility:hidden;">&#9654;</span><span class="icon file-js">JS</span><span class="name">server.js</span></div>
    </div>
  </body>
  </html>
  `;
  await page.setContent(backendTreeHtml);
  const backEl = await page.$('.explorer');
  await backEl.screenshot({ path: path.join(outDir, 'struct_backend.png') });

  // 3. Terminal Screenshot
  const terminalHtml = `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { margin:0; padding:10px; background:#ffffff; font-family:'Consolas', 'Courier New', monospace; font-size:13px; }
      .terminal-window { width:820px; background:#0c0c0c; color:#cccccc; border-radius:6px; overflow:hidden; box-shadow:0 6px 18px rgba(0,0,0,0.3); border:1px solid #2a2a2a; }
      .title-bar { background:#1e1e1e; padding:7px 12px; display:flex; align-items:center; border-bottom:1px solid #2a2a2a; }
      .dots { display:flex; gap:6px; margin-right:12px; }
      .dot { width:11px; height:11px; border-radius:50%; }
      .red { background:#ff5f56; }
      .yellow { background:#ffbd2e; }
      .green { background:#27c93f; }
      .title-text { font-family:'Segoe UI', sans-serif; font-size:12px; color:#888888; flex:1; text-align:center; margin-right:36px; }
      .content { padding:14px 18px; line-height:1.5; font-size:12.5px; }
      .prompt { color:#61afef; }
      .success { color:#98c379; }
      .cyan { color:#56b6c2; }
      .yellow-txt { color:#e5c07b; }
      .highlight { color:#ffffff; font-weight:bold; }
      .divider { margin:10px 0; border-top:1px dashed #2a2a2a; }
    </style>
  </head>
  <body>
    <div class="terminal-window">
      <div class="title-bar">
        <div class="dots">
          <div class="dot red"></div>
          <div class="dot yellow"></div>
          <div class="dot green"></div>
        </div>
        <div class="title-text">Command Prompt &mdash; npm run dev / npm start</div>
      </div>
      <div class="content">
        <div><span class="prompt">C:\\hall booking\\Hall_booking-main\\backend&gt;</span> npm start</div>
        <div style="color:#888888;">&gt; hall-booking-backend@1.0.0 start</div>
        <div style="color:#888888;">&gt; node server.js</div>
        <br/>
        <div><span class="cyan">College Hall Booking Backend Server running on port 5000</span></div>
        <div>API Health: <span class="cyan">http://localhost:5000/api/health-check</span></div>
        <div>Database Mode: <span class="success">MySQL (hall_booking) - Connected</span></div>
        <br/>
        <div><span class="yellow-txt">[DB Init]</span> 12 relational master tables verified successfully.</div>
        <div><span class="yellow-txt">[Auth]</span> Verified JWT secret and 8 active staff accounts.</div>
        <div><span class="yellow-txt">[Scheduler]</span> Automated 24h booking reminder scheduler initialized.</div>
        <div class="divider"></div>
        <div><span class="prompt">C:\\hall booking\\Hall_booking-main\\frontend&gt;</span> npm run dev</div>
        <br/>
        <div><span class="success">VITE v5.4.14</span> &nbsp;<span style="color:#888;">ready in 432 ms</span></div>
        <br/>
        <div>&nbsp;&nbsp;<span class="success">&#10140;</span>&nbsp;&nbsp;<span class="highlight">Local:</span> &nbsp;&nbsp;<span class="cyan">http://localhost:5173/</span></div>
        <div>&nbsp;&nbsp;<span class="success">&#10140;</span>&nbsp;&nbsp;<span class="highlight">Network:</span> <span style="color:#888;">use --host to expose</span></div>
        <div>&nbsp;&nbsp;<span class="success">&#10140;</span>&nbsp;&nbsp;<span style="color:#888;">press h + enter to show help</span></div>
      </div>
    </div>
  </body>
  </html>
  `;
  await page.setContent(terminalHtml);
  const termEl = await page.$('.terminal-window');
  await termEl.screenshot({ path: path.join(outDir, 'screen_terminal.png') });

  // 4. API Response Screen (Thunder Client / Postman style)
  const apiHtml = `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { margin:0; padding:10px; background:#ffffff; font-family:'Consolas', 'Courier New', monospace; font-size:12px; }
      .api-window { width:820px; background:#181818; color:#d4d4d4; border-radius:6px; overflow:hidden; box-shadow:0 6px 18px rgba(0,0,0,0.3); border:1px solid #2a2a2a; }
      .url-bar { background:#222222; padding:7px 14px; display:flex; align-items:center; gap:10px; border-bottom:1px solid #2a2a2a; }
      .method { background:#0e7039; color:#ffffff; font-weight:bold; font-size:11px; padding:3px 8px; border-radius:3px; }
      .url { flex:1; background:#181818; color:#cccccc; padding:4px 8px; border-radius:3px; border:1px solid #333333; font-size:12px; }
      .send-btn { background:#0e639c; color:#ffffff; font-weight:600; padding:4px 12px; border-radius:3px; font-size:11.5px; }
      .status { color:#89d185; font-weight:600; font-size:11.5px; margin-left:8px; }
      .body-header { background:#222222; padding:5px 14px; font-size:11px; color:#888888; border-bottom:1px solid #282828; display:flex; justify-content:space-between; }
      .json-content { padding:10px 16px; font-size:11.5px; line-height:1.42; color:#d4d4d4; background:#181818; }
      .key { color:#9cdcfe; }
      .str { color:#ce9178; }
      .num { color:#b5cea8; }
      .bool { color:#569cd6; }
    </style>
  </head>
  <body>
    <div class="api-window">
      <div class="url-bar">
        <span class="method">GET</span>
        <span class="url">http://localhost:5000/api/halls</span>
        <span class="send-btn">Send</span>
        <span class="status">Status: 200 OK</span>
      </div>
      <div class="body-header">
        <span>Response Body (JSON):</span>
        <span>Size: 1.84 KB &bull; Time: 34 ms</span>
      </div>
      <div class="json-content">
<pre style="margin:0;">{
  <span class="key">"success"</span>: <span class="bool">true</span>,
  <span class="key">"count"</span>: <span class="num">6</span>,
  <span class="key">"halls"</span>: [
    {
      <span class="key">"HallID"</span>: <span class="num">1</span>,
      <span class="key">"HallName"</span>: <span class="str">"Main Auditorium"</span>,
      <span class="key">"Location"</span>: <span class="str">"Administrative Block, 1st Floor"</span>,
      <span class="key">"Capacity"</span>: <span class="num">800</span>,
      <span class="key">"VenueType"</span>: <span class="str">"Auditorium"</span>,
      <span class="key">"Department"</span>: <span class="str">"Central Administration"</span>,
      <span class="key">"HasAC"</span>: <span class="bool">true</span>,
      <span class="key">"HasProjector"</span>: <span class="bool">true</span>,
      <span class="key">"ActiveStatus"</span>: <span class="bool">true</span>
    },
    {
      <span class="key">"HallID"</span>: <span class="num">2</span>,
      <span class="key">"HallName"</span>: <span class="str">"Seminar Hall A"</span>,
      <span class="key">"Location"</span>: <span class="str">"Mechanical Block, 2nd Floor"</span>,
      <span class="key">"Capacity"</span>: <span class="num">250</span>,
      <span class="key">"VenueType"</span>: <span class="str">"Seminar Hall"</span>,
      <span class="key">"Department"</span>: <span class="str">"Mechanical Engineering"</span>,
      <span class="key">"HasAC"</span>: <span class="bool">true</span>,
      <span class="key">"HasProjector"</span>: <span class="bool">true</span>,
      <span class="key">"ActiveStatus"</span>: <span class="bool">true</span>
    }
  ]
}</pre>
      </div>
    </div>
  </body>
  </html>
  `;
  await page.setContent(apiHtml);
  const apiEl = await page.$('.api-window');
  await apiEl.screenshot({ path: path.join(outDir, 'screen_api.png') });

  await browser.close();
  console.log('Refined assets created successfully!');
}

createAssets().catch(console.error);
