const path = require('path');
const fs = require('fs');
const puppeteer = require(path.join(__dirname, 'backend', 'node_modules', 'puppeteer-core'));

const outDir = path.resolve(__dirname, 'report_diagrams');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

function renderBoxArchHtml(title, subtitle, layers) {
  const boxHtml = layers.map((l, idx) => `
    <div style="background:${l.bg}; border:1.5px solid ${l.border}; border-radius:8px; padding:12px 20px; margin-bottom:${idx === layers.length - 1 ? '0' : '14px'}; box-shadow:0 1px 3px rgba(0,0,0,0.06); text-align:left;">
      <div style="font-family:'Times New Roman', serif; font-weight:bold; font-size:15px; color:#1e293b; margin-bottom:4px;">${l.title}</div>
      <div style="font-family:'Courier New', monospace; font-size:12px; color:#475569;">${l.desc}</div>
    </div>
    ${idx === layers.length - 1 ? '' : '<div style="text-align:center; font-size:18px; color:#64748b; line-height:1; margin:-6px 0 6px 0;">&#8595;</div>'}
  `).join('');

  return `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { margin:0; padding:24px; background:#ffffff; font-family:'Times New Roman', serif; }
      .container { width:680px; margin:0 auto; }
      .caption { text-align:center; font-style:italic; font-size:14px; margin-top:16px; color:#334155; }
    </style>
  </head>
  <body>
    <div class="container">
      ${boxHtml}
    </div>
  </body>
  </html>
  `;
}

async function generateAll() {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox']
  });
  const page = await browser.newPage();

  // 1. Fig 8.0 Overall Request Flow
  const arch80 = [
    { title: 'Client (React.js + Vite)', desc: 'Responsive Web SPA | Faculty & Admin Portals | Axios API Client | Lucide Icons', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (REST API + JWT Bearer)', desc: 'JSON payloads | Bearer <JWT_TOKEN> Authorization header | 401 Interceptor', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express.js Middleware Pipeline', desc: 'Helmet (HTTP hardening) | CORS | Morgan | Rate Limiter | auth.js (JWT verify) | authorizeRole.js', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers & Service Layer', desc: 'authController, hallController, bookingController, reportsController, timetableController, etc.', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Data Services & Business Logic', desc: 'conflictService, recurringService, auditService, notificationService, reportExportService', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Relational Database', desc: '14 Normalized Tables | InnoDB Engine | Connection Pooling (mysql2/promise) | ACID Transactions', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Overall Request Flow', '', arch80));
  const el80 = await page.$('.container');
  await el80.screenshot({ path: path.join(outDir, 'fig_8_0_request_flow.png') });

  // 2. Fig 8.2.A Auth Architecture
  const arch82 = [
    { title: 'Client (React)', desc: 'LoginForm.jsx | ChangePasswordModal.jsx | ProtectedRoute.jsx | LocalStorage Auth Token', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (Axios + JWT)', desc: 'POST /api/auth/login | POST /api/auth/change-password/send-otp | Bearer Header on Requests', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express Middleware', desc: 'rateLimiter.js (15 attempts/15 min) | auth.js (verify JWT, check role, validate token expiry)', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers', desc: 'authController.js (login, sendChangePasswordOtp, verifyChangePasswordOtp, changePassword)', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Security & Token Utilities', desc: 'bcrypt (salt rounds=12) | crypto.randomInt (6-digit OTP) | crypto.timingSafeEqual', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Tables', desc: 'staff (credentials, role, auth_version) | password_change_verifications (OTP hashes, expiry)', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Auth Architecture', '', arch82));
  const el82 = await page.$('.container');
  await el82.screenshot({ path: path.join(outDir, 'fig_8_2_a_auth_arch.png') });

  // 3. Fig 8.3.A Dept & Staff Architecture
  const arch83 = [
    { title: 'Client (React)', desc: 'FacultyManagement.jsx | AddFacultyModal.jsx | MasterDataManager.jsx (Departments)', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (Axios + JWT)', desc: 'GET/POST/PUT/DELETE /api/staff | GET/POST/PUT/DELETE /api/departments', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express Middleware', desc: 'auth.js (JWT authentication) | authorizeRole.js (admin role restriction)', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers', desc: 'staffController.js (getAllStaff, createStaff, updateStaff, deleteStaff, resetPassword)\ndepartmentController.js (getDepartments, createDepartment, updateDepartment, deleteDepartment)', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Data Validation & Hashing', desc: 'Unique email checks | Department code validation | Initial password bcrypt hashing (12 rounds)', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Tables', desc: 'departments (DeptID, DeptName, DeptCode, IsActive) | staff (staff_id, full_name, email, role, dept)', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Dept Architecture', '', arch83));
  const el83 = await page.$('.container');
  await el83.screenshot({ path: path.join(outDir, 'fig_8_3_a_dept_staff_arch.png') });

  // 4. Fig 8.4.A Venue & Facility Architecture
  const arch84 = [
    { title: 'Client (React)', desc: 'VenueManagement.jsx | AddVenueModal.jsx | EditVenueModal.jsx | MasterDataManager (Types/Facilities)', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (Axios + JWT Multipart)', desc: 'GET/POST/PUT/DELETE /api/halls | GET/POST/PUT /api/venue-types | GET/POST/PUT /api/venue-facilities', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express Middleware', desc: 'auth.js | authorizeRole.js (admin) | multer (venue image upload storage handling)', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers', desc: 'hallController.js (getHalls, createHall, updateHall, deleteHall, toggleStatus)\nvenueTypeController.js | venueFacilityController.js', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Mapping & Transaction Layer', desc: 'venue_facility_mapping bridge table synchronization | Referential integrity checks with bookings', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Tables', desc: 'halls | venue_types | venue_facilities | venue_facility_mapping | departments', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Venue Architecture', '', arch84));
  const el84 = await page.$('.container');
  await el84.screenshot({ path: path.join(outDir, 'fig_8_4_a_venue_arch.png') });

  // 5. Fig 8.5.A Timetable Architecture
  const arch85 = [
    { title: 'Client (React)', desc: 'Timetable.jsx | Period Matrix Grid (P1–P8) | Venue & Day Selectors | Live Schedule Badges', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (Axios + JWT)', desc: 'GET /api/booking-availability/hall/:id/periods?date=YYYY-MM-DD | GET /api/halls/timetable', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express Middleware', desc: 'auth.js (JWT verify) | query validator (ISO date format validation)', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers & Service Layer', desc: 'bookingAvailabilityController.js | conflictService.js (academic period boundaries 09:15 to 17:15)', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Period Resolution Engine', desc: 'periods.js (Standard 8 College Periods Definition, lunch break and interval mapping)', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Tables', desc: 'bookings (date, time_from, time_to, status) | halls (HallID, HallName) | deptbookings', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Timetable Architecture', '', arch85));
  const el85 = await page.$('.container');
  await el85.screenshot({ path: path.join(outDir, 'fig_8_5_a_timetable_arch.png') });

  // 6. Fig 8.6.A Booking Architecture
  const arch86 = [
    { title: 'Client (React)', desc: 'BookVenue.jsx | Period Selection Grid | AI Recommendations | Recurring Booking Options', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (Axios + JWT)', desc: 'POST /api/bookings | POST /api/bookings/recurring | GET /api/bookings/my-bookings', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express Middleware', desc: 'auth.js (extracts staffId and role from JWT) | validate.js (input constraints)', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers', desc: 'bookingController.js (createBooking, getMyBookings, checkAvailability, cancelOwnBooking)', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Domain Services', desc: 'conflictService.js (atomic slot clash check) | recurringService.js | auditService.js', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Tables', desc: 'bookings (status=pending) | recurring_bookings | booking_audit_logs | notifications', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Booking Architecture', '', arch86));
  const el86 = await page.$('.container');
  await el86.screenshot({ path: path.join(outDir, 'fig_8_6_a_booking_arch.png') });

  // 7. Fig 8.7.A Approval & Audit Architecture
  const arch87 = [
    { title: 'Client (React)', desc: 'AdminBookings.jsx | Status Tabs (Pending/Approved/Rejected/Cancelled) | BookingAuditModal.jsx', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (Axios + JWT)', desc: 'PUT /api/bookings/:id/status | POST /api/bookings/:id/cancel | GET /api/bookings/:id/audit-logs', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express Middleware', desc: 'auth.js | authorizeRole.js (admin privileges for approvals)', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers', desc: 'bookingController.js (updateBookingStatus, getBookingAuditLogs) | deptBookingController.js', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Audit & Notification Engine', desc: 'auditService.js (immutable log entries) | notificationService.js (in-app alerts & emails)', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Tables', desc: 'bookings (status transitions) | booking_audit_logs (history) | notifications (alerts)', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Approval Architecture', '', arch87));
  const el87 = await page.$('.container');
  await el87.screenshot({ path: path.join(outDir, 'fig_8_7_a_approval_arch.png') });

  // 8. Fig 8.8.A Dashboard & Reports Architecture
  const arch88 = [
    { title: 'Client (React)', desc: 'Dashboard.jsx | Reports.jsx | VenueAnalytics.jsx | Multi-filter controls | Export buttons', bg: '#EBF3FB', border: '#5B9BD5' },
    { title: 'HTTP (Axios + JWT)', desc: 'GET /api/dashboard/stats | GET /api/reports/data | GET /api/reports/export?format=xlsx|pdf', bg: '#EDEAF6', border: '#8064A2' },
    { title: 'Express Middleware', desc: 'auth.js | authorizeRole.js (admin role validation) | Query parser', bg: '#FFF8E7', border: '#D6B656' },
    { title: 'Controllers', desc: 'dashboardController.js (KPI counters, monthly trend)\nreportsController.js (aggregate summary, venue breakdown, department breakdown)\nanalyticsController.js', bg: '#EAF7EE', border: '#70AD47' },
    { title: 'Export & Document Engines', desc: 'ExcelJS (cell formatting, headers, auto-width) | PDFKit (custom A4 vector printable tables)', bg: '#FBEAEF', border: '#D9534F' },
    { title: 'MySQL Tables', desc: 'bookings, halls, departments, staff (aggregated queries with GROUP BY and date filters)', bg: '#F2F4F7', border: '#7F7F7F' }
  ];
  await page.setContent(renderBoxArchHtml('Dashboard Architecture', '', arch88));
  const el88 = await page.$('.container');
  await el88.screenshot({ path: path.join(outDir, 'fig_8_8_a_reports_arch.png') });

  console.log('Architecture diagrams rendered successfully!');
  await browser.close();
}

generateAll().catch(console.error);
