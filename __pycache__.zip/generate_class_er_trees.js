const path = require('path');
const fs = require('fs');
const puppeteer = require(path.join(__dirname, 'backend', 'node_modules', 'puppeteer-core'));

const outDir = path.resolve(__dirname, 'report_diagrams');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

async function generateAll() {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 1800, deviceScaleFactor: 2 });

  // 1. CLASS DIAGRAM (Chapter 4)
  console.log('Rendering Class Diagram...');
  const classDiagramHtml = `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { margin:0; padding:30px; background:#ffffff; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
      .diagram-container { width:1100px; margin:0 auto; background:#ffffff; padding:20px; border:1px solid #cbd5e1; border-radius:8px; }
      .title { text-align:center; font-family:'Times New Roman', serif; font-size:20px; font-weight:bold; margin-bottom:25px; color:#0f172a; }
      .grid { display:grid; grid-template-columns: repeat(3, 1fr); gap:20px; }
      .uml-class { border:1.5px solid #334155; border-radius:4px; background:#f8fafc; font-size:11px; box-shadow:2px 2px 5px rgba(0,0,0,0.08); }
      .class-header { background:#e2e8f0; padding:6px 10px; font-weight:bold; text-align:center; border-bottom:1.5px solid #334155; font-size:12px; color:#1e293b; }
      .class-stereotype { font-size:9px; font-weight:normal; color:#64748b; }
      .class-section { padding:8px 10px; border-bottom:1px solid #cbd5e1; }
      .class-section:last-child { border-bottom:none; background:#ffffff; }
      .attr { margin-bottom:3px; color:#334155; font-family:'Consolas', monospace; font-size:10.5px; }
      .method { margin-bottom:3px; color:#0f766e; font-family:'Consolas', monospace; font-size:10px; }
      .rel-note { grid-column: span 3; margin-top:15px; padding:12px; background:#eff6ff; border:1px dashed #3b82f6; border-radius:6px; font-size:11.5px; color:#1e40af; line-height:1.5; font-family:'Times New Roman', serif; }
    </style>
  </head>
  <body>
    <div class="diagram-container">
      <div class="title">HALL BOOKING SYSTEM — DETAILED UML CLASS DIAGRAM</div>
      <div class="grid">
        <!-- Staff -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Entity / Model&raquo;</div>Staff</div>
          <div class="class-section">
            <div class="attr">+ staff_id: INT [PK]</div>
            <div class="attr">+ email: VARCHAR(255) [UNI]</div>
            <div class="attr">+ password: VARCHAR(255)</div>
            <div class="attr">+ full_name: VARCHAR(255)</div>
            <div class="attr">+ department: VARCHAR(100)</div>
            <div class="attr">+ role: ENUM(admin, staff)</div>
            <div class="attr">+ phone: VARCHAR(30)</div>
            <div class="attr">+ designation: VARCHAR(150)</div>
            <div class="attr">+ employee_id: VARCHAR(100)</div>
            <div class="attr">+ is_first_login: BOOLEAN</div>
            <div class="attr">+ auth_version: INT</div>
          </div>
          <div class="class-section">
            <div class="method">+ login(email, password): Token</div>
            <div class="method">+ sendPasswordOtp(): void</div>
            <div class="method">+ verifyOtp(otp): ChangeToken</div>
            <div class="method">+ changePassword(newPass): void</div>
            <div class="method">+ getProfile(): StaffProfile</div>
          </div>
        </div>

        <!-- Hall -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Entity / Model&raquo;</div>Hall</div>
          <div class="class-section">
            <div class="attr">+ HallID: INT [PK]</div>
            <div class="attr">+ HallName: VARCHAR(100)</div>
            <div class="attr">+ Location: VARCHAR(255)</div>
            <div class="attr">+ Capacity: INT</div>
            <div class="attr">+ VenueType: VARCHAR(50)</div>
            <div class="attr">+ DeptID: INT [FK]</div>
            <div class="attr">+ HasAC: BOOLEAN</div>
            <div class="attr">+ HasProjector: BOOLEAN</div>
            <div class="attr">+ HasSmartBoard: BOOLEAN</div>
            <div class="attr">+ HasWiFi: BOOLEAN</div>
            <div class="attr">+ ActiveStatus: BOOLEAN</div>
            <div class="attr">+ NumberOfSystems: INT</div>
          </div>
          <div class="class-section">
            <div class="method">+ getAllHalls(filter): List&lt;Hall&gt;</div>
            <div class="method">+ getHallById(id): Hall</div>
            <div class="method">+ createHall(data): Hall</div>
            <div class="method">+ updateHall(id, data): void</div>
            <div class="method">+ toggleStatus(id, status): void</div>
          </div>
        </div>

        <!-- Booking -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Entity / Model&raquo;</div>Booking</div>
          <div class="class-section">
            <div class="attr">+ id: INT [PK]</div>
            <div class="attr">+ hall_id: INT [FK]</div>
            <div class="attr">+ staff_id: INT [FK]</div>
            <div class="attr">+ event_name: VARCHAR(255)</div>
            <div class="attr">+ reason: TEXT</div>
            <div class="attr">+ date: DATE</div>
            <div class="attr">+ time_from: TIME</div>
            <div class="attr">+ time_to: TIME</div>
            <div class="attr">+ status: VARCHAR(50)</div>
            <div class="attr">+ participants: INT</div>
            <div class="attr">+ remarks: TEXT</div>
            <div class="attr">+ recurring_group_id: VARCHAR(64)</div>
          </div>
          <div class="class-section">
            <div class="method">+ createBooking(req): Booking</div>
            <div class="method">+ checkAvailability(hall, date): bool</div>
            <div class="method">+ updateStatus(id, status): void</div>
            <div class="method">+ cancelBooking(id, reason): void</div>
            <div class="method">+ getAuditLogs(): List&lt;AuditLog&gt;</div>
          </div>
        </div>

        <!-- Department -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Entity / Model&raquo;</div>Department</div>
          <div class="class-section">
            <div class="attr">+ DeptID: INT [PK]</div>
            <div class="attr">+ DeptName: VARCHAR(100)</div>
            <div class="attr">+ DeptCode: VARCHAR(20) [UNI]</div>
            <div class="attr">+ IsActive: BOOLEAN</div>
            <div class="attr">+ CreatedAt: TIMESTAMP</div>
          </div>
          <div class="class-section">
            <div class="method">+ getDepartments(): List&lt;Dept&gt;</div>
            <div class="method">+ createDept(data): Department</div>
            <div class="method">+ updateDept(id, data): void</div>
            <div class="method">+ deleteDept(id): void</div>
          </div>
        </div>

        <!-- RecurringBooking -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Entity / Model&raquo;</div>RecurringBooking</div>
          <div class="class-section">
            <div class="attr">+ id: INT [PK]</div>
            <div class="attr">+ recurring_group_id: VARCHAR(64) [UNI]</div>
            <div class="attr">+ user_id: INT [FK]</div>
            <div class="attr">+ hall_id: INT [FK]</div>
            <div class="attr">+ start_date: DATE</div>
            <div class="attr">+ end_date: DATE</div>
            <div class="attr">+ weekdays: VARCHAR(100)</div>
            <div class="attr">+ period_number: INT</div>
            <div class="attr">+ total_occurrences: INT</div>
            <div class="attr">+ status: VARCHAR(50)</div>
          </div>
          <div class="class-section">
            <div class="method">+ createRecurring(data): RecGroup</div>
            <div class="method">+ validateAllOccurrences(): bool</div>
            <div class="method">+ cancelRecurringGroup(gid): void</div>
          </div>
        </div>

        <!-- BookingAuditLog -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Entity / Model&raquo;</div>BookingAuditLog</div>
          <div class="class-section">
            <div class="attr">+ id: INT [PK]</div>
            <div class="attr">+ booking_id: INT [FK]</div>
            <div class="attr">+ user_id: INT [FK]</div>
            <div class="attr">+ action: VARCHAR(50)</div>
            <div class="attr">+ old_status: VARCHAR(50)</div>
            <div class="attr">+ new_status: VARCHAR(50)</div>
            <div class="attr">+ details: TEXT</div>
            <div class="attr">+ created_at: TIMESTAMP</div>
          </div>
          <div class="class-section">
            <div class="method">+ logAction(bookingId, action, ...): void</div>
            <div class="method">+ getLogsByBooking(id): List&lt;Log&gt;</div>
          </div>
        </div>

        <!-- VenueType & Facility -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Master Dataset&raquo;</div>VenueType & Facility</div>
          <div class="class-section">
            <div class="attr">+ id: INT [PK]</div>
            <div class="attr">+ name: VARCHAR(100) [UNI]</div>
            <div class="attr">+ IsActive: BOOLEAN</div>
            <div class="attr">+ venue_facility_mapping: Bridge</div>
          </div>
          <div class="class-section">
            <div class="method">+ getVenueTypes(): List&lt;Type&gt;</div>
            <div class="method">+ getFacilities(): List&lt;Facility&gt;</div>
            <div class="method">+ syncVenueFacilities(venueId, ids)</div>
          </div>
        </div>

        <!-- Notification -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Notification System&raquo;</div>Notification</div>
          <div class="class-section">
            <div class="attr">+ id: INT [PK]</div>
            <div class="attr">+ user_id: INT [FK]</div>
            <div class="attr">+ title: VARCHAR(255)</div>
            <div class="attr">+ message: TEXT</div>
            <div class="attr">+ type: VARCHAR(50)</div>
            <div class="attr">+ related_booking_id: INT [FK]</div>
            <div class="attr">+ is_read: BOOLEAN</div>
          </div>
          <div class="class-section">
            <div class="method">+ notifyUser(uid, title, msg): void</div>
            <div class="method">+ markRead(id): void</div>
          </div>
        </div>

        <!-- PasswordChangeVerification -->
        <div class="uml-class">
          <div class="class-header"><div class="class-stereotype">&laquo;Security / OTP&raquo;</div>PasswordVerification</div>
          <div class="class-section">
            <div class="attr">+ id: INT [PK]</div>
            <div class="attr">+ staff_id: INT [FK]</div>
            <div class="attr">+ purpose: VARCHAR(50)</div>
            <div class="attr">+ otp_hash: VARCHAR(255)</div>
            <div class="attr">+ expires_at: DATETIME</div>
            <div class="attr">+ attempts: TINYINT</div>
            <div class="attr">+ change_token_hash: CHAR(64)</div>
          </div>
          <div class="class-section">
            <div class="method">+ createOtp(staffId): string</div>
            <div class="method">+ verifyOtp(staffId, otp): token</div>
          </div>
        </div>
      </div>

      <div class="rel-note">
        <strong>Domain Class Relationships:</strong><br/>
        &bull; 1 <code>Department</code> has many (1:N) <code>Halls</code> and many (1:N) <code>Staff</code> members.<br/>
        &bull; 1 <code>Staff</code> initiates many (1:N) <code>Bookings</code> and owns many (1:N) <code>RecurringBookings</code>.<br/>
        &bull; 1 <code>Hall</code> hosts many (1:N) <code>Bookings</code>; 1 <code>Hall</code> maps to many (M:N) <code>VenueFacilities</code> via bridge table.<br/>
        &bull; 1 <code>Booking</code> generates many (1:N) <code>BookingAuditLogs</code> and linked <code>Notifications</code> upon lifecycle updates.
      </div>
    </div>
  </body>
  </html>
  `;
  await page.setContent(classDiagramHtml);
  const classEl = await page.$('.diagram-container');
  await classEl.screenshot({ path: path.join(outDir, 'class_diagram.png') });

  // 2. ER DIAGRAM (Chapter 6)
  console.log('Rendering ER Diagram...');
  const erDiagramHtml = `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      body { margin:0; padding:30px; background:#ffffff; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
      .er-container { width:1150px; margin:0 auto; background:#ffffff; padding:25px; border:1px solid #cbd5e1; border-radius:8px; }
      .title { text-align:center; font-family:'Times New Roman', serif; font-size:20px; font-weight:bold; margin-bottom:20px; color:#0f172a; }
      .section-label { font-family:'Times New Roman', serif; font-size:14px; font-weight:bold; color:#1e3a8a; border-bottom:2px solid #3b82f6; padding-bottom:4px; margin:20px 0 14px 0; }
      .er-grid { display:grid; grid-template-columns: repeat(4, 1fr); gap:16px; }
      .er-table { border:1.5px solid #1e293b; border-radius:4px; background:#ffffff; font-size:10px; box-shadow:0 1px 4px rgba(0,0,0,0.06); }
      .table-header { background:#1e293b; color:#ffffff; padding:6px 8px; font-weight:bold; text-align:center; font-size:11px; }
      .pk { background:#eff6ff; font-weight:bold; color:#1d4ed8; }
      .fk { background:#fefce8; color:#b45309; }
      .table-row { padding:3px 6px; border-bottom:1px solid #f1f5f9; display:flex; justify-content:space-between; font-family:'Consolas', monospace; }
      .table-row:last-child { border-bottom:none; }
      .col-type { color:#64748b; font-size:9.5px; }
      .rel-box { margin-top:20px; padding:12px; background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; font-size:11.5px; color:#334155; font-family:'Times New Roman', serif; }
    </style>
  </head>
  <body>
    <div class="er-container">
      <div class="title">COLLEGE HALL BOOKING SYSTEM — RELATIONAL ENTITY RELATIONSHIP DIAGRAM</div>

      <div class="section-label">1. MASTER CLASSIFICATION & CORE ENTITIES</div>
      <div class="er-grid">
        <!-- departments -->
        <div class="er-table">
          <div class="table-header">departments</div>
          <div class="table-row pk"><span>DeptID</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row"><span>DeptName</span><span class="col-type">VARCHAR(100)</span></div>
          <div class="table-row"><span>DeptCode</span><span class="col-type">VARCHAR(20) [UNI]</span></div>
          <div class="table-row"><span>IsActive</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>CreatedAt</span><span class="col-type">TIMESTAMP</span></div>
        </div>

        <!-- venue_types -->
        <div class="er-table">
          <div class="table-header">venue_types</div>
          <div class="table-row pk"><span>id</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row"><span>name</span><span class="col-type">VARCHAR(100) [UNI]</span></div>
          <div class="table-row"><span>IsActive</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>created_at</span><span class="col-type">TIMESTAMP</span></div>
        </div>

        <!-- venue_facilities -->
        <div class="er-table">
          <div class="table-header">venue_facilities</div>
          <div class="table-row pk"><span>id</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row"><span>name</span><span class="col-type">VARCHAR(100) [UNI]</span></div>
          <div class="table-row"><span>IsActive</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>created_at</span><span class="col-type">TIMESTAMP</span></div>
        </div>

        <!-- staff -->
        <div class="er-table">
          <div class="table-header">staff</div>
          <div class="table-row pk"><span>staff_id</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row"><span>email</span><span class="col-type">VARCHAR(255) [UNI]</span></div>
          <div class="table-row"><span>password</span><span class="col-type">VARCHAR(255)</span></div>
          <div class="table-row"><span>full_name</span><span class="col-type">VARCHAR(255)</span></div>
          <div class="table-row"><span>department</span><span class="col-type">VARCHAR(100)</span></div>
          <div class="table-row"><span>role</span><span class="col-type">VARCHAR(255)</span></div>
          <div class="table-row"><span>phone</span><span class="col-type">VARCHAR(30)</span></div>
          <div class="table-row"><span>designation</span><span class="col-type">VARCHAR(150)</span></div>
          <div class="table-row"><span>employee_id</span><span class="col-type">VARCHAR(100)</span></div>
          <div class="table-row"><span>auth_version</span><span class="col-type">INT</span></div>
        </div>
      </div>

      <div class="section-label">2. VENUE CATALOG & MAPPING</div>
      <div class="er-grid">
        <!-- halls -->
        <div class="er-table" style="grid-column: span 2;">
          <div class="table-header">halls</div>
          <div class="table-row pk"><span>HallID</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row"><span>HallName</span><span class="col-type">VARCHAR(100)</span></div>
          <div class="table-row"><span>Location</span><span class="col-type">VARCHAR(255)</span></div>
          <div class="table-row"><span>Capacity</span><span class="col-type">INT</span></div>
          <div class="table-row"><span>VenueType</span><span class="col-type">VARCHAR(50)</span></div>
          <div class="table-row fk"><span>DeptID</span><span class="col-type">INT [FK &rarr; departments]</span></div>
          <div class="table-row"><span>HasAC</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>HasProjector</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>HasSmartBoard</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>HasWiFi</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>ActiveStatus</span><span class="col-type">TINYINT(1)</span></div>
          <div class="table-row"><span>NumberOfSystems</span><span class="col-type">INT</span></div>
        </div>

        <!-- venue_facility_mapping -->
        <div class="er-table">
          <div class="table-header">venue_facility_mapping</div>
          <div class="table-row pk fk"><span>venue_id</span><span class="col-type">INT [PK, FK &rarr; halls]</span></div>
          <div class="table-row pk fk"><span>facility_id</span><span class="col-type">INT [PK, FK &rarr; facilities]</span></div>
        </div>

        <!-- password_change_verifications -->
        <div class="er-table">
          <div class="table-header">password_verifications</div>
          <div class="table-row pk"><span>id</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row fk"><span>staff_id</span><span class="col-type">INT [FK &rarr; staff]</span></div>
          <div class="table-row"><span>purpose</span><span class="col-type">VARCHAR(50)</span></div>
          <div class="table-row"><span>otp_hash</span><span class="col-type">VARCHAR(255)</span></div>
          <div class="table-row"><span>expires_at</span><span class="col-type">DATETIME</span></div>
          <div class="table-row"><span>attempts</span><span class="col-type">TINYINT</span></div>
          <div class="table-row"><span>change_token_hash</span><span class="col-type">CHAR(64)</span></div>
        </div>
      </div>

      <div class="section-label">3. TRANSACTIONAL RESERVATIONS, AUDIT & NOTIFICATIONS</div>
      <div class="er-grid">
        <!-- bookings -->
        <div class="er-table" style="grid-column: span 2;">
          <div class="table-header">bookings</div>
          <div class="table-row pk"><span>id</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row fk"><span>hall_id</span><span class="col-type">INT [FK &rarr; halls]</span></div>
          <div class="table-row fk"><span>staff_id</span><span class="col-type">INT [FK &rarr; staff]</span></div>
          <div class="table-row"><span>event_name</span><span class="col-type">VARCHAR(255)</span></div>
          <div class="table-row"><span>reason</span><span class="col-type">TEXT</span></div>
          <div class="table-row"><span>date</span><span class="col-type">DATE</span></div>
          <div class="table-row"><span>time_from</span><span class="col-type">TIME</span></div>
          <div class="table-row"><span>time_to</span><span class="col-type">TIME</span></div>
          <div class="table-row"><span>status</span><span class="col-type">VARCHAR(50)</span></div>
          <div class="table-row"><span>participants</span><span class="col-type">INT</span></div>
          <div class="table-row"><span>remarks</span><span class="col-type">TEXT</span></div>
          <div class="table-row"><span>recurring_group_id</span><span class="col-type">VARCHAR(64)</span></div>
        </div>

        <!-- booking_audit_logs -->
        <div class="er-table">
          <div class="table-header">booking_audit_logs</div>
          <div class="table-row pk"><span>id</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row fk"><span>booking_id</span><span class="col-type">INT [FK &rarr; bookings]</span></div>
          <div class="table-row fk"><span>user_id</span><span class="col-type">INT [FK &rarr; staff]</span></div>
          <div class="table-row"><span>action</span><span class="col-type">VARCHAR(50)</span></div>
          <div class="table-row"><span>old_status</span><span class="col-type">VARCHAR(50)</span></div>
          <div class="table-row"><span>new_status</span><span class="col-type">VARCHAR(50)</span></div>
          <div class="table-row"><span>details</span><span class="col-type">TEXT</span></div>
          <div class="table-row"><span>created_at</span><span class="col-type">TIMESTAMP</span></div>
        </div>

        <!-- notifications -->
        <div class="er-table">
          <div class="table-header">notifications</div>
          <div class="table-row pk"><span>id</span><span class="col-type">INT [PK]</span></div>
          <div class="table-row fk"><span>user_id</span><span class="col-type">INT [FK &rarr; staff]</span></div>
          <div class="table-row"><span>title</span><span class="col-type">VARCHAR(255)</span></div>
          <div class="table-row"><span>message</span><span class="col-type">TEXT</span></div>
          <div class="table-row"><span>type</span><span class="col-type">VARCHAR(50)</span></div>
          <div class="table-row fk"><span>related_booking_id</span><span class="col-type">INT [FK &rarr; bookings]</span></div>
          <div class="table-row"><span>is_read</span><span class="col-type">TINYINT(1)</span></div>
        </div>
      </div>

      <div class="rel-box">
        <strong>Referential Integrity Constraints & Cascades:</strong><br/>
        &bull; <code>halls.DeptID &rarr; departments.DeptID</code> [ON DELETE RESTRICT]: Preserves academic department hall groupings.<br/>
        &bull; <code>venue_facility_mapping &rarr; halls & venue_facilities</code>: Composite primary key (venue_id, facility_id) resolving M:N venue amenity mapping.<br/>
        &bull; <code>bookings.hall_id &rarr; halls.HallID</code> & <code>bookings.staff_id &rarr; staff.staff_id</code>: Ensures valid venue and requester attribution.<br/>
        &bull; <code>booking_audit_logs.booking_id &rarr; bookings.id</code> [ON DELETE CASCADE]: Guarantees immutable audit trail linked directly to booking lifecycles.
      </div>
    </div>
  </body>
  </html>
  `;
  await page.setContent(erDiagramHtml);
  const erEl = await page.$('.er-container');
  await erEl.screenshot({ path: path.join(outDir, 'er_diagram.png') });

  // 3. FOLDER TREE DIAGRAMS (Section 8.1)
  console.log('Rendering Folder Structure Views...');
  function renderTreeHtml(title, treeText) {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { margin:0; padding:16px; background:#ffffff; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .box { width:520px; background:#1e1e1e; color:#cccccc; padding:14px 18px; border-radius:6px; font-family:'Consolas', monospace; font-size:12px; line-height:1.6; box-shadow:0 2px 6px rgba(0,0,0,0.15); }
        .tree-header { color:#9cdcfe; font-weight:bold; margin-bottom:8px; border-bottom:1px solid #333333; padding-bottom:4px; font-size:13px; }
        .folder { color:#e5c07b; font-weight:bold; }
        .file-js { color:#61afef; }
        .file-jsx { color:#e06c75; }
        .file-json { color:#98c379; }
        .file-env { color:#d19a66; }
      </style>
    </head>
    <body>
      <div class="box">
        <div class="tree-header">${title}</div>
        ${treeText}
      </div>
    </body>
    </html>
    `;
  }

  // Fig 8.1.1 Highlevel
  await page.setContent(renderTreeHtml('Hall_Booking-main (Root Project)', `
    <div><span class="folder">&#128194; .git/</span></div>
    <div><span class="folder">&#128194; backend/</span></div>
    <div><span class="folder">&#128194; frontend/</span></div>
    <div><span class="file-json">&#128196; package.json</span></div>
    <div><span class="file-json">&#128196; package-lock.json</span></div>
    <div><span class="file-js">&#128196; README.md</span></div>
    <div><span class="file-js">&#128196; TODO.md</span></div>
  `));
  const el811 = await page.$('.box');
  await el811.screenshot({ path: path.join(outDir, 'fig_8_1_1_highlevel.png') });

  // Fig 8.1.2 Backend
  await page.setContent(renderTreeHtml('backend/ (Modular Backend Architecture)', `
    <div><span class="folder">&#128194; config/</span></div>
    <div><span class="folder">&#128194; controllers/</span></div>
    <div><span class="folder">&#128194; middlewares/</span></div>
    <div><span class="folder">&#128194; migrations/</span></div>
    <div><span class="folder">&#128194; models/</span></div>
    <div><span class="folder">&#128194; routes/</span></div>
    <div><span class="folder">&#128194; services/</span></div>
    <div><span class="folder">&#128194; uploads/</span></div>
    <div><span class="folder">&#128194; utils/</span></div>
    <div><span class="file-env">&#128196; .env</span></div>
    <div><span class="file-json">&#128196; package.json</span></div>
    <div><span class="file-js">&#128196; server.js</span></div>
  `));
  const el812 = await page.$('.box');
  await el812.screenshot({ path: path.join(outDir, 'fig_8_1_2_backend.png') });

  // Fig 8.1.3 Config
  await page.setContent(renderTreeHtml('backend/config/', `
    <div><span class="file-js">&#128196; db.js</span> (MySQL Connection Pool & Database Configuration)</div>
    <div><span class="file-js">&#128196; periods.js</span> (Academic Timetable Periods 1-8 Configuration)</div>
  `));
  const el813 = await page.$('.box');
  await el813.screenshot({ path: path.join(outDir, 'fig_8_1_3_config.png') });

  // Fig 8.1.4 Controllers
  await page.setContent(renderTreeHtml('backend/controllers/', `
    <div><span class="file-js">&#128196; analyticsController.js</span></div>
    <div><span class="file-js">&#128196; authController.js</span></div>
    <div><span class="file-js">&#128196; bookingAvailabilityController.js</span></div>
    <div><span class="file-js">&#128196; bookingController.js</span></div>
    <div><span class="file-js">&#128196; chatbotController.js</span></div>
    <div><span class="file-js">&#128196; dashboardController.js</span></div>
    <div><span class="file-js">&#128196; departmentController.js</span></div>
    <div><span class="file-js">&#128196; deptBookingController.js</span></div>
    <div><span class="file-js">&#128196; hallController.js</span></div>
    <div><span class="file-js">&#128196; notificationController.js</span></div>
    <div><span class="file-js">&#128196; profileController.js</span></div>
    <div><span class="file-js">&#128196; reportsController.js</span></div>
    <div><span class="file-js">&#128196; staffController.js</span></div>
    <div><span class="file-js">&#128196; venueFacilityController.js</span></div>
    <div><span class="file-js">&#128196; venueTypeController.js</span></div>
  `));
  const el814 = await page.$('.box');
  await el814.screenshot({ path: path.join(outDir, 'fig_8_1_4_controllers.png') });

  // Fig 8.1.5 Middlewares
  await page.setContent(renderTreeHtml('backend/middlewares/', `
    <div><span class="file-js">&#128196; auth.js</span> (JWT Token Verification & Session Middleware)</div>
    <div><span class="file-js">&#128196; authorizeRole.js</span> (Role-Based Access Control Middleware)</div>
    <div><span class="file-js">&#128196; upload.js</span> (Multer Multipart Image Upload Middleware)</div>
    <div><span class="file-js">&#128196; validate.js</span> (Request Body Validation Middleware)</div>
  `));
  const el815 = await page.$('.box');
  await el815.screenshot({ path: path.join(outDir, 'fig_8_1_5_middleware.png') });

  // Fig 8.1.6 Models
  await page.setContent(renderTreeHtml('backend/models/ & services/', `
    <div><span class="folder">&#128194; models/</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; BookingAuditLog.js</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; Notification.js</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; RecurringBooking.js</span></div>
    <div><span class="folder">&#128194; services/</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; auditService.js</span> | <span class="file-js">conflictService.js</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; notificationService.js</span> | <span class="file-js">recurringService.js</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; reportExportService.js</span> (ExcelJS & PDFKit)</div>
  `));
  const el816 = await page.$('.box');
  await el816.screenshot({ path: path.join(outDir, 'fig_8_1_6_models.png') });

  // Fig 8.1.7 Frontend Folder
  await page.setContent(renderTreeHtml('frontend/ (React 18 + Vite SPA)', `
    <div><span class="folder">&#128194; public/</span></div>
    <div><span class="folder">&#128194; src/</span></div>
    <div><span class="file-js">&#128196; index.html</span></div>
    <div><span class="file-json">&#128196; package.json</span></div>
    <div><span class="file-js">&#128196; vite.config.js</span></div>
    <div><span class="file-js">&#128196; tailwind.config.js</span></div>
  `));
  const el817 = await page.$('.box');
  await el817.screenshot({ path: path.join(outDir, 'fig_8_1_7_frontend.png') });

  // Fig 8.1.8 frontend/src
  await page.setContent(renderTreeHtml('frontend/src/', `
    <div><span class="folder">&#128194; api/</span> (Axios REST API Client Modules)</div>
    <div><span class="folder">&#128194; assets/</span> (Static Icons and Images)</div>
    <div><span class="folder">&#128194; components/</span> (Reusable React Components)</div>
    <div><span class="folder">&#128194; layouts/</span> (AdminLayout, FacultyLayout)</div>
    <div><span class="folder">&#128194; pages/</span> (Application Views and Portals)</div>
    <div><span class="folder">&#128194; routes/</span> (ProtectedRoute.jsx)</div>
    <div><span class="file-jsx">&#128196; App.jsx</span> (Client-side Router)</div>
    <div><span class="file-js">&#128196; main.jsx</span> (Entry Point)</div>
    <div><span class="file-js">&#128196; index.css</span> (Tailwind Design Tokens)</div>
  `));
  const el818 = await page.$('.box');
  await el818.screenshot({ path: path.join(outDir, 'fig_8_1_8_src.png') });

  // Fig 8.1.9 frontend/src/pages
  await page.setContent(renderTreeHtml('frontend/src/pages/', `
    <div><span class="folder">&#128194; admin/</span> (Analytics, Reports)</div>
    <div><span class="folder">&#128194; faculty/</span> (Dashboard, BookVenue, MyBookings, Profile)</div>
    <div><span class="folder">&#128194; Dashboard/</span> (Admin Dashboard)</div>
    <div><span class="folder">&#128194; AdminBookings/</span> (Booking Approval Center)</div>
    <div><span class="folder">&#128194; VenueManagement/</span> (Halls, Types, Facilities)</div>
    <div><span class="folder">&#128194; FacultyManagement/</span> (Staff User Directory)</div>
    <div><span class="folder">&#128194; Timetable/</span> (Period Allocation Matrix)</div>
    <div><span class="folder">&#128194; Reports/</span> (Transactional Reports & Export)</div>
    <div><span class="folder">&#128194; Notifications/</span> (Notification Center)</div>
    <div><span class="file-jsx">&#128196; Homepage.jsx</span> (Authentication Page)</div>
  `));
  const el819 = await page.$('.box');
  await el819.screenshot({ path: path.join(outDir, 'fig_8_1_9_pages.png') });

  // Fig 8.1.10 routes and api
  await page.setContent(renderTreeHtml('frontend/src/routes/ & api/', `
    <div><span class="folder">&#128194; routes/</span></div>
    <div>&nbsp;&nbsp;<span class="file-jsx">&#128196; ProtectedRoute.jsx</span> (Auth & Role Guard)</div>
    <div><span class="folder">&#128194; api/</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; authApi.js</span> | <span class="file-js">bookingApi.js</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; hallApi.js</span> | <span class="file-js">staffApi.js</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; masterDataApi.js</span> | <span class="file-js">reportsApi.js</span></div>
    <div>&nbsp;&nbsp;<span class="file-js">&#128196; analyticsApi.js</span> | <span class="file-js">notificationApi.js</span></div>
  `));
  const el8110 = await page.$('.box');
  await el8110.screenshot({ path: path.join(outDir, 'fig_8_1_10_routes_api.png') });

  // Fig 8.1.11 components
  await page.setContent(renderTreeHtml('frontend/src/components/', `
    <div><span class="file-jsx">&#128196; LoginForm.jsx</span> (Credential and Password Handling)</div>
    <div><span class="file-jsx">&#128196; Navbar.jsx</span> | <span class="file-jsx">Footer.jsx</span></div>
    <div><span class="file-jsx">&#128196; Pagination.jsx</span> (Reusable Data Table Pagination)</div>
    <div><span class="folder">&#128194; bookings/</span> (BookingAuditModal.jsx)</div>
    <div><span class="folder">&#128194; faculty/</span> (BookingStatusBadge, FacultySidebar, FacultyTopbar)</div>
    <div><span class="folder">&#128194; layout/</span> (Sidebar.jsx, Topbar.jsx)</div>
    <div><span class="folder">&#128194; profile/</span> (ChangePasswordModal.jsx)</div>
  `));
  const el8111 = await page.$('.box');
  await el8111.screenshot({ path: path.join(outDir, 'fig_8_1_11_components.png') });

  console.log('All diagrams and folder tree visuals generated!');
  await browser.close();
}

generateAll().catch(console.error);
