const path = require('path');
const fs = require('fs');
const puppeteer = require(path.join(__dirname, 'backend', 'node_modules', 'puppeteer-core'));

const outDir = path.resolve(__dirname, 'report_screenshots');

async function main() {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox', '--window-size=1440,960']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 960 });

  // 1. Log in as admin
  await page.goto('http://localhost:5173/', { waitUntil: 'networkidle2' });
  await page.type('input[name="email"]', 'admin@nec.edu.in');
  await page.type('input[name="password"]', 'Admin@123');
  await page.click('button[type="submit"]');
  await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
  await new Promise(r => setTimeout(r, 2000));

  // Add Venue Modal
  console.log('Capturing Add Venue Modal...');
  await page.goto('http://localhost:5173/admin/venue-management', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const b = btns.find(x => x.textContent.includes('Add Venue'));
    if (b) b.click();
  });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '04_venue_add_modal.png') });

  // Admin Bookings - Click view details / audit log
  console.log('Capturing Booking Details & Audit Modal...');
  await page.goto('http://localhost:5173/admin/bookings', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 1500));
  await page.evaluate(() => {
    const eyeBtns = Array.from(document.querySelectorAll('button'));
    const eye = eyeBtns.find(x => x.querySelector('svg.lucide-eye') || x.title?.includes('View'));
    if (eye) eye.click();
  });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '10b_booking_detail_modal.png') });

  // Admin Bookings - Audit Log Modal
  console.log('Capturing Booking Audit Log Modal...');
  await page.evaluate(() => {
    // press escape first
    const closeBtn = document.querySelector('button[aria-label="Close"], button:has(svg.lucide-x)');
    if (closeBtn) closeBtn.click();
  });
  await new Promise(r => setTimeout(r, 500));
  await page.evaluate(() => {
    const auditBtns = Array.from(document.querySelectorAll('button'));
    const audit = auditBtns.find(x => x.querySelector('svg.lucide-history') || x.title?.includes('Audit'));
    if (audit) audit.click();
  });
  await new Promise(r => setTimeout(r, 1500));
  await page.screenshot({ path: path.join(outDir, '10c_booking_audit_modal.png') });

  // Reports - scroll down to show breakdown & export options
  console.log('Capturing Reports Breakdown...');
  await page.goto('http://localhost:5173/admin/reports', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  await page.evaluate(() => {
    window.scrollBy(0, 600);
  });
  await new Promise(r => setTimeout(r, 1000));
  await page.screenshot({ path: path.join(outDir, '13b_reports_breakdown.png') });

  // Log in as Faculty
  console.log('Switching to Faculty for Booking Form...');
  await page.evaluate(() => localStorage.clear());
  await page.goto('http://localhost:5173/', { waitUntil: 'networkidle2' });
  await page.type('input[name="email"]', 'alice@nec.edu.in');
  await page.type('input[name="password"]', 'Alice@123');
  await page.click('button[type="submit"]');
  await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
  await new Promise(r => setTimeout(r, 2000));

  // Faculty Book Venue page - scroll down to form
  await page.goto('http://localhost:5173/faculty/book-venue', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 2000));
  // Pick first venue from select or cards
  await page.evaluate(() => {
    const venueSelect = document.querySelector('select[name="venue"]') || document.querySelector('#venue');
    if (venueSelect && venueSelect.options.length > 1) {
      venueSelect.selectedIndex = 1;
      venueSelect.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });
  await new Promise(r => setTimeout(r, 1000));
  await page.evaluate(() => {
    window.scrollBy(0, 650);
  });
  await new Promise(r => setTimeout(r, 1000));
  await page.screenshot({ path: path.join(outDir, '18b_faculty_booking_form.png') });

  await browser.close();
  console.log('Extra screenshots captured successfully!');
}

main().catch(console.error);
