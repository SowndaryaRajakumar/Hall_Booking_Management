import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn
import os

doc = docx.Document()
section = doc.sections[0]
section.page_width = Inches(8.27)   # A4
section.page_height = Inches(11.69)
section.top_margin = Inches(0.55)
section.bottom_margin = Inches(0.55)
section.left_margin = Inches(0.65)
section.right_margin = Inches(0.65)

# Page border
sectPr = section._sectPr
pgBorders = parse_xml(
    '<w:pgBorders %s w:offsetFrom="page">'
    '<w:top w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '<w:left w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '<w:bottom w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '<w:right w:val="single" w:sz="6" w:space="24" w:color="000000"/>'
    '</w:pgBorders>' % nsdecls('w')
)
sectPr.append(pgBorders)

def add_title(text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(14)
    run = p.add_run(text)
    run.font.name = 'Times New Roman'
    run.font.size = Pt(14)
    run.font.bold = True
    return p

def add_heading_bold(text, space_before=6, space_after=4):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    run = p.add_run(text)
    run.font.name = 'Times New Roman'
    run.font.size = Pt(12)
    run.font.bold = True
    return p

def add_body_paragraph(text, space_after=10):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.2
    run = p.add_run(text)
    run.font.name = 'Times New Roman'
    run.font.size = Pt(10.5)
    return p

def add_code(text, font_size=9.2, space_after=8):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(text)
    run.font.name = 'Consolas'
    run.font.size = Pt(font_size)
    return p

# PAGE 1
add_title('College Hall Booking Management System using React, Node.js and Express')
add_heading_bold('Ex.no:15', space_before=0, space_after=4)
add_heading_bold('Date:', space_before=0, space_after=6)
add_heading_bold('Aim:', space_before=0, space_after=3)
add_body_paragraph(
    'To develop a College Hall Booking Management System using React, Node.js, and Express.js by implementing '
    'a REST API with user authentication, Role-Based Access Control, venue and booking CRUD operations, database '
    'integration, pagination, filtering, searching, sorting, timetable slot allocation, conflict detection, booking '
    'approval workflow, email/system notifications, audit logging, middleware, and comprehensive analytics report export functionality.'
)
add_heading_bold('Project Structure:', space_before=4, space_after=6)

# Side-by-side images in table
tbl = doc.add_table(rows=1, cols=2)
tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
for row in tbl.rows:
    for cell in row.cells:
        cell.width = Inches(3.4)
        tcPr = cell._tc.get_or_add_tcPr()
        tcBorders = parse_xml(r'<w:tcBorders %s><w:top w:val="none"/><w:left w:val="none"/><w:bottom w:val="none"/><w:right w:val="none"/></w:tcBorders>' % nsdecls('w'))
        tcPr.append(tcBorders)

p_left = tbl.cell(0, 0).paragraphs[0]
p_left.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_left.add_run().add_picture('ex15_assets/struct_frontend.png', width=Inches(3.3))

p_right = tbl.cell(0, 1).paragraphs[0]
p_right.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_right.add_run().add_picture('ex15_assets/struct_backend.png', width=Inches(3.3))

add_heading_bold('backend/index.js', space_before=10, space_after=4)
add_code(
'''import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { query, isDbConnected, testConnection } from './config/db.js';
import { ensureMasterData } from './migrations/ensureMasterData.js';
import authRoutes from './routes/auth.js';
import staffRoutes from './routes/staff.js';
import hallRoutes from './routes/halls.js';
import departmentRoutes from './routes/departments.js';
import venueTypeRoutes from './routes/venueTypes.js';
import venueFacilityRoutes from './routes/venueFacilities.js';'''
)

doc.add_page_break()

# PAGE 2
add_code(
'''import bookingRoutes from './routes/bookings.js';
import bookingAvailabilityRoutes from './routes/bookingAvailability.js';
import deptBookingRoutes from './routes/deptBookings.js';
import dashboardRoutes from './routes/dashboard.js';
import reportsRoutes from './routes/reports.js';
import chatbotRoutes from './routes/chatbot.js';
import profileRoutes from './routes/profile.js';
import notificationRoutes from './routes/notifications.js';
import analyticsRoutes from './routes/analytics.js';
import { startReminderScheduler } from './services/notificationService.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Global Middlewares
app.use(cors());
app.use(express.json());

// API Health Check & Database Status
app.get('/api/health-check', async (req, res) => {
  try {
    if (!isDbConnected()) await testConnection();
    const isLive = isDbConnected();
    return res.json({
      status: 'ok',
      connected: isLive,
      database: isLive ? 'connected' : 'mock',
      mode: isLive ? 'mysql' : 'in-memory-fallback',
      dbName: process.env.DB_NAME || 'hall_booking'
    });
  } catch (error) {
    return res.json({ status: 'ok', connected: false, database: 'mock' });
  }
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/venue-types', venueTypeRoutes);
app.use('/api/admin/venue-facilities', venueFacilityRoutes);
app.use('/api/venue-facilities', venueFacilityRoutes);
app.use('/api/halls', hallRoutes);
app.use('/api/venues', hallRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/admin-bookings', bookingRoutes);
app.use('/api/halls1', bookingAvailabilityRoutes);
app.use('/api/dept-bookings', deptBookingRoutes);'''
)

doc.add_page_break()

# PAGE 3
add_code(
'''app.use('/api/dashboard', dashboardRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/chatbot', chatbotRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/analytics', analyticsRoutes);

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[Server Error]', err);
  res.status(500).json({ success: false, message: 'Internal server error.' });
});

async function startServer() {
  try {
    await testConnection();
    await ensureMasterData();
    startReminderScheduler();
  } catch (dbErr) {
    console.log('[Server] Switched to high-availability in-memory mode:', dbErr.message);
  }
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on: http://localhost:${PORT}`);
  });
}
startServer();'''
)

add_heading_bold('backend/config/db.js', space_before=10, space_after=4)
add_code(
'''import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import { executeMockQuery } from './mockStore.js';

dotenv.config();

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD !== undefined ? process.env.DB_PASSWORD : '',
  database: process.env.DB_NAME || 'hall_booking',
  port: Number(process.env.DB_PORT) || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  connectTimeout: 2500
};

let pool = null;
let isMySqlAvailable = false;
let hasCheckedMySql = false;'''
)

doc.add_page_break()

# PAGE 4
add_code(
'''export function isDbConnected() {
  return isMySqlAvailable;
}

export async function testConnection() {
  try {
    const conn = await mysql.createConnection({
      host: dbConfig.host,
      user: dbConfig.user,
      password: dbConfig.password,
      port: dbConfig.port,
      connectTimeout: 2500
    });
    await conn.query('SELECT 1');
    await conn.end();
    isMySqlAvailable = true;
    if (!pool) pool = mysql.createPool(dbConfig);
    return true;
  } catch {
    isMySqlAvailable = false;
    return false;
  } finally {
    hasCheckedMySql = true;
  }
}

export function getPool() {
  if (!pool && isMySqlAvailable) pool = mysql.createPool(dbConfig);
  return pool;
}

export async function query(sql, params = []) {
  if (!hasCheckedMySql) await testConnection();
  if (isMySqlAvailable) {
    try {
      const p = getPool();
      if (p) {
        const [results] = await p.execute(sql, params);
        return results;
      }
    } catch (err) {
      if (['ECONNREFUSED', 'PROTOCOL_CONNECTION_LOST', 
'ER_NO_SUCH_TABLE'].includes(err.code)) {
        isMySqlAvailable = false;
      } else {
        throw err;
      }
    }
  }
  return executeMockQuery(sql, params);
}'''
)

doc.add_page_break()

# PAGE 5
add_code(
'''export default { getPool, query, isDbConnected, testConnection };'''
)

add_heading_bold('backend/middleware/authMiddleware.js', space_before=8, space_after=4)
add_code(
'''import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'hall_booking_jwt_secure_auth_token_key_2026';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

export function generateToken(user) {
  const payload = {
    id: user.staff_id,
    email: user.email,
    role: user.role,
    name: user.full_name,
    department: user.department,
    designation: user.designation || null,
    employeeId: user.employee_id || null
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

export function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;

  if (!token) {
    if (req.headers['x-user-role']) {
      req.user = {
        role: req.headers['x-user-role'],
        email: req.headers['x-user-email'] || 'admin@nec.edu.in',
        name: req.headers['x-user-name'] || 'Administrator'
      };
      return next();
    }
    return res.status(401).json({
      success: false,
      message: 'Access Denied: Missing JSON Web Token (JWT).'
    });
  }'''
)

doc.add_page_break()

# PAGE 6
add_code(
'''  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({
        success: false,
        message: 'Invalid or expired JSON Web Token (JWT).'
      });
    }
    req.user = decoded;
    next();
  });
}'''
)

add_heading_bold('backend/controllers/bookingController.js (Excerpt)', space_before=10, space_after=4)
add_code(
'''export async function createBooking(req, res) {
  try {
    const { hallId, selectedSlots, reason, participants = 50, remarks } = req.body;
    const bookingId = 'HB-' + Date.now();
    const timestamp = new Date().toISOString();

    // Map hall details and verify venue capacity
    const hallInfo = await query(
      'SELECT HallName, Capacity, DeptID FROM halls WHERE HallID = ? LIMIT 1',
      [hallId]
    );
    const hallName = hallInfo[0]?.HallName || 'Campus Venue';

    // Verify timetable slot conflict across selected periods
    const conflict = await query(
      `SELECT id FROM bookings
       WHERE hall_id = ? AND date = ? AND time_from = ? AND time_to = ?
       AND status IN ('Pending', 'Approved') LIMIT 1`,
      [hallId, selectedSlots[0].date, selectedSlots[0].timeFrom, selectedSlots[0].timeTo]
    );

    if (conflict.length > 0) {
      return res.status(409).json({ success: false, message: 'Timetable period slot conflict detected.' });
    }

    // Insert atomic reservation record
    await query(
      `INSERT INTO bookings (id, hall_id, staff_email, date, time_from, time_to, reason, participants, status, remarks, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)`,
      [bookingId, hallId, req.user.email, selectedSlots[0].date, selectedSlots[0].timeFrom, selectedSlots[0].timeTo, reason, participants, remarks, timestamp]
    );

    // Auto-dispatch notifications to admin and timetable coordinator
    await query(
      `INSERT INTO notifications (id, type, title, user_id, related_booking_id, created_at)
       VALUES (?, 'BOOKING_REQUEST', ?, ?, ?, ?)`,
      ['NOTIF-' + Date.now(), 'New Hall Booking Request: ' + hallName, req.user.id || 1, bookingId, timestamp]
    );

    return res.json({ success: true, bookingId, hallName, message: 'Hall booking request submitted successfully.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Error creating hall booking request.' });
  }
}'''
)

doc.add_page_break()

# PAGE 7
add_heading_bold('Output Screens:', space_before=0, space_after=8)
p_term = doc.add_paragraph()
p_term.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_term.paragraph_format.space_after = Pt(12)
p_term.add_run().add_picture('ex15_assets/screen_terminal.png', width=Inches(6.8))

p_dash = doc.add_paragraph()
p_dash.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_dash.paragraph_format.space_after = Pt(0)
p_dash.add_run().add_picture('report_screenshots/02_admin_dashboard.png', width=Inches(6.8))

doc.add_page_break()

# PAGE 8
p_api = doc.add_paragraph()
p_api.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_api.paragraph_format.space_after = Pt(8)
p_api.add_run().add_picture('ex15_assets/screen_api.png', width=Inches(6.6))

p_book = doc.add_paragraph()
p_book.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_book.paragraph_format.space_after = Pt(8)
p_book.add_run().add_picture('report_screenshots/10_admin_bookings.png', width=Inches(6.6))

add_heading_bold('Rubrics:', space_before=0, space_after=4)

rubrics_table = doc.add_table(rows=2, cols=7)
rubrics_table.alignment = WD_TABLE_ALIGNMENT.CENTER
headers = [
    'Problem\nUnderstanding\n& Approach\n(10)',
    'Implementation\n& Execution\n(15)',
    'Tool /\nTechnology\nUsage (10)',
    'Code Quality\n&\nDocumentation\n(5)',
    'Viva\n\n(5)',
    'Time\nManagement\n(5)',
    'Total\n\n(50)'
]
col_widths = [Inches(1.2), Inches(1.2), Inches(1.0), Inches(1.2), Inches(0.65), Inches(0.9), Inches(0.65)]

for i, h in enumerate(headers):
    cell = rubrics_table.cell(0, i)
    cell.text = h
    cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in cell.paragraphs[0].runs:
        r.font.name = 'Times New Roman'
        r.font.bold = True
        r.font.size = Pt(8.5)

for row in rubrics_table.rows:
    for i, cell in enumerate(row.cells):
        cell.width = col_widths[i]
        tcPr = cell._tc.get_or_add_tcPr()
        tcBorders = parse_xml(
            r'<w:tcBorders %s><w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
            r'<w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
            r'<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
            r'<w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/></w:tcBorders>' % nsdecls('w')
        )
        tcPr.append(tcBorders)

rubrics_table.rows[1].height = Pt(32)

add_heading_bold('Result:', space_before=8, space_after=3)
add_body_paragraph(
    'Thus, the College Hall Booking Management System was successfully developed using React, Node.js, and Express.js. '
    'The system successfully implemented authentication, Role-Based Access Control, JWT authorization, venue and booking '
    'CRUD operations, database integration, pagination, filtering, searching, sorting, timetable slot allocation, conflict '
    'detection, approval workflow, email/system notifications, audit logging, middleware, and comprehensive analytics report export functionality.',
    space_after=0
)

docx_path = os.path.abspath('EX_15_HALL_BOOKING_MANAGEMENT.docx')
doc.save(docx_path)
print('Saved DOCX to:', docx_path)
