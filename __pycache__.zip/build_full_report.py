import os
import sys
import json
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

from report_builder_helpers import (
    setup_page_layout, add_right_page_number, add_heading_styled,
    add_body_p, add_bullet_p, add_figure, add_table_data,
    BASE_DIR, SCREENSHOTS_DIR, DIAGRAMS_DIR, LOGO_PATH, SCHEMA_PATH
)

def build_report():
    print("Initializing document...")
    doc = docx.Document()

    # Load database schema
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema = json.load(f)

    # Base style setup
    style_normal = doc.styles['Normal']
    font = style_normal.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    font.color.rgb = RGBColor(0, 0, 0)

    # ---------------------------------------------------------------------------
    # SECTION 1: TITLE PAGE (No border, no page number)
    # ---------------------------------------------------------------------------
    sec1 = doc.sections[0]
    setup_page_layout(sec1, add_border=False)

    # Title Page Content (Page 1)
    p_t1 = doc.add_paragraph()
    p_t1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_t1.paragraph_format.space_before = Pt(36)
    p_t1.paragraph_format.space_after = Pt(8)
    r = p_t1.add_run("HALL BOOKING SYSTEM")
    r.font.name = "Times New Roman"
    r.font.size = Pt(16)
    r.font.bold = True

    p_t2 = doc.add_paragraph()
    p_t2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_t2.paragraph_format.space_before = Pt(4)
    p_t2.paragraph_format.space_after = Pt(28)
    r = p_t2.add_run("23CS54C – MODERN WEB TECHNOLOGIES")
    r.font.name = "Times New Roman"
    r.font.size = Pt(13)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_before = Pt(0)
    p_sub.paragraph_format.space_after = Pt(6)
    r = p_sub.add_run("Submitted by")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.italic = True

    p_stu = doc.add_paragraph()
    p_stu.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_stu.paragraph_format.space_before = Pt(0)
    p_stu.paragraph_format.space_after = Pt(28)
    r = p_stu.add_run("SOWNDARYA R 24104085")
    r.font.name = "Times New Roman"
    r.font.size = Pt(13)
    r.font.bold = True

    p_ful = doc.add_paragraph()
    p_ful.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_ful.paragraph_format.space_before = Pt(0)
    p_ful.paragraph_format.space_after = Pt(4)
    r = p_ful.add_run("In partial fulfillment for the award of the degree")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.italic = True

    p_of = doc.add_paragraph()
    p_of.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_of.paragraph_format.space_before = Pt(0)
    p_of.paragraph_format.space_after = Pt(6)
    r = p_of.add_run("of")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.italic = True

    p_deg = doc.add_paragraph()
    p_deg.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_deg.paragraph_format.space_before = Pt(0)
    p_deg.paragraph_format.space_after = Pt(4)
    r = p_deg.add_run("BACHELOR OF ENGINEERING/TECHNOLOGY")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.bold = True
    r.font.italic = True

    p_in = doc.add_paragraph()
    p_in.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_in.paragraph_format.space_before = Pt(0)
    p_in.paragraph_format.space_after = Pt(4)
    r = p_in.add_run("in")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.italic = True

    p_dep = doc.add_paragraph()
    p_dep.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_dep.paragraph_format.space_before = Pt(0)
    p_dep.paragraph_format.space_after = Pt(24)
    r = p_dep.add_run("COMPUTER SCIENCE AND ENGINEERING/ INFORMATION TECHNOLOGY")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.bold = True
    r.font.italic = True

    # Logo
    if os.path.exists(LOGO_PATH):
        p_logo = doc.add_paragraph()
        p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_logo.paragraph_format.space_before = Pt(0)
        p_logo.paragraph_format.space_after = Pt(16)
        r_logo = p_logo.add_run()
        r_logo.add_picture(LOGO_PATH, width=Inches(1.2))

    p_col = doc.add_paragraph()
    p_col.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_col.paragraph_format.space_before = Pt(0)
    p_col.paragraph_format.space_after = Pt(4)
    r = p_col.add_run("NATIONAL ENGINEERING COLLEGE")
    r.font.name = "Times New Roman"
    r.font.size = Pt(13)
    r.font.bold = True

    p_aff = doc.add_paragraph()
    p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_aff.paragraph_format.space_before = Pt(0)
    p_aff.paragraph_format.space_after = Pt(4)
    r = p_aff.add_run("(An Autonomous Institution affiliated to Anna University, Chennai)")
    r.font.name = "Times New Roman"
    r.font.size = Pt(11)
    r.font.bold = True

    p_loc = doc.add_paragraph()
    p_loc.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_loc.paragraph_format.space_before = Pt(0)
    p_loc.paragraph_format.space_after = Pt(14)
    r = p_loc.add_run("K.R.NAGAR, KOVILPATTI - 628503")
    r.font.name = "Times New Roman"
    r.font.size = Pt(11)
    r.font.bold = True

    p_date = doc.add_paragraph()
    p_date.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_date.paragraph_format.space_before = Pt(0)
    p_date.paragraph_format.space_after = Pt(0)
    r = p_date.add_run("OCTOBER - 2026")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.bold = True

    # ---------------------------------------------------------------------------
    # SECTION 2: BONAFIDE CERTIFICATE (Page 2, Box border, page number 1 at bottom right)
    # ---------------------------------------------------------------------------
    sec2 = doc.add_section()
    setup_page_layout(sec2, add_border=True)
    add_right_page_number(sec2)

    p_c1 = doc.add_paragraph()
    p_c1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_c1.paragraph_format.space_before = Pt(12)
    p_c1.paragraph_format.space_after = Pt(3)
    r = p_c1.add_run("NATIONAL ENGINEERING COLLEGE")
    r.font.name = "Times New Roman"
    r.font.size = Pt(13)
    r.font.bold = True

    p_c2 = doc.add_paragraph()
    p_c2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_c2.paragraph_format.space_before = Pt(0)
    p_c2.paragraph_format.space_after = Pt(3)
    r = p_c2.add_run("(An Autonomous Institution affiliated to Anna University, Chennai)")
    r.font.name = "Times New Roman"
    r.font.size = Pt(11)
    r.font.bold = True

    p_c3 = doc.add_paragraph()
    p_c3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_c3.paragraph_format.space_before = Pt(0)
    p_c3.paragraph_format.space_after = Pt(12)
    r = p_c3.add_run("K.R.NAGAR, KOVILPATTI - 628503")
    r.font.name = "Times New Roman"
    r.font.size = Pt(11)
    r.font.bold = True

    if os.path.exists(LOGO_PATH):
        p_clogo = doc.add_paragraph()
        p_clogo.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_clogo.paragraph_format.space_before = Pt(0)
        p_clogo.paragraph_format.space_after = Pt(16)
        r_clogo = p_clogo.add_run()
        r_clogo.add_picture(LOGO_PATH, width=Inches(1.2))

    p_cert = doc.add_paragraph()
    p_cert.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_cert.paragraph_format.space_before = Pt(6)
    p_cert.paragraph_format.space_after = Pt(24)
    r = p_cert.add_run("BONAFIDE CERTIFICATE")
    r.font.name = "Times New Roman"
    r.font.size = Pt(13)
    r.font.bold = True

    p_body = doc.add_paragraph()
    p_body.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p_body.paragraph_format.space_before = Pt(0)
    p_body.paragraph_format.space_after = Pt(36)
    p_body.paragraph_format.line_spacing = 1.35
    r = p_body.add_run("This is to certify that this project report, “")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r_bold = p_body.add_run("Hall Booking System")
    r_bold.font.name = "Times New Roman"
    r_bold.font.size = Pt(12)
    r_bold.font.bold = True
    r2 = p_body.add_run("”, is the bonafide work of ")
    r2.font.name = "Times New Roman"
    r2.font.size = Pt(12)
    r_stu = p_body.add_run("SOWNDARYA R(24104085)")
    r_stu.font.name = "Times New Roman"
    r_stu.font.size = Pt(12)
    r_stu.font.bold = True
    r3 = p_body.add_run(" who carried out the project work under my supervision.")
    r3.font.name = "Times New Roman"
    r3.font.size = Pt(12)

    p_guide = doc.add_paragraph()
    p_guide.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_guide.paragraph_format.space_before = Pt(20)
    p_guide.paragraph_format.space_after = Pt(40)
    r = p_guide.add_run("Course Instructor/Guide")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.bold = True

    p_viva = doc.add_paragraph()
    p_viva.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p_viva.paragraph_format.space_before = Pt(0)
    p_viva.paragraph_format.space_after = Pt(45)
    p_viva.paragraph_format.line_spacing = 1.2
    r = p_viva.add_run("Submitted to the ")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r_sub = p_viva.add_run("23CS54C – MODERN WEB TECHNOLOGIES")
    r_sub.font.name = "Times New Roman"
    r_sub.font.size = Pt(12)
    r_sub.font.bold = True
    r2 = p_viva.add_run(" Viva-Voce examination held at National Engineering College, K.R.Nagar, Kovilpatti on ____________")
    r2.font.name = "Times New Roman"
    r2.font.size = Pt(12)

    table_sign = doc.add_table(rows=1, cols=2)
    table_sign.alignment = WD_TABLE_ALIGNMENT.CENTER
    table_sign.autofit = False
    table_sign.rows[0].cells[0].width = Inches(3.2)
    table_sign.rows[0].cells[1].width = Inches(3.0)
    p_int = table_sign.rows[0].cells[0].paragraphs[0]
    p_int.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p_int.add_run("Internal Examiner")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.bold = True
    p_ext = table_sign.rows[0].cells[1].paragraphs[0]
    p_ext.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p_ext.add_run("Co Examiner")
    r.font.name = "Times New Roman"
    r.font.size = Pt(12)
    r.font.bold = True

    # ---------------------------------------------------------------------------
    # TABLE OF CONTENTS (Page 3)
    # ---------------------------------------------------------------------------
    doc.add_page_break()

    add_heading_styled(doc, "TABLE OF CONTENTS", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=18)

    p_thdr = doc.add_paragraph()
    p_thdr.paragraph_format.space_before = Pt(0)
    p_thdr.paragraph_format.space_after = Pt(8)
    r1 = p_thdr.add_run("CH NO   TITLE.....................................................................................................PAGE NO")
    r1.font.name = "Times New Roman"
    r1.font.size = Pt(11)
    r1.font.bold = True

    toc_items = [
        ("1", "INTRODUCTION", "3"),
        ("2", "OBJECTIVES", "4"),
        ("3", "DESCRIPTION", "5"),
        ("4", "CLASS DIAGRAM", "6"),
        ("5", "TABLE STRUCTURES", "7"),
        ("6", "ER DIAGRAM", "16"),
        ("7", "TECH STACK", "18"),
        ("8", "MODULES", "19"),
        ("9", "CONCLUSION", "70")
    ]

    for ch, title, pnum in toc_items:
        p_row = doc.add_paragraph()
        p_row.paragraph_format.space_before = Pt(0)
        p_row.paragraph_format.space_after = Pt(4)
        
        # Format aligned with dots
        leader_dots = "." * max(2, int(82 - len(ch) - len(title) - len(pnum)))
        line_str = f"{ch:<6} {title}{leader_dots}{pnum}"
        r = p_row.add_run(line_str)
        r.font.name = "Times New Roman"
        r.font.size = Pt(11)

    # ---------------------------------------------------------------------------
    # CHAPTER 1: INTRODUCTION (Page 4, Numbered 3)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 1", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "INTRODUCTION", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    add_body_p(doc, "In modern collegiate and university environments, effective management of institutional infrastructure—specifically seminar halls, smart auditoriums, conference rooms, computer laboratories, and specialized workshop venues—is critical to smooth daily operations. Academic institutions coordinate a relentless schedule of curricular lectures, symposia, placement recruitment drives, technical club symposiums, faculty development workshops, and administrative conferences across shared physical venues. Traditionally, handling venue requisitions through manual or paper-based methods is time-consuming, highly error-prone, lacks transparency, and frequently results in disastrous double-booking conflicts where multiple departments prepare for simultaneous events in the exact same facility.")

    add_body_p(doc, "There is an urgent necessity for a reliable, automated, digital solution that brings all venue scheduling, approval workflows, amenity management, and institutional reporting under one unified web platform. The College Hall Booking System is an enterprise-grade, full-stack web application meticulously engineered to digitize, automate, and streamline the complete lifecycle of institutional venue reservations across National Engineering College.")

    add_body_p(doc, "The system was developed to satisfy the rigorous operational demands of collegiate governance, establishing distinct role-based access for Administrators and Faculty members. Faculty members can check real-time hall availability, view comprehensive facility specifications (such as air conditioning, smart interactive boards, acoustic speaker setups, CCTV coverage, and system counts), reserve specific academic periods or custom time ranges, submit recurring semester timetable reservations, and track the progress of their requisitions in real time.")

    add_body_p(doc, "Simultaneously, administrators are empowered with robust management utilities: a dynamic executive dashboard providing live KPI statistics; unified Master Data management for departments, venues, venue types, and facility equipment; an intuitive approval queue for reviewing, confirming, rejecting, or cancelling booking requests with granular remarks; a visual academic period timetable matrix (Periods 1 through 8); an immutable booking audit trail; and multi-criteria transactional reporting with server-side Excel (.xlsx) and printable PDF document exports.")

    add_body_p(doc, "The application is built on modern web technologies comprising a React 18 single-page application powered by Vite and styled with Tailwind CSS on the frontend, and a Node.js v24 asynchronous server using Express.js v5 on the backend. Relational data is modeled and stored within a high-performance MySQL InnoDB database utilizing connection pooling via the mysql2/promise driver. Tokenized JSON Web Tokens (JWT) and Bcrypt cryptographic hashing safeguard all endpoints. This project report presents a complete technical overview of the system architecture, mathematical design baselines, database schema, REST API contracts, and user interface implementations.")

    # ---------------------------------------------------------------------------
    # CHAPTER 2: OBJECTIVES (Page 5, Numbered 4)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 2", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "OBJECTIVES", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    objectives = [
        ("To Digitize Campus Venue Operations: ", "Replace outdated paper-based requisition slips and physical register ledgers with an instant, centralized digital web reservation platform to enhance booking accuracy, administrative efficiency, and institutional accessibility."),
        ("To Centralize Master Data Governance: ", "Maintain structured, consistent, and validated master data records across academic departments, venue facilities, classifications (Classroom, Smart Classroom, Laboratory, Seminar Hall, Auditorium, Conference Room), and amenities (AC, Projector, Smart Board, WiFi, Speaker, Podium, White Board, CCTV)."),
        ("To Eliminate Scheduling Clashes and Double Bookings: ", "Enforce strict atomic database slot conflict detection, ensuring that no venue can be concurrently booked for overlapping time intervals or overlapping academic timetable periods."),
        ("To Enforce Role-Based Access Control (RBAC): ", "Secure all platform capabilities through JSON Web Token (JWT) stateless authentication and role-specific route guards, cleanly isolating administrative oversight privileges from faculty reservation self-service."),
        ("To Streamline the Reservation Approval Lifecycle: ", "Provide college administrators with an efficient request review portal to rapidly approve, reject, or cancel venue requisitions with recorded remarks, accompanied by automated status updates for requesters."),
        ("To Support Flexible Recurring Bookings: ", "Enable faculty coordinators to schedule repeating semester-long venue series (weekly or specific day patterns) in a single atomic transaction while automatically verifying availability across every future occurrence."),
        ("To Deliver Dynamic Reporting and Analytics: ", "Generate comprehensive multi-criteria transaction reports filtered by date ranges, departments, venues, faculty, and status, and provide streaming exports to Microsoft Excel (.xlsx via ExcelJS) and vector PDF documents."),
        ("To Provide Comprehensive Lifecycle Auditability: ", "Record every status modification, approval, rejection, and cancellation within an immutable booking audit log, capturing the user ID, timestamp, transition state, and contextual reason."),
        ("To Enforce Web Security and API Hardening: ", "Implement industry-standard defenses including HTTP header protection via Helmet, Cross-Origin Resource Sharing (CORS) controls, request rate limiting on authentication routes, and salted Bcrypt password hashing."),
        ("To Deploy a Scalable, Maintainable Architecture: ", "Adopt a decoupled, three-tier RESTful client-server architecture with modular controllers, dedicated service classes, and normalized relational storage, enabling seamless maintenance and long-term institutional scalability.")
    ]

    for title, desc in objectives:
        add_bullet_p(doc, desc, bold_prefix=title)

    # ---------------------------------------------------------------------------
    # CHAPTER 3: DESCRIPTION (Page 6, Numbered 5)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 3", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "DESCRIPTION", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    add_body_p(doc, "The Hall Booking System is an enterprise-grade full-stack web application developed to coordinate and automate campus venue scheduling, departmental event management, and institutional facility administration at National Engineering College. The application is architected around five major functional domains:")

    add_heading_styled(doc, "1. Master Data & Venue Catalog Management", level=3, space_before=8, space_after=3)
    add_body_p(doc, "This module establishes the foundational reference catalog for the entire college. Administrators maintain academic departments (with unique department codes like CS, IT, ME, ECE), venue classifications (Classroom, Smart Classroom, Laboratory, Seminar Hall, Auditorium, Conference Room), and individual amenities (Air Conditioning, Projectors, Smart Boards, WiFi, Speaker Systems, Podiums, White Boards, CCTV). Each physical hall record captures its operational location, seating capacity, number of computing systems, assigned department, active status, image asset, and mapped amenities via an associative bridge table. Maintaining structured master data ensures consistency across all booking forms and report filters.")

    add_heading_styled(doc, "2. Reservation & Period Scheduling Engine", level=3, space_before=8, space_after=3)
    add_body_p(doc, "The reservation engine enables faculty members to browse available venues, inspect real-time slot availability, and submit booking requisitions. The system natively understands collegiate timetables, mapping bookings to standard institutional periods (Periods 1 through 8, spanning 09:15 AM to 05:15 PM) or arbitrary custom time windows. When a reservation is submitted, an atomic conflict validation algorithm verifies that no overlapping confirmed or pending booking exists for that venue. Additionally, the recurring reservation sub-engine allows staff to schedule semester-long events spanning weeks or months while verifying all individual dates in sequence.")

    add_heading_styled(doc, "3. Administrative Workflow & Audit Trail", level=3, space_before=8, space_after=3)
    add_body_p(doc, "The administrative management module governs the transition of booking states from 'pending' to 'approved', 'rejected', or 'cancelled'. Administrators review event purpose, expected participant counts, requester contact information, and time requirements. Approvals and rejections are accompanied by optional administrative remarks. Crucially, every state transition is recorded in an immutable audit log table capturing the actor, timestamp, prior status, new status, and detailed context. Automatic in-app notifications alert faculty members immediately when their requests are evaluated.")

    add_heading_styled(doc, "4. Reports, Business Analytics & Document Export", level=3, space_before=8, space_after=3)
    add_body_p(doc, "The reporting module provides administrative leadership with transparent visibility into institutional resource utilization. Dynamic query filters allow filtering bookings across custom date ranges, departments, specific halls, faculty coordinators, and booking statuses. The system aggregates real-time metrics including venue utilization percentages, departmental reservation volumes, and status distributions. The report engine supports streaming downloads of multi-column Microsoft Excel (.xlsx) workbooks generated via ExcelJS and styled, printable PDF documents compiled via PDFKit.")

    add_heading_styled(doc, "5. Security, Authentication & Modular Deployment", level=3, space_before=8, space_after=3)
    add_body_p(doc, "System security is anchored on stateless JSON Web Token (JWT) authentication, password hashing using salted Bcrypt (cost factor 12), and request rate limiting on credential endpoints to deter brute-force attempts. A dedicated OTP-based verification mechanism allows faculty to securely change passwords with cryptographic tokens. The decoupled architecture pairs a React single-page application with an Express.js REST API server and MySQL database, ensuring high maintainability, responsive client interactions, and high throughput.")

    # ---------------------------------------------------------------------------
    # CHAPTER 4: CLASS DIAGRAM (Page 7, Numbered 6)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 4", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "CLASS DIAGRAM", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    class_img = os.path.join(DIAGRAMS_DIR, "class_diagram.png")
    add_figure(
        doc, class_img,
        caption_text="fig 4.1 Detailed UML Class Diagram of Hall Booking System",
        description_text="The UML Class Diagram illustrates the object-oriented architectural design of the Hall Booking System, delineating domain models, structural attributes, access visibilities, and controller method contracts. The Staff entity encapsulates user identity, credentials, roles (admin and staff), and password-reset workflows. The Hall entity models physical venues, linking to Department and mapping amenities via VenueFacility. The Booking entity coordinates reservation transactions, establishing relationships with Staff, Hall, BookingAuditLog, and Notification entities. RecurringBooking orchestrates multi-session group series, ensuring strict relational integrity across academic departments.",
        width=Inches(6.0)
    )

    # ---------------------------------------------------------------------------
    # CHAPTER 5: TABLE STRUCTURES (Pages 8-16, Numbered 7-15)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 5", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "TABLE STRUCTURES", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    headers_ch5 = ["Field", "Type", "Null", "Key", "Default", "Extra"]
    col_w_ch5 = [1.5, 1.4, 0.6, 0.6, 1.1, 1.0]

    # Order of tables
    ordered_tables = [
        ("staff", "Staff / Faculty Accounts Table"),
        ("users", "Legacy Users Authentication Table"),
        ("departments", "Academic Departments Master Table"),
        ("halls", "Venues and Halls Catalog Table"),
        ("venue_types", "Venue Classification Master Table"),
        ("venue_facilities", "Venue Facilities & Amenities Master Table"),
        ("venue_facility_mapping", "Venue Facility Mapping Bridge Table"),
        ("bookings", "Venue Reservations and Bookings Transaction Table"),
        ("deptbookings", "Departmental Academic Schedule Bookings Table"),
        ("recurring_bookings", "Recurring Series Bookings Management Table"),
        ("booking_audit_logs", "Booking Lifecycle Audit Trail Log Table"),
        ("password_change_verifications", "Password Verification and OTP Security Table"),
        ("notifications", "System and Booking Notifications Table")
    ]

    for tbl_name, tbl_title in ordered_tables:
        if tbl_name in schema:
            add_heading_styled(doc, f"{tbl_name.capitalize()} :", level=3, space_before=10, space_after=4)
            cols_data = []
            for col in schema[tbl_name]:
                cols_data.append([
                    col.get("Field", ""),
                    col.get("Type", ""),
                    col.get("Null", ""),
                    col.get("Key", ""),
                    col.get("Default", "NULL") if col.get("Default") is not None else "NULL",
                    col.get("Extra", "")
                ])
            add_table_data(doc, headers_ch5, cols_data, col_widths=[1.5, 1.4, 0.6, 0.6, 1.1, 1.0])

    # ---------------------------------------------------------------------------
    # CHAPTER 6: ER DIAGRAM (Pages 17-18, Numbered 16-17)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 6", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "ER DIAGRAM", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    er_img = os.path.join(DIAGRAMS_DIR, "er_diagram.png")
    add_figure(
        doc, er_img,
        caption_text="fig 6.1 Complete Entity Relationship Diagram of Hall Booking System",
        description_text="The Entity Relationship (ER) Diagram models the relational database architecture of the Hall Booking System, delineating entity boundaries, primary keys, foreign key constraints, and relational cardinalities across all 13 core tables. The schema establishes a clean separation between Master Classification entities (departments, venue_types, venue_facilities, staff) and Transactional entities (bookings, deptbookings, recurring_bookings). The associative table venue_facility_mapping implements a resolved many-to-many relationship between physical halls and facility amenities. Foreign key dependencies with ON DELETE CASCADE rules protect audit logs, notifications, and recurring occurrences from orphaned states upon parent entity updates.",
        width=Inches(6.0)
    )

    # ---------------------------------------------------------------------------
    # CHAPTER 7: TECH STACK (Page 19, Numbered 18)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 7", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "TECH STACK", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    add_heading_styled(doc, "7.1 TECH STACK", level=2, space_before=6, space_after=6)
    tech_stack_rows = [
        ["Frontend", "React.js 18 (Vite)", "Single-page application with modular, reactive UI and high-performance bundle loading"],
        ["Styling & Icons", "Tailwind CSS & Lucide Icons", "Utility-first CSS framework and lightweight, vector SVG iconography"],
        ["HTTP Client", "Axios & Fetch API", "RESTful communication with centralized JWT Bearer authentication interceptor"],
        ["Backend", "Node.js (v24) + Express.js v5", "Asynchronous, event-driven RESTful API server handling high concurrent requests"],
        ["Database", "MySQL (via mysql2/promise)", "Relational storage engine with pooled connections and ACID transaction guarantees"],
        ["Authentication", "JSON Web Tokens (JWT)", "Stateless, cryptographically signed token-based session management"],
        ["Security", "Helmet, CORS, bcrypt, crypto", "HTTP header protection, cross-origin restrictions, salt hashing, timing-safe compare"],
        ["Reports & Export", "ExcelJS & PDFKit", "Server-side streaming generation of formatted .xlsx workbooks and vector PDF reports"],
        ["Notifications", "Nodemailer", "Transactional email delivery for password-reset verification OTP codes"],
        ["Tooling & Runtime", "npm, nodemon, ESLint", "Developer tooling, hot module replacement, and strict ECMAScript linting"]
    ]
    add_table_data(doc, ["Layer", "Technology", "Purpose"], tech_stack_rows, col_widths=[1.5, 1.8, 2.9])

    add_heading_styled(doc, "7.2 ARCHITECTURE OVERVIEW", level=2, space_before=10, space_after=6)
    arch_overview_rows = [
        ["Model Layer", "MySQL + mysql2 Connection Pool", "Defines relational schema, enforces primary/foreign key integrity, executes atomic queries and transactions"],
        ["View Layer", "React.js + Tailwind CSS", "Renders component-driven user interfaces, manages client state, and interacts with REST endpoints via Axios"],
        ["Controller Layer", "Node.js + Express.js v5", "Receives HTTP requests, validates payloads, enforces role authorization, and coordinates domain service logic"]
    ]
    add_table_data(doc, ["Layer", "Technology", "Purpose"], arch_overview_rows, col_widths=[1.5, 1.8, 2.9])

    # ---------------------------------------------------------------------------
    # CHAPTER 8: MODULES (Pages 20-72, Numbered 19-71)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 8", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "MODULES", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    # 8.0 Design Approach
    add_heading_styled(doc, "8.0 Design Approach", level=2, space_before=8, space_after=6)
    add_body_p(doc, "Each module of the Hall Booking System is documented here the way a rigorous system design problem is solved: by walking through the same seven engineering steps in the same order, every time. This ensures that every functional domain is thoroughly explained, architecturally comparable, and grounded in concrete rationale rather than merely displaying user interface screens.")

    step_table_rows = [
        ["1. Functional requirements", "What must the module do?", "Section x.1"],
        ["2. Non-functional requirements", "How fast, how concurrent, how secure? Where does the CAP trade-off fall?", "Section x.2"],
        ["3. Tech stack", "Which tools suit this domain, and why?", "Section x.3"],
        ["4. Back-of-the-envelope", "How many users, requests, storage sizing, and database load?", "Section x.4"],
        ["5. Low-level architecture", "Which components exist and who talks to whom?", "Section x.5 (diagram + request flow)"],
        ["6. API design", "What is the exact HTTP contract between client and server?", "Section x.6"],
        ["7. DB design", "Which tables, primary keys, foreign keys, and indexes store the data?", "Section x.7"]
    ]
    add_table_data(doc, ["Step", "Question it answers", "Presented in each module as"], step_table_rows, col_widths=[1.8, 2.6, 1.8])

    add_heading_styled(doc, "Shared baseline for all modules", level=3, space_before=8, space_after=4, underline=True)
    add_body_p(doc, "Non-functional baseline: Every inbound HTTP request traverses Helmet (HTTP security headers), CORS, a strict JSON payload size limit, an in-memory IP rate limiter, and JWT authentication middleware before dispatching to a route controller. All persistent data lives in a unified MySQL database. In CAP theorem terms, the system deliberately favors Consistency over Availability (CP): two users can never observe conflicting versions of a venue booking or timetable period slot. Concurrent reservations for identical venues and times are serialized through database transactions and unique constraints. Timestamps and audit logs record every mutation for rigorous administrative compliance.")

    add_body_p(doc, "Sizing baseline (assumptions):")
    sizing_rows = [
        ["Faculty / Staff Users", "≈ 150 members", "Academic faculty and departmental coordinators (NEC campus)"],
        ["System Administrators", "≈ 5 officers", "Administrative office, estate officers, and timetable conveners"],
        ["Working days / year", "280 days", "Academic calendar excluding official holidays and semester breaks"],
        ["Requests per user / day", "≈ 40 requests", "Dashboard views, slot availability checks, timetable lookups, submissions"],
        ["Total requests / day", "155 × 40 ≈ 6,200", "Derived daily aggregate HTTP transaction volume"],
        ["Average request load", "6,200 ÷ 28,800 s ≈ 0.22 req/s", "Distributed over an 8-hour college working day"],
        ["Peak request load", "≈ 5–10 req/s", "Beginning of semesters and conference reservation rush windows"],
        ["Total Database Tables", "14 relational tables", "Active production MySQL schema"]
    ]
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], sizing_rows, col_widths=[2.0, 1.8, 2.4])

    add_body_p(doc, "A single Node.js runtime process and one managed MySQL InnoDB instance easily handle this workload with average latency under 45 ms. Because session state is stateless and encoded within signed JWT bearer tokens, additional Node.js instances can be effortlessly deployed behind an Nginx reverse proxy if campus user concurrency multiplies.")

    fig_80 = os.path.join(DIAGRAMS_DIR, "fig_8_0_request_flow.png")
    add_figure(
        doc, fig_80,
        caption_text="Fig 8.0 Overall request flow of the Hall Booking System",
        description_text="The overall request flow diagram depicts the journey of an HTTP transaction through the Hall Booking System architecture. Requests originated by the React single-page application travel across Axios with an attached JWT Bearer token, passing through Express security middlewares (Helmet, CORS, RateLimiter, and auth.js) before reaching dedicated domain controllers. Controllers leverage service modules for conflict detection and audit logging, dispatching SQL statements through the mysql2 connection pool to the underlying MySQL database.",
        width=Inches(5.6)
    )

    # 8.1 FOLDER STRUCTURE
    add_heading_styled(doc, "8.1 FOLDER STRUCTURE", level=2, space_before=14, space_after=6)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_1_highlevel.png"),
        caption_text="Fig 8.1.1 Highlevel view of project",
        description_text="The root directory structure of the Hall Booking System workspace exhibits a clean separation of concerns, partitioning the project into an isolated backend REST server, an independent frontend React single-page client, package manifests, and comprehensive documentation assets."
    )

    add_heading_styled(doc, "8.1.1 BACKEND FOLDER", level=3, space_before=10, space_after=4)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_2_backend.png"),
        caption_text="Fig 8.1.2 Backend Folder Structure – Overall organization of backend files showing modular architecture",
        description_text="The backend codebase follows a layered, modular Node.js/Express architecture, decoupling routing, controller dispatching, domain services, middleware filters, database migrations, and persistent storage uploads."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_3_config.png"),
        caption_text="Fig 8.1.3 config Folder structure",
        description_text="The backend config directory isolates core infrastructural definitions, containing db.js for MySQL connection pooling and periods.js for academic timetable period time-slot configurations."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_4_controllers.png"),
        caption_text="Fig 8.1.4 Controller Folder",
        description_text="The controllers directory encapsulates endpoint request handling across 15 dedicated controller modules, orchestrating authentication, venue catalog management, bookings, approvals, notifications, and analytics."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_5_middleware.png"),
        caption_text="Fig 8.1.5 Middleware Folder Structure",
        description_text="The middleware folder maintains reusable Express filters responsible for verifying JWT credentials (auth.js), enforcing role-based authorization (authorizeRole.js), validating schemas, and handling multipart image uploads."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_6_models.png"),
        caption_text="Fig 8.1.6 Model & Service Folder Structure",
        description_text="The models and services directories contain data models and core business logic, including conflictService.js for atomic schedule conflict detection and reportExportService.js for ExcelJS and PDFKit file compilation."
    )

    add_heading_styled(doc, "8.1.2 FRONTEND FOLDER", level=3, space_before=10, space_after=4)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_7_frontend.png"),
        caption_text="FIG 8.1.7 Structure of Frontend Folder",
        description_text="The frontend project is scaffolded using Vite and React 18, utilizing Tailwind CSS for styling tokens and maintaining complete static assets, public directories, and configuration manifests."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_8_src.png"),
        caption_text="Fig 8.1.8 Structure of frontend/src",
        description_text="The frontend/src directory organizes the presentation layer into dedicated modular folders for API services, reusable components, role layouts, page views, route guards, and utility functions."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_9_pages.png"),
        caption_text="Fig 8.1.9 Structure of frontend/src/pages Folder",
        description_text="The pages directory organizes the application's view hierarchy into administrative portals (Dashboard, VenueManagement, FacultyManagement, Timetable, Reports) and faculty self-service workspaces."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_10_routes_api.png"),
        caption_text="Fig 8.1.10 Structure of frontend/src/routes and frontend/src/api",
        description_text="The routes directory maintains the ProtectedRoute guard enforcing token and role validation, while the api directory centralizes Axios REST client modules communicating with corresponding backend endpoints."
    )
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_1_11_components.png"),
        caption_text="Fig 8.1.11 Structure of frontend/src/components",
        description_text="The components directory encapsulates reusable user interface widgets, including LoginForm, Pagination, BookingStatusBadge, and modal dialogs across layout sidebars and topbars."
    )

    # ---------------------------------------------------------------------------
    # 8.2 USER AUTHENTICATION & ACCESS CONTROL
    # ---------------------------------------------------------------------------
    add_heading_styled(doc, "8.2 USER AUTHENTICATION & ACCESS CONTROL", level=2, space_before=14, space_after=6)
    add_heading_styled(doc, "8.2.0 Purpose & Scope", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "Provides tokenized authentication, secure credential verification, and Role-Based Access Control (RBAC) across the college hall reservation platform, preventing unauthorized access and isolating administrative powers from faculty workflows.")

    add_heading_styled(doc, "8.2.1 Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "What the module must do:")
    add_bullet_p(doc, "A user signs in with email and password, receiving a cryptographically signed JWT bearer token and profile object (id, name, email, department, role, isFirstLogin).")
    add_bullet_p(doc, "Role-based authorization directs Administrators to /admin/dashboard and Faculty members to /faculty/dashboard upon successful sign-in.")
    add_bullet_p(doc, "First-time users with temporary passwords are required to change their credentials before continuing.")
    add_bullet_p(doc, "Faculty members can securely change passwords through an OTP-based verification flow requiring a 6-digit code delivered to their institutional email.")
    add_bullet_p(doc, "Client-side route guards (ProtectedRoute.jsx) redirect unauthenticated requests to the login screen and validate role permissions.")
    add_bullet_p(doc, "An auth_version counter on each user record invalidates existing tokens upon password resets, enforcing immediate re-authentication.")

    add_heading_styled(doc, "8.2.2 Non-Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "How well the module must do it:")
    add_bullet_p(doc, "Security: Passwords are encrypted using Bcrypt with 12 salt rounds; plaintext passwords are never persisted or returned via the API.")
    add_bullet_p(doc, "Brute-force defence: An IP-based rate limiter restricts consecutive authentication attempts on /api/auth/login to protect against dictionary attacks.")
    add_bullet_p(doc, "Session length: JWT access tokens carry a 24-hour expiration window, balancing security hygiene with seamless single-shift usage.")
    add_bullet_p(doc, "Latency target: Credential validation and signature generation execute in under 300 ms.")
    add_bullet_p(doc, "CAP trade-off: Consistency is prioritized—revoked credentials or password modifications take immediate effect on the very next HTTP transaction.")

    add_heading_styled(doc, "8.2.3 Tech Stack", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Concern", "Choice", "Why it fits this module"], [
        ["Password Hashing", "bcrypt (12 salt rounds)", "Cryptographically secure key derivation function resistant to GPU cracking"],
        ["Session Tokens", "JSON Web Tokens (JWT, 24 h)", "Stateless authentication avoiding server-side session lookup overhead"],
        ["Verification OTP", "crypto.randomInt (6-digit)", "Cryptographically secure pseudorandom number generation for verification"],
        ["Email Delivery", "Nodemailer", "Direct SMTP integration delivering verification codes to registered faculty emails"],
        ["Route Guard", "ProtectedRoute.jsx", "Client-side React router wrapper checking role and token validity before rendering"]
    ], col_widths=[1.5, 2.0, 2.7])

    add_heading_styled(doc, "8.2.4 Back-of-the-Envelope Estimation", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], [
        ["Total Faculty Accounts", "≈ 150 records", "Academic teaching staff across collegiate departments"],
        ["Daily Logins", "≈ 200 logins / day", "Staff accessing platform during working hours"],
        ["Peak Login Rate", "≈ 1–2 logins / s", "Morning shift commencement and event submission windows"],
        ["bcrypt Verification CPU", "≈ 75 ms per call", "Standard single-core CPU execution time for work factor 12"],
        ["Token Header Size", "≈ 220 bytes", "Compact base64url encoded payload containing role and identity"]
    ], col_widths=[2.0, 1.8, 2.4])

    add_heading_styled(doc, "8.2.5 Low-Level Architecture", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_2_a_auth_arch.png"),
        caption_text="Fig 8.2.A Low-level architecture – USER AUTHENTICATION & ACCESS CONTROL",
        description_text="The authentication architecture illustrates the credential verification pipeline. LoginForm dispatches POST requests to /api/auth/login. The controller validates credentials against Bcrypt hashes in the staff table and issues a 24-hour JWT token. The token is stored in localStorage and passed in Axios Bearer headers, where auth.js verifies signatures before delegating requests to protected controllers."
    )

    add_heading_styled(doc, "8.2.6 API Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Method", "Endpoint", "Purpose / contract"], [
        ["POST", "/api/auth/login (public)", "Body: email, password. Returns JWT bearer token and user profile object."],
        ["POST", "/api/auth/change-password/send-otp", "Protected. Generates and emails a 6-digit verification code with 5-min TTL."],
        ["POST", "/api/auth/change-password/verify-otp", "Protected. Body: otp. Validates OTP and returns a 10-minute passwordChangeToken."],
        ["PUT", "/api/auth/change-password", "Protected. Body: newPassword, passwordChangeToken. Updates password and increments auth_version."],
        ["GET", "/api/profile/me", "Protected. Returns authenticated user profile, designation, phone, and employee ID."]
    ], col_widths=[1.0, 2.4, 2.8])

    add_heading_styled(doc, "8.2.7 DB Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Table", "Keys & indexes", "Key columns"], [
        ["staff", "PK staff_id (auto)\nUNIQUE email", "email, password (bcrypt hash), full_name, department, role, is_first_login, auth_version, phone, designation, employee_id"],
        ["password_change_verifications", "PK id (auto)\nUNIQUE (staff_id, purpose)", "staff_id (FK), purpose, otp_hash, expires_at, attempts, change_token_hash, change_token_expires_at"]
    ], col_widths=[1.8, 1.8, 2.6])

    add_heading_styled(doc, "8.2.8 Screenshots", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "01_login.png"),
        caption_text="fig 8.2.1 User Login & Authentication Interface",
        description_text="The authentication screen presents a responsive login portal featuring the official National Engineering College campus background. Users enter their institutional email address and password to sign in. The interface incorporates client-side input validation, error messaging, and automated redirection based on the authenticated user's role."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "23_change_password_otp.png"),
        caption_text="fig 8.2.2 Password Change Verification & OTP Modal",
        description_text="The password change interface incorporates a multi-step cryptographic verification process. When a user requests a password update, the system dispatches a 6-digit one-time password to their registered email address. The modal captures the code, enforces attempt limits, and ensures only verified users can update their account credentials."
    )

    # ---------------------------------------------------------------------------
    # 8.3 DEPARTMENT & STAFF MANAGEMENT
    # ---------------------------------------------------------------------------
    add_heading_styled(doc, "8.3 DEPARTMENT & STAFF MANAGEMENT", level=2, space_before=14, space_after=6)
    add_heading_styled(doc, "8.3.0 Purpose & Scope", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "Administers academic department classifications and maintains the institutional faculty directory, regulating account creation, profile modifications, and departmental affiliations.")

    add_heading_styled(doc, "8.3.1 Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "What the module must do:")
    add_bullet_p(doc, "Maintain academic departments with unique department codes (e.g., CS, IT, ME, ECE, EE, CE, AI&DS).")
    add_bullet_p(doc, "Provide administrators with full CRUD capabilities over department records.")
    add_bullet_p(doc, "Onboard new faculty members by recording full name, institutional email, department, designation, employee ID, and contact phone number.")
    add_bullet_p(doc, "Assign initial temporary passwords and set the is_first_login flag for newly onboarded faculty.")
    add_bullet_p(doc, "Enable searching, filtering by department, and paginating through faculty records.")
    add_bullet_p(doc, "Allow administrators to edit faculty details, reassign roles, or reset account credentials.")

    add_heading_styled(doc, "8.3.2 Non-Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "How well the module must do it:")
    add_bullet_p(doc, "Data integrity: Unique constraints on email and department codes prevent duplicate entries.")
    add_bullet_p(doc, "Access control: Staff onboarding and department management endpoints are strictly restricted to the admin role via authorizeRole.js.")
    add_bullet_p(doc, "Response time: Paginated staff and department directory queries return within 40 ms.")

    add_heading_styled(doc, "8.3.3 Tech Stack", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Concern", "Choice", "Why it fits this module"], [
        ["Staff Management UI", "FacultyManagement.jsx + AddFacultyModal", "Responsive grid table with instant modal dialogs for record management"],
        ["Master Data UI", "MasterDataManager.jsx", "Reusable CRUD component managing academic departments and metadata"],
        ["Password Initialization", "bcrypt (12 rounds)", "Generates secure initial password hashes during faculty onboarding"],
        ["Persistence", "MySQL (departments & staff)", "Relational tables with foreign key relationships and unique indexes"]
    ], col_widths=[1.5, 2.0, 2.7])

    add_heading_styled(doc, "8.3.4 Back-of-the-Envelope Estimation", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], [
        ["Academic Departments", "7 active departments", "Live schema records (CS, EE, ME, CE, IT, AI&DS, ECE)"],
        ["Faculty Directory Size", "≈ 150 members", "Institutional faculty size (< 100 KB total storage)"],
        ["Query Payload", "≈ 8 KB per page", "10 staff records per page including department and contact metadata"]
    ], col_widths=[2.0, 1.8, 2.4])

    add_heading_styled(doc, "8.3.5 Low-Level Architecture", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_3_a_dept_staff_arch.png"),
        caption_text="Fig 8.3.A Low-level architecture – DEPARTMENT & STAFF MANAGEMENT",
        description_text="The Department and Staff Management architecture coordinates faculty directory maintenance. Administrators interact with FacultyManagement.jsx and AddFacultyModal.jsx, issuing authenticated requests to staffController and departmentController. The system enforces unique constraints on email and department codes, applying 12-round Bcrypt hashing during credential initialization."
    )

    add_heading_styled(doc, "8.3.6 API Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Method", "Endpoint", "Purpose / contract"], [
        ["GET", "/api/departments", "List all active academic departments with codes."],
        ["POST", "/api/departments", "Admin only. Body: DeptName, DeptCode. Creates a new academic department."],
        ["PUT", "/api/departments/:id", "Admin only. Updates department name, code, or active status."],
        ["GET", "/api/staff", "Admin only. Query: page, limit, search, department. Returns paginated staff directory."],
        ["POST", "/api/staff", "Admin only. Body: full_name, email, department, designation, employee_id, phone, role."],
        ["PUT", "/api/staff/:id", "Admin only. Updates faculty profile, designation, phone, or assigned role."],
        ["POST", "/api/staff/:id/reset-password", "Admin only. Generates temporary password for faculty account."]
    ], col_widths=[1.0, 2.4, 2.8])

    add_heading_styled(doc, "8.3.7 DB Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Table", "Keys & indexes", "Key columns"], [
        ["departments", "PK DeptID (auto)\nUNIQUE DeptCode", "DeptName varchar(100), DeptCode varchar(20), IsActive tinyint(1), CreatedAt, UpdatedAt"],
        ["staff", "PK staff_id (auto)\nUNIQUE email", "email, password, full_name, department, role, phone, designation, employee_id, is_first_login"]
    ], col_widths=[1.8, 1.8, 2.6])

    add_heading_styled(doc, "8.3.8 Screenshots", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "05_manage_departments.png"),
        caption_text="fig 8.3.1 Department Master Management",
        description_text="The Department Master interface enables administrators to maintain academic departments. The panel displays active department names and official codes alongside controls for adding, editing, and activating or deactivating departments used across the booking system."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "08_faculty_management.png"),
        caption_text="fig 8.3.2 Faculty & Staff Management Directory",
        description_text="The Faculty Directory displays institutional staff accounts in a structured data table. The register features search by name or email, department filter dropdowns, designation badges, role indicators, and dedicated action controls for editing profiles and managing credentials."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "09_faculty_add_modal.png"),
        caption_text="fig 8.3.3 Add Faculty Account Modal",
        description_text="The Add Faculty dialog captures onboarding details including full name, institutional email, academic department, designation, employee ID, contact phone number, and access role. Submitting the form automatically provisions the account with secure temporary credentials."
    )

    # ---------------------------------------------------------------------------
    # 8.4 VENUE & FACILITY MASTER MANAGEMENT
    # ---------------------------------------------------------------------------
    add_heading_styled(doc, "8.4 VENUE & FACILITY MASTER MANAGEMENT", level=2, space_before=14, space_after=6)
    add_heading_styled(doc, "8.4.0 Purpose & Scope", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "Administers physical venues, classifications, equipment amenities, and facility capabilities across campus, providing an accurate catalog for reservation scheduling.")

    add_heading_styled(doc, "8.4.1 Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "What the module must do:")
    add_bullet_p(doc, "Maintain physical venue records including Hall Name, Location, Seating Capacity, Venue Type, Department, and Active Status.")
    add_bullet_p(doc, "Support venue classifications: Classroom, Smart Classroom, Laboratory, Computer Lab, Seminar Hall, Auditorium, Conference Room, Workshop.")
    add_bullet_p(doc, "Manage venue amenity capabilities: Air Conditioning, Projector, Smart Board, WiFi, Speaker System, Podium, White Board, CCTV.")
    add_bullet_p(doc, "Record specialized computing system counts (NumberOfSystems) for laboratory and workshop facilities.")
    add_bullet_p(doc, "Synchronize venue-amenity relationships using the associative venue_facility_mapping bridge table.")
    add_bullet_p(doc, "Upload and store venue images via Multer multipart storage handling.")
    add_bullet_p(doc, "Provide active/inactive status toggles to temporarily withdraw venues from public booking without deleting records.")

    add_heading_styled(doc, "8.4.2 Non-Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "How well the module must do it:")
    add_bullet_p(doc, "Image handling: Uploaded venue images are stored with unique timestamps to prevent file collisions.")
    add_bullet_p(doc, "Referential integrity: Venues with historical booking records cannot be abruptly deleted; foreign key constraints enforce safe archival.")
    add_bullet_p(doc, "Search latency: Venue lookups with amenity filters execute in under 25 ms.")

    add_heading_styled(doc, "8.4.3 Tech Stack", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Concern", "Choice", "Why it fits this module"], [
        ["Venue Management UI", "VenueManagement.jsx + Modals", "Comprehensive dashboard featuring search, status filtering, and master data tabs"],
        ["File Uploads", "Multer Middleware", "Handles multipart/form-data image uploads with disk storage in backend/uploads/venues"],
        ["Bridge Table Sync", "MySQL InnoDB Transactions", "Synchronizes venue_facility_mapping records atomically upon venue updates"]
    ], col_widths=[1.5, 2.0, 2.7])

    add_heading_styled(doc, "8.4.4 Back-of-the-Envelope Estimation", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], [
        ["Total Venues", "5 active halls", "Live catalog (lab1, lab2, lab3, lab9, f14)"],
        ["Venue Classifications", "8 venue types", "Classroom, Smart Classroom, Laboratory, Seminar Hall, Auditorium, etc."],
        ["Standard Amenities", "8 facility types", "AC, Projector, Smart Board, WiFi, Speaker, Podium, White Board, CCTV"]
    ], col_widths=[2.0, 1.8, 2.4])

    add_heading_styled(doc, "8.4.5 Low-Level Architecture", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_4_a_venue_arch.png"),
        caption_text="Fig 8.4.A Low-level architecture – VENUE & FACILITY MASTER MANAGEMENT",
        description_text="The Venue and Facility Master architecture coordinates the registration and maintenance of campus facilities. VenueManagement.jsx dispatches requests to hallController.js, venueTypeController.js, and venueFacilityController.js. Image uploads pass through Multer disk storage, while facility selections are saved to the venue_facility_mapping bridge table."
    )

    add_heading_styled(doc, "8.4.6 API Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Method", "Endpoint", "Purpose / contract"], [
        ["GET", "/api/halls", "Query: page, limit, status, search. Returns paginated venue catalog."],
        ["POST", "/api/halls", "Admin. Multipart: name, location, capacity, venueType, facilities, image. Creates hall."],
        ["PUT", "/api/halls/:id", "Admin. Updates hall parameters and synchronizes facility amenity mappings."],
        ["PATCH", "/api/halls/:id/status", "Admin. Toggles ActiveStatus between 1 (active) and 0 (inactive)."],
        ["GET", "/api/venue-types", "Lists all active venue classification types."],
        ["GET", "/api/venue-facilities", "Lists all available facility amenities and equipment options."]
    ], col_widths=[1.0, 2.4, 2.8])

    add_heading_styled(doc, "8.4.7 DB Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Table", "Keys & indexes", "Key columns"], [
        ["halls", "PK HallID (auto)\nFK DeptID → departments", "HallName, Location, Capacity, VenueType, DeptID, HasAC, HasProjector, HasWiFi, HasSmartBoard, ActiveStatus, NumberOfSystems, ImageURL"],
        ["venue_types", "PK id (auto)\nUNIQUE name", "name varchar(100), IsActive tinyint(1), created_at, updated_at"],
        ["venue_facilities", "PK id (auto)\nUNIQUE name", "name varchar(100), IsActive tinyint(1), created_at, updated_at"],
        ["venue_facility_mapping", "PK (venue_id, facility_id)", "venue_id (FK → halls.HallID), facility_id (FK → venue_facilities.id)"]
    ], col_widths=[1.8, 1.8, 2.6])

    add_heading_styled(doc, "8.4.8 Screenshots", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "03_venue_management.png"),
        caption_text="fig 8.4.1 Venue Management Master Directory",
        description_text="The Venue Management screen displays the campus hall inventory with location, seating capacity, venue classification, amenity tags, and active status toggles. Administrators can search, filter, edit, or provision new facilities directly from this view."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "04_venue_add_modal.png"),
        caption_text="fig 8.4.2 Add New Venue Master Dialog",
        description_text="The Add Venue dialog captures comprehensive hall specifications, including hall name, location, seating capacity, venue type selector, computing system counts, image uploads, and interactive checkboxes for amenities such as AC, Projectors, and Smart Boards."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "06_manage_venue_types.png"),
        caption_text="fig 8.4.3 Venue Type Classification Master",
        description_text="The Venue Types management panel enables administrators to define and update venue categories, ensuring consistent terminology across event scheduling and booking recommendation filters."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "07_manage_facilities.png"),
        caption_text="fig 8.4.4 Venue Facility Amenities Master",
        description_text="The Facilities management panel maintains the master list of campus amenities (such as Air Conditioning, Smart Boards, CCTV, and Audio Systems) available for assignment to physical venues."
    )

    # ---------------------------------------------------------------------------
    # 8.5 TIMETABLE & PERIOD SCHEDULE MANAGEMENT
    # ---------------------------------------------------------------------------
    add_heading_styled(doc, "8.5 TIMETABLE & PERIOD SCHEDULE MANAGEMENT", level=2, space_before=14, space_after=6)
    add_heading_styled(doc, "8.5.0 Purpose & Scope", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "Coordinates the collegiate academic period matrix, mapping reservations to standardized timetable periods (P1 through P8) and preventing scheduling clashes with curricular lectures.")

    add_heading_styled(doc, "8.5.1 Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "What the module must do:")
    add_bullet_p(doc, "Standardize the 8 official academic periods: P1 (09:15–10:05), P2 (10:05–10:50), P3 (11:10–12:00), P4 (12:00–12:50), P5 (01:50–02:40), P6 (02:40–03:30), P7 (03:45–04:30), P8 (04:30–05:15).")
    add_bullet_p(doc, "Display an interactive timetable grid mapping period allocations across selected dates and halls.")
    add_bullet_p(doc, "Calculate real-time period availability, returning occupied, pending, and free slots.")
    add_bullet_p(doc, "Allow venue filtering by department to review hall utilization across academic divisions.")

    add_heading_styled(doc, "8.5.2 Non-Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "How well the module must do it:")
    add_bullet_p(doc, "Interval accuracy: Period time boundaries strictly enforce interval breaks (10:50–11:10 AM, 12:50–01:50 PM lunch break, 03:30–03:45 PM).")
    add_bullet_p(doc, "Grid rendering speed: The multi-period matrix renders in under 50 ms.")

    add_heading_styled(doc, "8.5.3 Tech Stack", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Concern", "Choice", "Why it fits this module"], [
        ["Period Configuration", "backend/config/periods.js", "Standardized definitions for academic periods P1 to P8"],
        ["Availability Engine", "bookingAvailabilityController.js", "Resolves overlapping booking time spans into discrete period availability states"],
        ["Timetable UI", "Timetable.jsx", "Responsive grid displaying hall allocations across periods P1–P8"]
    ], col_widths=[1.5, 2.0, 2.7])

    add_heading_styled(doc, "8.5.4 Back-of-the-Envelope Estimation", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], [
        ["Academic Periods", "8 periods / day", "Official NEC collegiate timetable schedule"],
        ["Daily Period Slots", "5 halls × 8 = 40 slots", "Total available hall-period slots per academic day"],
        ["Timetable Lookup Size", "≈ 4 KB per query", "JSON array representing period status across all 5 halls"]
    ], col_widths=[2.0, 1.8, 2.4])

    add_heading_styled(doc, "8.5.5 Low-Level Architecture", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_5_a_timetable_arch.png"),
        caption_text="Fig 8.5.A Low-level architecture – TIMETABLE & PERIOD SCHEDULE MANAGEMENT",
        description_text="The Timetable architecture resolves booking time ranges against collegiate academic periods. Timetable.jsx queries bookingAvailabilityController.js with the selected date and hall. The controller compares requested times against period intervals defined in periods.js, querying active reservations to return slot statuses for the matrix display."
    )

    add_heading_styled(doc, "8.5.6 API Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Method", "Endpoint", "Purpose / contract"], [
        ["GET", "/api/booking-availability/hall/:id/periods", "Query: date. Returns occupied/free status for periods P1 through P8."],
        ["GET", "/api/halls/timetable", "Query: date, hallId. Returns complete daily schedule matrix across all periods."]
    ], col_widths=[1.0, 2.4, 2.8])

    add_heading_styled(doc, "8.5.7 DB Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Table", "Keys & indexes", "Key columns"], [
        ["bookings", "PK id (auto)\nINDEX (hall_id, date, status)", "date, time_from, time_to, status, hall_id, staff_id, event_name"],
        ["halls", "PK HallID (auto)", "HallName, Location, Capacity, VenueType, DeptID, ActiveStatus"]
    ], col_widths=[1.8, 1.8, 2.6])

    add_heading_styled(doc, "8.5.8 Screenshots", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "12_admin_timetable.png"),
        caption_text="fig 8.5.1 Admin Timetable & Period Allocation Matrix",
        description_text="The Timetable screen displays a visual schedule matrix across collegiate academic periods (P1 to P8). Administrators can inspect day-by-day venue utilization, identify free periods, and detect scheduled bookings across halls."
    )

    # ---------------------------------------------------------------------------
    # 8.6 VENUE RESERVATION & BOOKING WORKFLOW
    # ---------------------------------------------------------------------------
    add_heading_styled(doc, "8.6 VENUE RESERVATION & BOOKING WORKFLOW", level=2, space_before=14, space_after=6)
    add_heading_styled(doc, "8.6.0 Purpose & Scope", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "Governs the venue reservation lifecycle for faculty coordinators, providing availability checking, slot booking, conflict prevention, and recurring reservation scheduling.")

    add_heading_styled(doc, "8.6.1 Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "What the module must do:")
    add_bullet_p(doc, "Faculty browse active venues with amenity specifications, capacity, and location details.")
    add_bullet_p(doc, "Interactive slot selection allows booking by academic period buttons (P1 to P8) or custom time ranges.")
    add_bullet_p(doc, "Smart venue recommendations suggest alternate halls matching date, period, and amenity criteria.")
    add_bullet_p(doc, "Booking form captures event name, purpose, date, time, expected participants, contact phone, and remarks.")
    add_bullet_p(doc, "Atomic conflict detection prevents overlapping bookings for identical venues and time windows.")
    add_bullet_p(doc, "Recurring reservation engine allows scheduling repeating weekly series across semester calendars.")
    add_bullet_p(doc, "My Bookings portal displays personal requisition history with status badges and cancellation actions.")

    add_heading_styled(doc, "8.6.2 Non-Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "How well the module must do it:")
    add_bullet_p(doc, "Atomicity: Conflict detection and booking creation execute inside a single MySQL transaction to eliminate race conditions.")
    add_bullet_p(doc, "Concurrency safety: Multiple concurrent submissions for the same venue are serialized; conflicting submissions receive HTTP 409 Conflict.")
    add_bullet_p(doc, "Submission speed: Booking validation, conflict checking, and persistence complete in under 80 ms.")

    add_heading_styled(doc, "8.6.3 Tech Stack", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Concern", "Choice", "Why it fits this module"], [
        ["Reservation UI", "BookVenue.jsx", "Interactive booking workspace with period buttons, recommendation engine, and forms"],
        ["Conflict Engine", "conflictService.js", "Validates time window overlaps against existing confirmed and pending bookings"],
        ["Recurring Engine", "recurringService.js", "Generates recurring occurrence dates and validates availability across each date"],
        ["Personal Tracking", "MyBookings.jsx", "Faculty view with status badges, search, and self-cancellation controls"]
    ], col_widths=[1.5, 2.0, 2.7])

    add_heading_styled(doc, "8.6.4 Back-of-the-Envelope Estimation", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], [
        ["Total Bookings to Date", "58 bookings", "Live database records in bookings table"],
        ["Daily Reservations", "≈ 5–15 bookings / day", "Average departmental event submissions"],
        ["Storage per Booking", "≈ 0.8 KB / record", "Header metadata, time bounds, event details, and remarks"],
        ["Yearly Storage", "≈ 3.5 MB / year", "Calculated over 4,200 annual reservation transactions"]
    ], col_widths=[2.0, 1.8, 2.4])

    add_heading_styled(doc, "8.6.5 Low-Level Architecture", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_6_a_booking_arch.png"),
        caption_text="Fig 8.6.A Low-level architecture – VENUE RESERVATION & BOOKING WORKFLOW",
        description_text="The Venue Reservation architecture details the requisition flow. BookVenue.jsx submits reservation parameters to bookingController.js. The controller invokes conflictService.js to verify that the venue has no overlapping bookings. Upon successful validation, the booking record is created, an entry is written to booking_audit_logs, and an alert is dispatched via notificationService."
    )

    add_heading_styled(doc, "8.6.6 API Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Method", "Endpoint", "Purpose / contract"], [
        ["POST", "/api/bookings", "Protected. Body: hall_id, date, time_from, time_to, event_name, reason, participants, remarks. Validates conflicts and creates booking."],
        ["POST", "/api/bookings/recurring", "Protected. Body: recurring parameters (weekdays, start_date, end_date). Creates recurring series."],
        ["GET", "/api/bookings/my-bookings", "Protected. Returns personal booking history for authenticated faculty member."],
        ["PUT", "/api/bookings/:id/cancel-own", "Protected. Allows faculty to cancel own pending or approved booking."]
    ], col_widths=[1.0, 2.4, 2.8])

    add_heading_styled(doc, "8.6.7 DB Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Table", "Keys & indexes", "Key columns"], [
        ["bookings", "PK id (auto)\nFK hall_id → halls\nFK staff_id → staff", "hall_id, staff_id, event_name, reason, date, time_from, time_to, status ('pending', 'approved', 'rejected', 'cancelled'), participants, remarks, recurring_group_id"],
        ["recurring_bookings", "PK id (auto)\nUNIQUE recurring_group_id", "recurring_group_id, user_id (FK), hall_id (FK), start_date, end_date, weekdays, total_occurrences, status"]
    ], col_widths=[1.8, 1.8, 2.6])

    add_heading_styled(doc, "8.6.8 Screenshots", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "18_faculty_book_venue.png"),
        caption_text="fig 8.6.1 Faculty Venue Reservation Workspace",
        description_text="The Faculty Venue Reservation screen displays available campus halls alongside location, capacity, and amenity tags. Faculty members can search by venue type, select target halls, and review facility features before booking."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "18b_faculty_booking_form.png"),
        caption_text="fig 8.6.2 Booking Period Slot Selection & Recommendation",
        description_text="The booking form captures event details including event name, date range, period slots (P1 to P8), custom times, participant counts, and purpose. The system displays real-time slot availability badges to prevent conflicts before submission."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "20_faculty_my_bookings.png"),
        caption_text="fig 8.6.3 Faculty My Bookings Management",
        description_text="The My Bookings portal provides faculty members with a consolidated view of their requisitions. Each entry displays hall name, date, time, event purpose, status badge (Pending, Approved, Rejected, Cancelled), and cancellation controls."
    )

    # ---------------------------------------------------------------------------
    # 8.7 BOOKING APPROVAL, CANCELLATION & AUDIT LOGGING
    # ---------------------------------------------------------------------------
    add_heading_styled(doc, "8.7 BOOKING APPROVAL, CANCELLATION & AUDIT LOGGING", level=2, space_before=14, space_after=6)
    add_heading_styled(doc, "8.7.0 Purpose & Scope", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "Provides administrators with review and authorization workflows for pending requisitions, records cancellation reasons, maintains an immutable audit log, and manages in-app notifications.")

    add_heading_styled(doc, "8.7.1 Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "What the module must do:")
    add_bullet_p(doc, "Administrators review all booking requisitions in a unified register filtered by status (All, Pending, Approved, Rejected, Cancelled).")
    add_bullet_p(doc, "Instant approval actions change booking status to 'approved' and notify the requester.")
    add_bullet_p(doc, "Rejection actions change status to 'rejected', recording administrative remarks and notifying the requester.")
    add_bullet_p(doc, "Cancellation actions change status to 'cancelled' with recorded administrative or user cancellation reasons.")
    add_bullet_p(doc, "Every status update is logged in the booking_audit_logs table with user ID, prior status, new status, timestamp, and details.")
    add_bullet_p(doc, "Real-time in-app notifications inform faculty coordinators of approval or rejection decisions.")

    add_heading_styled(doc, "8.7.2 Non-Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "How well the module must do it:")
    add_bullet_p(doc, "Audit immutability: Audit log entries cannot be modified or deleted, preserving an accurate record for administrative compliance.")
    add_bullet_p(doc, "Status transition safety: Bookings can only transition through valid states (e.g., cancelled bookings cannot be approved without reopening).")
    add_bullet_p(doc, "Approval execution: Status updates, audit log writes, and notification dispatches commit together within a database transaction.")

    add_heading_styled(doc, "8.7.3 Tech Stack", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Concern", "Choice", "Why it fits this module"], [
        ["Approval UI", "AdminBookings.jsx", "Status-filtered register with action buttons for approving, rejecting, and viewing bookings"],
        ["Audit Log UI", "BookingAuditModal.jsx", "Modal displaying chronological lifecycle changes, timestamps, and actors"],
        ["Audit Service", "auditService.js", "Records structured audit entries into booking_audit_logs on every state modification"],
        ["Notification System", "notificationService.js", "Dispatches in-app notifications to staff accounts upon booking decisions"]
    ], col_widths=[1.5, 2.0, 2.7])

    add_heading_styled(doc, "8.7.4 Back-of-the-Envelope Estimation", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], [
        ["Audit Logs per Booking", "≈ 2–4 log entries", "Creation, review, approval/rejection, cancellation"],
        ["Yearly Audit Entries", "≈ 12,000 entries / year", "Calculated over 4,200 annual bookings (< 5 MB storage)"],
        ["Notification Delivery", "< 15 ms latency", "Local database write with instant client-side notification badge update"]
    ], col_widths=[2.0, 1.8, 2.4])

    add_heading_styled(doc, "8.7.5 Low-Level Architecture", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_7_a_approval_arch.png"),
        caption_text="Fig 8.7.A Low-level architecture – BOOKING APPROVAL, CANCELLATION & AUDIT LOGGING",
        description_text="The Approval and Audit architecture handles administrative review workflows. AdminBookings.jsx issues PUT requests to /api/bookings/:id/status. bookingController.js updates the booking state, invokes auditService.js to append an immutable record to booking_audit_logs, and dispatches a notification via notificationService.js."
    )

    add_heading_styled(doc, "8.7.6 API Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Method", "Endpoint", "Purpose / contract"], [
        ["GET", "/api/bookings", "Admin. Query: status, page, limit, search. Returns filtered bookings register."],
        ["PUT", "/api/bookings/:id/status", "Admin. Body: status ('approved'|'rejected'), remarks. Updates status, writes audit log, notifies user."],
        ["POST", "/api/bookings/:id/cancel", "Admin. Body: cancelReason. Cancels reservation, releases slot, writes audit entry."],
        ["GET", "/api/bookings/:id/audit-logs", "Admin. Returns chronological audit history for specified booking ID."],
        ["GET", "/api/notifications", "Protected. Returns in-app notifications for authenticated user."]
    ], col_widths=[1.0, 2.4, 2.8])

    add_heading_styled(doc, "8.7.7 DB Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Table", "Keys & indexes", "Key columns"], [
        ["booking_audit_logs", "PK id (auto)\nFK booking_id → bookings\nFK user_id → staff", "booking_id, user_id, action, old_status, new_status, details, created_at"],
        ["notifications", "PK id (auto)\nFK user_id → staff\nFK related_booking_id → bookings", "user_id, title, message, type, related_booking_id, is_read, created_at"]
    ], col_widths=[1.8, 1.8, 2.6])

    add_heading_styled(doc, "8.7.8 Screenshots", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "10_admin_bookings.png"),
        caption_text="fig 8.7.1 Admin Booking Request Management Register",
        description_text="The Admin Bookings register provides an overview of all campus reservation requests. Administrators can filter by status (All, Pending, Approved, Rejected, Cancelled), review event details, and execute approval or rejection actions."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "11_admin_bookings_pending.png"),
        caption_text="fig 8.7.2 Filtered Booking Queue & Approval Status",
        description_text="The filtered booking view isolates pending requisitions awaiting administrative review. Administrators can quickly verify event requirements, participant counts, and schedule details before approving or rejecting requests."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "10b_booking_detail_modal.png"),
        caption_text="fig 8.7.3 Booking Details & Verification Modal",
        description_text="The Booking Details modal displays comprehensive requisition information, including requester name, contact number, event purpose, date, time slots, and administrative remarks."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "10c_booking_audit_modal.png"),
        caption_text="fig 8.7.4 Comprehensive Booking Audit Trail Log",
        description_text="The Booking Audit modal displays an immutable chronological log of lifecycle actions. Each entry records the actor, timestamp, prior state, new state, and contextual remarks, ensuring accountability across all booking modifications."
    )

    # ---------------------------------------------------------------------------
    # 8.8 EXECUTIVE DASHBOARD, REPORTS & BUSINESS ANALYTICS
    # ---------------------------------------------------------------------------
    add_heading_styled(doc, "8.8 EXECUTIVE DASHBOARD, REPORTS & BUSINESS ANALYTICS", level=2, space_before=14, space_after=6)
    add_heading_styled(doc, "8.8.0 Purpose & Scope", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "Provides administrative intelligence through live KPI monitoring, departmental utilization analytics, and multi-criteria transactional reporting with Excel (.xlsx) and printable PDF exports.")

    add_heading_styled(doc, "8.8.1 Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "What the module must do:")
    add_bullet_p(doc, "Dashboard KPI metric cards: Total Halls, Total Bookings, Pending Approvals, Approved Events, Rejected Requisitions.")
    add_bullet_p(doc, "Personalized Faculty Dashboard: Displays My Bookings count, Pending Requests, Approved Venues, upcoming schedule, and quick action links.")
    add_bullet_p(doc, "Reports & Registers: Multi-filter engine supporting From Date, To Date, Venue, Department, Faculty Coordinator, and Booking Status.")
    add_bullet_p(doc, "Department Utilization Breakdown: Calculates total events, confirmed bookings, and usage percentages per academic division.")
    add_bullet_p(doc, "Venue Utilization Breakdown: Summarizes booking frequencies and hours utilized per campus hall.")
    add_bullet_p(doc, "Server-side Excel Export: Compiles and streams formatted .xlsx workbooks built via ExcelJS.")
    add_bullet_p(doc, "Printable PDF Export: Compiles vector printable PDF documents formatted via PDFKit.")
    add_bullet_p(doc, "Venue Analytics: Visualizes monthly booking trends, peak utilization hours, and capacity metrics.")

    add_heading_styled(doc, "8.8.2 Non-Functional Requirements", level=3, space_before=6, space_after=3, underline=True)
    add_body_p(doc, "How well the module must do it:")
    add_bullet_p(doc, "Query performance: Multi-table aggregate report queries execute in under 120 ms.")
    add_bullet_p(doc, "Streaming export: Excel and PDF exports stream directly via HTTP response pipes to prevent memory bottlenecks on large datasets.")
    add_bullet_p(doc, "Read consistency: Reports aggregate committed transactional data, accurately reflecting current database records.")

    add_heading_styled(doc, "8.8.3 Tech Stack", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Concern", "Choice", "Why it fits this module"], [
        ["Executive Dashboard", "Dashboard.jsx & FacultyDashboard.jsx", "Role-specific overview dashboards displaying KPI metrics and recent booking activities"],
        ["Reporting UI", "Reports.jsx", "Multi-filter reporting workspace with real-time summary statistics and export controls"],
        ["Excel Export Engine", "ExcelJS (server-side)", "Builds styled Microsoft Excel (.xlsx) workbooks with formatted headers, auto-widths, and cell borders"],
        ["PDF Export Engine", "PDFKit (server-side)", "Generates structured, vector printable PDF documents with custom margins and headers"],
        ["Analytics Engine", "VenueAnalytics.jsx & analyticsService.js", "Aggregates venue utilization trends and departmental booking statistics"]
    ], col_widths=[1.5, 2.0, 2.7])

    add_heading_styled(doc, "8.8.4 Back-of-the-Envelope Estimation", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Quantity", "Estimate", "Basis"], [
        ["Dashboard Query Load", "≈ 4 aggregate queries", "COUNT and GROUP BY queries on bookings and halls tables"],
        ["Generated Excel Size", "≈ 45 KB (.xlsx)", "Compressed workbook containing 200 formatted booking rows"],
        ["Generated PDF Size", "≈ 120 KB (.pdf)", "Vector PDF document with multi-page table formatting"],
        ["Export Response Time", "< 600 ms", "Server-side compilation and streaming to client"]
    ], col_widths=[2.0, 1.8, 2.4])

    add_heading_styled(doc, "8.8.5 Low-Level Architecture", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(DIAGRAMS_DIR, "fig_8_8_a_reports_arch.png"),
        caption_text="Fig 8.8.A Low-level architecture – EXECUTIVE DASHBOARD & BUSINESS ANALYTICS",
        description_text="The Dashboard and Reports architecture details the analytical data pipeline. Reports.jsx submits filter criteria (date range, venue, department, status) to reportsController.js. The controller executes aggregate queries across bookings, halls, and departments. When export is requested, reportExportService.js compiles the data into an ExcelJS workbook or PDFKit document and streams it directly to the client."
    )

    add_heading_styled(doc, "8.8.6 API Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Method", "Endpoint", "Purpose / contract"], [
        ["GET", "/api/dashboard/stats", "Admin. Returns KPI summary metrics: total venues, pending requests, approved, rejected."],
        ["GET", "/api/reports/data", "Admin. Query: fromDate, toDate, venueId, departmentId, status, search, page. Returns filtered data, department breakdown, and venue breakdown."],
        ["GET", "/api/reports/export", "Admin. Query: filters, format ('xlsx'|'pdf'). Streams compiled spreadsheet or PDF document to browser."],
        ["GET", "/api/analytics/venue-utilization", "Admin. Returns venue usage percentages and peak booking hours."],
        ["GET", "/api/analytics/department-bookings", "Admin. Returns distribution of reservations across academic departments."]
    ], col_widths=[1.0, 2.4, 2.8])

    add_heading_styled(doc, "8.8.7 DB Design", level=3, space_before=6, space_after=3, underline=True)
    add_table_data(doc, ["Table", "Keys & indexes", "Key columns"], [
        ["Aggregation Sources", "Read-only across 4 tables", "bookings (date, status, hall_id, staff_id), halls (HallID, HallName, Capacity), departments (DeptID, DeptName), staff (staff_id, full_name)"],
        ["Performance Indexes", "INDEX (date, status)\nINDEX (hall_id, date)", "Optimizes range filtering and departmental aggregations across large reservation datasets"]
    ], col_widths=[1.8, 1.8, 2.6])

    add_heading_styled(doc, "8.8.8 Screenshots", level=3, space_before=6, space_after=3, underline=True)
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "02_admin_dashboard.png"),
        caption_text="fig 8.8.1 Administrator Executive Dashboard",
        description_text="The Admin Dashboard provides a consolidated operational overview through KPI cards displaying total halls, pending requests, approved events, and rejected requisitions. It features quick-navigation shortcuts and a recent bookings ledger."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "17_faculty_dashboard.png"),
        caption_text="fig 8.8.2 Faculty Personalized Dashboard",
        description_text="The Faculty Dashboard presents personalized summary metrics: active bookings, pending requests, and upcoming events. Quick-action links allow faculty to initiate new reservations or view their booking history."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "13_admin_reports.png"),
        caption_text="fig 8.8.3 Comprehensive Booking Reports & Registers",
        description_text="The Reports screen provides a multi-criteria query interface with filters for date range, venue, department, faculty, and status. Action buttons allow instant streaming export to Excel (.xlsx) and printable PDF formats."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "13b_reports_breakdown.png"),
        caption_text="fig 8.8.4 Department & Venue Utilization Breakdown",
        description_text="The report breakdown tables present aggregated metrics by department and venue, displaying total reservations, confirmed events, and utilization percentages to assist institutional capacity planning."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "14_admin_analytics.png"),
        caption_text="fig 8.8.5 Venue Analytics & Usage Trends",
        description_text="The Venue Analytics dashboard visualizes campus facility utilization, booking distribution across departments, and peak reservation hours to support institutional scheduling decisions."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "15_admin_notifications.png"),
        caption_text="fig 8.8.6 System Notifications Center",
        description_text="The Notifications Center displays real-time alerts for booking submissions, approval decisions, and status updates, keeping users informed of requisition changes."
    )
    add_figure(
        doc, os.path.join(SCREENSHOTS_DIR, "16_admin_profile.png"),
        caption_text="fig 8.8.7 Administrator Profile & Security Settings",
        description_text="The Admin Profile view displays administrator account information, email address, role permissions, and logout controls."
    )

    # ---------------------------------------------------------------------------
    # CHAPTER 9: CONCLUSION (Page 73, Numbered 72)
    # ---------------------------------------------------------------------------
    doc.add_page_break()
    add_heading_styled(doc, "CHAPTER 9", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=16, space_after=2)
    add_heading_styled(doc, "CONCLUSION", level=1, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=0, space_after=16)

    add_body_p(doc, "The Hall Booking System delivers a comprehensive, modern digital solution for coordinating campus venue scheduling, departmental event management, and institutional facility administration at National Engineering College. By replacing manual paper slips, physical logbooks, and disconnected communication channels with an integrated web platform, the system significantly improves operational efficiency, booking accuracy, data transparency, and institutional resource utilization.")

    add_body_p(doc, "The application was engineered using React 18 with Vite and Tailwind CSS for the frontend, Node.js v24 and Express.js v5 for the backend REST API, and a normalized MySQL database managed through pooled connections with InnoDB ACID transaction support. Its modular client-server architecture enforces clean separation of concerns across routing, controllers, domain services, and persistent storage. Stateless JSON Web Token (JWT) authentication, salted Bcrypt password hashing (work factor 12), role-based route guards, request rate limiting, and cryptographic OTP-based password verification ensure robust web security.")

    add_body_p(doc, "Key operational milestones accomplished by the system include:")
    add_bullet_p(doc, "Elimination of Scheduling Clashes: Atomic database slot validation across custom times and standardized academic periods (P1 to P8) ensures zero double-booking conflicts across campus venues.")
    add_bullet_p(doc, "Streamlined Approval Workflows: Centralized administrative review queues enable rapid evaluation, approval, rejection with remarks, and cancellation of venue requisitions.")
    add_bullet_p(doc, "Complete Lifecycle Auditability: The immutable booking_audit_logs ledger captures every state transition, actor, and timestamp for institutional accountability.")
    add_bullet_p(doc, "Multi-Format Business Intelligence: Dynamic reporting allows administrators to filter records across multiple dimensions and stream exports to Microsoft Excel (.xlsx via ExcelJS) and printable PDF documents.")
    add_bullet_p(doc, "Support for Recurring Reservations: Faculty coordinators can schedule repeating semester series with automated conflict checks across all future dates.")

    add_body_p(doc, "Looking toward future enhancements, the platform's modular architecture readily accommodates advanced capabilities, including IoT-enabled smart venue energy management (automated lighting and HVAC activation upon booking check-in), QR-code door access integration, and automated SMS alert notifications. Overall, the Hall Booking System successfully meets all engineering objectives, delivering a secure, robust, and efficient venue management platform for National Engineering College.")

    # ---------------------------------------------------------------------------
    # SAVE DOCUMENT
    # ---------------------------------------------------------------------------
    output_docx = os.path.join(BASE_DIR, "FINAL_HALL_BOOKING_SYSTEM_REPORT.docx")
    print(f"Saving final report to {output_docx}...")
    doc.save(output_docx)
    print("Report saved successfully!")
    return output_docx

if __name__ == "__main__":
    build_report()
