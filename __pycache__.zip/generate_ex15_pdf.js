const path = require('path');
const fs = require('fs');
const puppeteer = require(path.join(__dirname, 'backend', 'node_modules', 'puppeteer-core'));

function toBase64(filePath) {
  const bitmap = fs.readFileSync(filePath);
  const ext = path.extname(filePath).replace('.', '');
  return `data:image/${ext === 'png' ? 'png' : 'jpeg'};base64,${bitmap.toString('base64')}`;
}

async function run() {
  const templatePath = path.resolve(__dirname, 'ex15_template.html');
  let html = fs.readFileSync(templatePath, 'utf8');

  const frontendImg = toBase64(path.resolve(__dirname, 'ex15_assets', 'struct_frontend.png'));
  const backendImg = toBase64(path.resolve(__dirname, 'ex15_assets', 'struct_backend.png'));
  const termImg = toBase64(path.resolve(__dirname, 'ex15_assets', 'screen_terminal.png'));
  const dashImg = toBase64(path.resolve(__dirname, 'report_screenshots', '02_admin_dashboard.png'));
  const apiImg = toBase64(path.resolve(__dirname, 'ex15_assets', 'screen_api.png'));
  const bookingsImg = toBase64(path.resolve(__dirname, 'report_screenshots', '10_admin_bookings.png'));

  html = html.replace('{{FRONTEND_IMG}}', frontendImg);
  html = html.replace('{{BACKEND_IMG}}', backendImg);
  html = html.replace('{{TERM_IMG}}', termImg);
  html = html.replace('{{DASH_IMG}}', dashImg);
  html = html.replace('{{API_IMG}}', apiImg);
  html = html.replace('{{BOOKINGS_IMG}}', bookingsImg);

  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox']
  });

  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle0' });

  const pdfPath = path.resolve(__dirname, 'EX_15_HALL_BOOKING_MANAGEMENT.pdf');
  await page.pdf({
    path: pdfPath,
    format: 'A4',
    preferCSSPageSize: true,
    printBackground: true
  });

  await browser.close();
  console.log('EX_15_HALL_BOOKING_MANAGEMENT.pdf created successfully at:', pdfPath);
}

run().catch(console.error);
