const express = require('express');
const router = express.Router();
const {
  getAllBookings,
  getBookingById,
  createBooking,
  updateBookingStatus,
  cancelBooking,
  getFacultyBookings,
  checkAvailability,
  getHallPeriodAvailability,
} = require('../controllers/bookingController');
const authenticateToken = require('../middlewares/authMiddleware');
router.get('/bookings', getAllBookings);
router.get('/my', getFacultyBookings);
router.post('/availability', checkAvailability);
router.get('/availability/:hallId', getHallPeriodAvailability);
router.get('/:id', getBookingById);
router.post('/', createBooking);
router.patch('/:id/status', updateBookingStatus);
router.patch('/:id/cancel', authenticateToken, cancelBooking);
module.exports = router;
