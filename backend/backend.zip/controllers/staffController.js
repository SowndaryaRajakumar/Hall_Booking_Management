const pool = require('../config/db');

// Get staff details by token
const getStaffDetails = async (req, res) => {
  try {
    const email = req.user.email; // From authentication middleware
    
    const [rows] = await pool.query(
      'SELECT staff_id, email, full_name, department, role, phone, designation, profile_image FROM staff WHERE email = ?',
      [email]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Staff not found'
      });
    }

    // Return normalized profile object
    const staff = rows[0];
    res.json({
      success: true,
      data: {
        staff_id: staff.staff_id,
        full_name: staff.full_name,
        email: staff.email,
        department: staff.department,
        role: staff.role,
        phone: staff.phone || null,
        designation: staff.designation || null,
        profile_image: staff.profile_image || null
      }
    });
  } catch (error) {
    console.error('Error fetching staff details:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

const getStaffStats = async (req, res) => {
  try {
    const staffEmail = req.user.email; // Assuming the email is part of the authenticated user's token
    const [stats] = await pool.query(
      `SELECT 
        COUNT(*) as totalBookings,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approvedBookings,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pendingBookings
      FROM bookings 
      WHERE staff_email = ?`,
      [staffEmail]
    );
    res.json({
      success: true,
      data: {
        totalBookings: parseInt(stats[0].totalBookings) || 0,
        approvedBookings: parseInt(stats[0].approvedBookings) || 0,
        pendingBookings: parseInt(stats[0].pendingBookings) || 0
      }
    });
  } catch (error) {
    console.error('Error fetching staff statistics:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};
const getAllStaff = async (req, res) => {
  try {

    const [rows] = await pool.query(`
      SELECT
        staff_id,
        full_name,
        email,
        department,
        role,
        is_first_login
      FROM staff
      ORDER BY full_name
    `);

    res.json({
      success: true,
      data: rows
    });

  } catch (error) {

    console.error("Error fetching staff:", error);

    res.status(500).json({
      success: false,
      message: "Internal Server Error"
    });

  }
};
const bcrypt = require("bcrypt");

const addStaff = async (req, res) => {
  try {
    const {
      full_name,
      email,
      department,
      role,
      password
    } = req.body;

    // Validation
    if (!full_name || !email || !department || !role || !password) {
      return res.status(400).json({
        success: false,
        message: "All fields are required"
      });
    }

    // Check if email already exists
    const [existing] = await pool.query(
      "SELECT staff_id FROM staff WHERE email = ?",
      [email]
    );

    if (existing.length > 0) {
      return res.status(400).json({
        success: false,
        message: "Email already exists"
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert staff
    await pool.query(
      `INSERT INTO staff
      (full_name,email,password,department,role,is_first_login)
      VALUES (?,?,?,?,?,0)`,
      [
        full_name,
        email,
        hashedPassword,
        department,
        role,
        false
      ]
    );

    res.status(201).json({
      success: true,
      message: "Faculty added successfully"
    });

  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Server Error"
    });
  }
};

const updateStaff = async (req, res) => {
  try {
    const { id } = req.params;
    const { full_name, email, department, role } = req.body;

    await pool.query(
      `UPDATE staff
       SET full_name = ?, email = ?, department = ?, role = ?
       WHERE staff_id = ?`,
      [full_name, email, department, role, id]
    );

    res.json({
      success: true,
      message: "Faculty updated successfully",
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "Failed to update faculty",
    });
  }
};
const deleteStaff = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if staff exists
    const [rows] = await pool.query(
      "SELECT * FROM staff WHERE staff_id = ?",
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Faculty not found",
      });
    }

    await pool.query(
      "DELETE FROM staff WHERE staff_id = ?",
      [id]
    );

    res.json({
      success: true,
      message: "Faculty deleted successfully",
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Failed to delete faculty",
    });
  }
};
module.exports = {
  getStaffDetails,
  getStaffStats,
  getAllStaff,
  addStaff,
  updateStaff,
  deleteStaff
};