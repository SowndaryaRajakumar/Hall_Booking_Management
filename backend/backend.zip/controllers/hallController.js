// controllers/hallController.js
const pool = require('../config/db');

const getBodyValue = (body, keys, fallback = "") => {
  for (const key of keys) {
    const value = body?.[key];
    if (value !== undefined && value !== null && value !== "") {
      return value;
    }
  }
  return fallback;
};

const parseBoolean = (value, fallback = false) => {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value === 1;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (["true", "1", "yes", "on"].includes(normalized)) return true;
    if (["false", "0", "no", "off"].includes(normalized)) return false;
  }
  return fallback;
};

const parseNumber = (value, fallback = 0) => {
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (trimmed === "") return fallback;
    const parsed = Number(trimmed);
    return Number.isFinite(parsed) ? parsed : fallback;
  }
  return fallback;
};

const normalizeHallRow = (hall = {}) => ({
  hallId: hall.HallID ?? hall.hallId ?? hall.id,
  hallName: hall.HallName ?? hall.hallName ?? hall.name ?? "",
  department: hall.DeptName ?? hall.department ?? "",
  deptId: hall.DeptID ?? hall.deptId ?? "",
  location: hall.Location ?? hall.location ?? "",
  capacity: hall.Capacity ?? hall.capacity ?? "",
  numberOfSystems: hall.NumberOfSystems ?? hall.numberOfSystems ?? 0,
  venueType: hall.VenueType ?? hall.venueType ?? "",
  hasProjector: Boolean(hall.HasProjector ?? hall.hasProjector),
  hasSmartBoard: Boolean(hall.HasSmartBoard ?? hall.hasSmartBoard),
  hasWiFi: Boolean(hall.HasWiFi ?? hall.hasWiFi),
  hasSpeaker: Boolean(hall.HasSpeaker ?? hall.hasSpeaker),
  hasPodium: Boolean(hall.HasPodium ?? hall.hasPodium),
  hasWhiteBoard: Boolean(hall.HasWhiteBoard ?? hall.hasWhiteBoard),
  hasCCTV: Boolean(hall.HasCCTV ?? hall.hasCCTV),
  hasAC: Boolean(hall.HasAC ?? hall.hasAC),
  microphoneType: hall.MicrophoneType ?? hall.microphoneType ?? "None",
  additionalFeatures: hall.AdditionalFeatures ?? hall.additionalFeatures ?? "",
  image: hall.ImageURL ?? hall.image ?? null,
  activeStatus: parseBoolean(hall.ActiveStatus ?? hall.activeStatus, true),
});

const normalizeHallPayload = (body = {}) => ({
  hallName: getBodyValue(body, ["hallName", "HallName", "name"], ""),
  location: getBodyValue(body, ["location", "Location"], ""),
  capacity: getBodyValue(body, ["capacity", "Capacity"], ""),
  deptId: getBodyValue(body, ["deptId", "DeptID", "deptID"], ""),
  venueType: getBodyValue(body, ["venueType", "VenueType"], ""),
  hasProjector: parseBoolean(getBodyValue(body, ["hasProjector", "HasProjector"], false), false),
  hasSmartBoard: parseBoolean(getBodyValue(body, ["hasSmartBoard", "HasSmartBoard"], false), false),
  hasWiFi: parseBoolean(getBodyValue(body, ["hasWiFi", "HasWiFi"], false), false),
  hasSpeaker: parseBoolean(getBodyValue(body, ["hasSpeaker", "HasSpeaker"], false), false),
  hasPodium: parseBoolean(getBodyValue(body, ["hasPodium", "HasPodium"], false), false),
  hasWhiteBoard: parseBoolean(getBodyValue(body, ["hasWhiteBoard", "HasWhiteBoard"], false), false),
  hasCCTV: parseBoolean(getBodyValue(body, ["hasCCTV", "HasCCTV"], false), false),
  hasAC: parseBoolean(getBodyValue(body, ["hasAC", "HasAC"], false), false),
  microphoneType: getBodyValue(body, ["microphoneType", "MicrophoneType"], "None"),
  additionalFeatures: getBodyValue(body, ["additionalFeatures", "AdditionalFeatures"], ""),
  activeStatus: parseBoolean(getBodyValue(body, ["activeStatus", "ActiveStatus"], true), true),
  numberOfSystems: parseNumber(getBodyValue(body, ["numberOfSystems", "NumberOfSystems"], 0), 0),
});

// Get all halls
exports.getAllHalls = async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        h.*,
        d.DeptName
      FROM Halls h
      LEFT JOIN Departments d
      ON h.DeptID = d.DeptID
      ORDER BY h.HallName ASC
    `);

    const halls = rows.map(normalizeHallRow);

    res.json({
      success: true,
      data: halls
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch venues"
    });
  }
};

// Get all active halls
exports.getActiveHalls = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM ActiveHallsView');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching active halls:', error);
    res.status(500).json({ error: 'Failed to fetch active halls' });
  }
};

// Get halls by department
exports.getHallsByDepartment = async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'CALL GetHallsByDepartment(?)',
      [req.params.deptId]
    );
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching halls:', error);
    res.status(500).json({ error: 'Failed to fetch halls' });
  }
};

// Get a specific hall
exports.getHallById = async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT h.*, d.DeptName FROM Halls h LEFT JOIN Departments d ON h.DeptID = d.DeptID WHERE h.HallID = ?',
      [req.params.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Hall not found' });
    }

    res.json({ success: true, data: normalizeHallRow(rows[0]) });
  } catch (error) {
    console.error('Error fetching hall details:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch hall details' });
  }
};

// Add a new hall
exports.createHall = async (req, res) => {
  try {
    const payload = normalizeHallPayload(req.body);
    const imageUrl = req.file
      ? `/uploads/venues/${req.file.filename}`
      : null;

    if (
      !payload.hallName ||
      !payload.location ||
      !payload.capacity ||
      !payload.deptId ||
      !payload.venueType
    ) {
      return res.status(400).json({
        success: false,
        message: "Please fill all required fields."
      });
    }

    const [result] = await pool.query(
      `INSERT INTO Halls
      (
        HallName,
        Location,
        Capacity,
        VenueType,
        HasProjector,
        HasSmartBoard,
        HasWiFi,
        HasSpeaker,
        HasPodium,
        HasWhiteBoard,
        HasCCTV,
        MicrophoneType,
        AdditionalFeatures,
        HasAC,
        NumberOfSystems,
        ImageURL,
        DeptID,
        ActiveStatus
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        payload.hallName,
        payload.location,
        payload.capacity,
        payload.venueType,
        payload.hasProjector ? 1 : 0,
        payload.hasSmartBoard ? 1 : 0,
        payload.hasWiFi ? 1 : 0,
        payload.hasSpeaker ? 1 : 0,
        payload.hasPodium ? 1 : 0,
        payload.hasWhiteBoard ? 1 : 0,
        payload.hasCCTV ? 1 : 0,
        payload.microphoneType || "None",
        payload.additionalFeatures || "",
        payload.hasAC ? 1 : 0,
        payload.numberOfSystems || 0,
        imageUrl,
        payload.deptId,
        payload.activeStatus ? 1 : 0
      ]
    );

    res.status(201).json({
      success: true,
      message: "Venue added successfully",
      data: {
        hallId: result.insertId,
        hallName: payload.hallName,
        department: "",
        deptId: payload.deptId,
        location: payload.location,
        capacity: payload.capacity,
        numberOfSystems: payload.numberOfSystems,
        venueType: payload.venueType,
        hasProjector: payload.hasProjector,
        hasSmartBoard: payload.hasSmartBoard,
        hasWiFi: payload.hasWiFi,
        hasSpeaker: payload.hasSpeaker,
        hasPodium: payload.hasPodium,
        hasWhiteBoard: payload.hasWhiteBoard,
        hasCCTV: payload.hasCCTV,
        hasAC: payload.hasAC,
        microphoneType: payload.microphoneType || "None",
        additionalFeatures: payload.additionalFeatures || "",
        image: imageUrl,
        activeStatus: payload.activeStatus,
      }
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Failed to add venue"
    });
  }
};

// Update a hall
exports.updateHall = async (req, res) => {
  try {
    const { id } = req.params;
    const payload = normalizeHallPayload(req.body);

    const [existingRows] = await pool.query('SELECT ImageURL, ActiveStatus FROM Halls WHERE HallID = ?', [id]);
    const existingImage = existingRows[0]?.ImageURL || null;
    const existingStatus = existingRows[0]?.ActiveStatus ?? 1;
    const imageUrl = req.file
      ? `/uploads/venues/${req.file.filename}`
      : (getBodyValue(req.body, ["imageUrl", "ImageURL"], existingImage) || existingImage);

    const hasExplicitStatus =
      req.body.activeStatus !== undefined &&
      req.body.activeStatus !== null &&
      req.body.activeStatus !== "" &&
      req.body.activeStatus !== "undefined";

    const activeStatus = hasExplicitStatus
      ? parseBoolean(req.body.activeStatus, existingStatus === 1)
      : existingStatus === 1;

    if (
      !payload.hallName ||
      !payload.location ||
      !payload.capacity ||
      !payload.deptId ||
      !payload.venueType
    ) {
      return res.status(400).json({
        success: false,
        message: "Please fill all required fields."
      });
    }

    await pool.query(
      `UPDATE Halls
       SET
         HallName = ?,
         Location = ?,
         Capacity = ?,
         VenueType = ?,
         HasProjector = ?,
         HasSmartBoard = ?,
         HasWiFi = ?,
         HasSpeaker = ?,
         HasPodium = ?,
         HasWhiteBoard = ?,
         HasCCTV = ?,
         MicrophoneType = ?,
         AdditionalFeatures = ?,
         HasAC = ?,
         NumberOfSystems = ?,
         ImageURL = ?,
         DeptID = ?,
         ActiveStatus = ?
       WHERE HallID = ?`,
      [
        payload.hallName,
        payload.location,
        payload.capacity,
        payload.venueType,
        payload.hasProjector ? 1 : 0,
        payload.hasSmartBoard ? 1 : 0,
        payload.hasWiFi ? 1 : 0,
        payload.hasSpeaker ? 1 : 0,
        payload.hasPodium ? 1 : 0,
        payload.hasWhiteBoard ? 1 : 0,
        payload.hasCCTV ? 1 : 0,
        payload.microphoneType || "None",
        payload.additionalFeatures || "",
        payload.hasAC ? 1 : 0,
        payload.numberOfSystems || 0,
        imageUrl,
        payload.deptId,
        activeStatus ? 1 : 0,
        id
      ]
    );

    const [updatedRows] = await pool.query(
      'SELECT h.*, d.DeptName FROM Halls h LEFT JOIN Departments d ON h.DeptID = d.DeptID WHERE h.HallID = ?',
      [id]
    );

    res.json({
      success: true,
      message: "Venue updated successfully",
      data: normalizeHallRow(updatedRows[0])
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Failed to update venue"
    });
  }
};
// Check availability of halls for a specific department and timeslot
exports.checkHallsAvailability = async (req, res) => {
  const { deptId, selectedDate, timeSlot } = req.body;

  if (!deptId || !selectedDate || !timeSlot) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const [rows] = await pool.query(
      `SELECT h.HallID, h.HallName, h.Location, h.Capacity 
       FROM Halls h 
       JOIN Departments d ON h.DeptID = d.DeptID 
       WHERE h.DeptID = ? 
       AND h.HallID NOT IN (
         SELECT HallID FROM Bookings 
         WHERE BookingDate = ? AND TimeSlot = ?
       )`,
      [deptId, selectedDate, timeSlot]
    );

    // Transform data to match frontend expectations
    const availableHalls = rows.map(hall => ({
      id: hall.HallID,
      name: hall.HallName,
      location: hall.Location,
      capacity: hall.Capacity,
    }));

    res.json(availableHalls);
  } catch (error) {
    console.error('Error checking hall availability:', error);
    res.status(500).json({ error: 'Failed to check hall availability' });
  }
};

// Toggle hall active status
exports.toggleHallStatus = async (req, res) => {
  const hallId = req.params.id;
  const { activeStatus } = req.body;
  
  if (activeStatus === undefined) {
    return res.status(400).json({ error: 'Active status is required' });
  }
  
  try {
    await pool.execute(
      'CALL ToggleHallStatus(?, ?)',
      [parseInt(hallId), !!activeStatus]
    );
    
    res.json({ 
      message: `Hall ${activeStatus ? 'activated' : 'deactivated'} successfully`,
      hallId,
      activeStatus: !!activeStatus
    });
  } catch (error) {
    console.error('Error toggling hall status:', error);
    res.status(500).json({ error: 'Failed to update hall status' });
  }
};

// Delete a hall permanently after checking for bookings
exports.deleteHall = async (req, res) => {
  const hallId = parseInt(req.params.id, 10);

  if (!hallId) {
    return res.status(400).json({ success: false, message: 'Invalid venue ID.' });
  }

  try {
    const [existingHall] = await pool.query(
      'SELECT HallID FROM Halls WHERE HallID = ?',
      [hallId]
    );

    if (existingHall.length === 0) {
      return res.status(404).json({ success: false, message: 'Venue not found.' });
    }

    const [bookingRows] = await pool.query(
      'SELECT COUNT(*) AS bookingCount FROM Bookings WHERE hall_id = ?',
      [hallId]
    );

    if (bookingRows[0].bookingCount > 0) {
      return res.status(409).json({
        success: false,
        message: 'Cannot delete this venue because booking records exist.'
      });
    }

    const [deleteResult] = await pool.query('DELETE FROM Halls WHERE HallID = ?', [hallId]);

    if (!deleteResult || deleteResult.affectedRows === 0) {
      return res.status(500).json({
        success: false,
        message: 'Unable to delete venue at this time.'
      });
    }

    res.json({
      success: true,
      message: 'Venue deleted successfully.'
    });
  } catch (error) {
    console.error('Error deleting hall:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to delete venue due to a database error.'
    });
  }
};

exports.getAvailableHalls = async (req, res) => {
  const { timeSlot } = req.query;

  if (!timeSlot) {
    return res.status(400).json({ error: 'Time slot is required' });
  }

  try {
    // Fetch all halls excluding those that are already booked in the selected time slot
    const [rows] = await pool.query(
      `SELECT h.HallID, h.HallName, h.Location, h.Capacity, d.DeptName 
       FROM Halls h 
       JOIN Departments d ON h.DeptID = d.DeptID
       WHERE h.HallID NOT IN (
         SELECT HallID FROM Bookings 
         WHERE TimeSlot = ?
       )`,
      [timeSlot]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'No available halls for this time slot' });
    }

    // Map the response to the frontend format
    const availableHalls = rows.map(hall => ({
      id: hall.HallID,
      name: hall.HallName,
      location: hall.Location,
      capacity: hall.Capacity,
      department: hall.DeptName
    }));

    res.json(availableHalls);
  } catch (error) {
    console.error('Error fetching available halls:', error);
    res.status(500).json({ error: 'Failed to fetch available halls' });
  }
}; 
