const pool = require('../config/db');

// Get admin dashboard statistics and recent bookings
exports.getAdminDashboard = async (req, res) => {
  try {
    // Parallel count queries
    const queries = [
      'SELECT COUNT(*) AS totalVenues FROM Halls',
      "SELECT COUNT(*) AS activeVenues FROM Halls WHERE ActiveStatus = 1",
      "SELECT COUNT(*) AS totalFaculty FROM staff WHERE role = 'staff'",
      "SELECT COUNT(*) AS totalAdmins FROM staff WHERE role = 'admin'",
      "SELECT COUNT(*) AS pendingBookings FROM bookings WHERE status = 'Pending'",
      "SELECT COUNT(*) AS approvedBookings FROM bookings WHERE status = 'Approved'",
      "SELECT COUNT(*) AS rejectedBookings FROM bookings WHERE status = 'Rejected'",
      "SELECT COUNT(*) AS cancelledBookings FROM bookings WHERE status = 'Cancelled'",
      "SELECT COUNT(*) AS todaysBookings FROM bookings WHERE DATE(date) = CURDATE()",
      // Available venues today: active venues minus venues with blocking bookings (Pending/Approved) today
      "SELECT COUNT(*) AS availableVenuesToday FROM Halls h WHERE h.ActiveStatus = 1 AND NOT EXISTS (SELECT 1 FROM bookings b WHERE b.hall_id = h.HallID AND DATE(b.date) = CURDATE() AND b.status IN ('Pending', 'Approved'))",
      // Recent bookings: use the real denormalized columns present in the bookings table
      "SELECT id, staff_name AS facultyName, hall_name AS venueName, date, time_from AS timeFrom, time_to AS timeTo, status FROM bookings ORDER BY created_at DESC, id DESC LIMIT 5"
    ];
    const promiseArray = queries.map((q) => pool.query(q));
    const results = await Promise.all(promiseArray);

    // COUNT queries return a single row -> r[0][0]
    const [totalVenues, activeVenues, totalFaculty, totalAdmins, pendingBookings, approvedBookings, rejectedBookings, cancelledBookings, todaysBookings, availableVenuesToday] = results.slice(0, 10).map(r => r[0][0]);
    // Recent bookings query returns an array of rows -> r[0]
    const [recentBookings] = results.slice(10).map(r => r[0]);

    res.json({
      success: true,
      data: {
        totalVenues: totalVenues.totalVenues,
        activeVenues: activeVenues.activeVenues,
        totalFaculty: totalFaculty.totalFaculty,
        totalAdmins: totalAdmins.totalAdmins,
        pendingBookings: pendingBookings.pendingBookings,
        approvedBookings: approvedBookings.approvedBookings,
        rejectedBookings: rejectedBookings.rejectedBookings,
        cancelledBookings: cancelledBookings.cancelledBookings,
        todaysBookings: todaysBookings.todaysBookings,
        availableVenues: availableVenuesToday.availableVenuesToday,
        availableVenuesToday: availableVenuesToday.availableVenuesToday,
        recentBookings: recentBookings.map(b => ({
          id: b.id,
          facultyName: b.facultyName,
          venueName: b.venueName,
          date: b.date,
          timeFrom: b.timeFrom,
          timeTo: b.timeTo,
          status: b.status,
        })),
      }
    });
  } catch (err) {
    console.error('Dashboard retrieval error:', err);
    res.status(500).json({ success: false, message: 'Failed to retrieve dashboard data', error: err.message });
  }
};

